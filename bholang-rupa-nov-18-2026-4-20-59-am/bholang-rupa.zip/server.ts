import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import type {
  ArtworkSubmission,
  CollabParticipant,
  CollabStroke,
  DemoState,
  ForumMessage,
  PresentationSubmission,
  QuizSubmission,
  TeacherNotification,
} from './src/types.ts';

dotenv.config();

const PORT = 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

interface StoreData {
  artworks: ArtworkSubmission[];
  presentations: PresentationSubmission[];
  quizzes: QuizSubmission[];
  forum: ForumMessage[];
  notifications: TeacherNotification[];
  demoState: DemoState;
  collabRooms: Record<string, CollabStroke[]>;
}

const defaultDemoState: DemoState = {
  mode: 'unsur',
  activeConcept: 'titik-garis',
  density: 64,
  lightAngle: 42,
  primaryHue: 222,
  customColor: '#1D4ED8',
  studentColor: '#1D4ED8',
  teacherColor: '#DC2626',
  selectedPrimaries: ['merah', 'kuning'],
  balanceMode: 'asimetris',
  rhythmCount: 6,
  emphasisStrength: 78,
  teacherNote:
    'Amati bagaimana perubahan sudut cahaya dan kepadatan garis memengaruhi kedalaman ruang pada karyamu.',
  updatedBy: 'Siswa Eksplorasi',
  updatedAt: new Date().toISOString(),
};

const SEED_ARTWORK_1_SVG = `data:image/svg+xml;base64,${Buffer.from(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 880 500">
    <rect width="880" height="500" fill="#FAF7F0"/>
    <circle cx="290" cy="240" r="145" fill="#1D4ED8" opacity="0.88"/>
    <circle cx="560" cy="230" r="110" fill="#DC2626" opacity="0.82"/>
    <circle cx="445" cy="275" r="85" fill="#F59E0B" opacity="0.85"/>
    <path d="M80 390 Q240 280 430 370 T800 340" fill="none" stroke="#0F172A" stroke-width="6" stroke-linecap="round"/>
    <path d="M110 420 Q280 320 460 400 T770 375" fill="none" stroke="#1E3A8A" stroke-width="3" stroke-dasharray="10 8"/>
    <circle cx="200" cy="145" r="8" fill="#0F172A"/>
    <circle cx="226" cy="132" r="6" fill="#0F172A"/>
    <circle cx="252" cy="126" r="4" fill="#0F172A"/>
  </svg>`
).toString('base64')}`;

const SEED_ARTWORK_2_SVG = `data:image/svg+xml;base64,${Buffer.from(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 880 500">
    <rect width="880" height="500" fill="#F3F6FA"/>
    <g transform="translate(440 250)">
      <circle r="170" fill="none" stroke="#1D4ED8" stroke-width="3" stroke-dasharray="8 8"/>
      <circle r="120" fill="none" stroke="#0EA5E9" stroke-width="4"/>
      <rect x="-84" y="-84" width="168" height="168" rx="18" transform="rotate(45)" fill="#1E40AF" opacity="0.85"/>
      <rect x="-64" y="-64" width="128" height="128" rx="14" fill="#F59E0B" opacity="0.9"/>
      <circle r="38" fill="#DC2626"/>
    </g>
  </svg>`
).toString('base64')}`;

const initialStore: StoreData = {
  artworks: [
    {
      id: 'art-seed-1',
      studentName: 'Aulia Rahma',
      className: 'X-A',
      title: 'Harmoni Gelombang Warna Komplementer',
      description:
        'Eksplorasi blending biru-merah-kuning dengan irama garis lengkung dan aksen titik bergradasi.',
      imageDataUrl: SEED_ARTWORK_1_SVG,
      aiCritique:
        'Keseimbangan asimetris terasa mantap. Perpaduan biru dingin dan aksen merah-kuning menciptakan titik fokus yang kuat.',
      pinned: true,
      pinnedBy: 'Kurator Kelas',
      pinnedAt: new Date(Date.now() - 18000000).toISOString(),
      likedBy: ['Hamidah Nuril', 'Bagas Pratama', 'Nadia Kusuma'],
      appreciations: [
        {
          id: 'appr-seed-1',
          authorName: 'Hamidah Nuril',
          authorRole: 'siswa',
          badge: 'Warna Harmonis',
          message:
            'Penerapan kontras warna primer dan irama garis lengkung sangat ekspresif. Layak dijadikan referensi kelas!',
          createdAt: new Date(Date.now() - 17000000).toISOString(),
        },
        {
          id: 'appr-seed-2',
          authorName: 'Bagas Pratama',
          authorRole: 'siswa',
          badge: 'Komposisi Indah',
          message: 'Perpindahan ukuran titik di kiri atas bikin komposisinya terlihat hidup.',
          createdAt: new Date(Date.now() - 12000000).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 21600000).toISOString(),
    },
    {
      id: 'art-seed-2',
      studentName: 'Nadia Kusuma',
      className: 'X-A',
      title: 'Mandala Simetri Radial Geometris',
      description:
        'Menerapkan prinsip keseimbangan radial 4-arah dengan kombinasi bidang persegi dan lingkaran.',
      imageDataUrl: SEED_ARTWORK_2_SVG,
      aiCritique:
        'Simetri radial sangat presisi dengan pusat perhatian warna merah yang tegas di tengah.',
      pinned: false,
      likedBy: ['Citra Melati'],
      appreciations: [
        {
          id: 'appr-seed-3',
          authorName: 'Citra Melati',
          authorRole: 'siswa',
          badge: 'Teknik Kreatif',
          message: 'Rapi banget simetri radialnya, warna tengahnya langsung jadi pusat perhatian.',
          createdAt: new Date(Date.now() - 7200000).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 14400000).toISOString(),
    },
  ],
  presentations: [
    {
      id: 'pres-sample-1',
      studentName: 'Aulia Rahma',
      className: 'X-A',
      title: 'Eksplorasi Keseimbangan Asimetris pada Batik Modern',
      topic: 'Prinsip Keseimbangan & Irama',
      mode: 'deck',
      slides: [
        {
          id: 's1',
          heading: 'Latar Belakang Visual',
          bullets: [
            'Mengamati pengulangan motif diagonal pada batik Nusantara.',
            'Memadukan garis lengkung organik dengan bidang geometris tegas.',
          ],
          note: 'Slide pengantar presentasi kelas.',
          accentColor: '#1D4ED8',
        },
        {
          id: 's2',
          heading: 'Penerapan Prinsip Irama & Penekanan',
          bullets: [
            'Irama tercipta dari pengulangan bentuk daun secara progresif.',
            'Penekanan menggunakan aksen merah marun di tengah bidang.',
          ],
          note: 'Fokus pengamatan pada kontras warna utama.',
          accentColor: '#DC2626',
        },
      ],
      comments: [
        {
          id: 'pcom-1',
          authorName: 'Hamidah Nuril',
          authorRole: 'siswa',
          content: 'Analisis keseimbangan asimetrisnya sudah sangat tepat, Aulia. Pertahankan kontras warna utamanya!',
          createdAt: new Date(Date.now() - 43200000).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
  ],
  quizzes: [
    {
      id: 'quiz-seed-1',
      studentName: 'Nadia Kusuma',
      className: 'X-A',
      topic: 'Unsur & Prinsip Seni Rupa KD 3.1',
      score: 92,
      unsurScore: 100,
      prinsipScore: 83,
      correctCount: 11,
      totalQuestions: 12,
      predicate: 'Sangat Baik',
      notes: 'Menguasai teori warna dan gelap-terang dengan sangat baik.',
      driveSynced: false,
      createdAt: new Date(Date.now() - 172800000).toISOString(),
    },
    {
      id: 'quiz-seed-2',
      studentName: 'Bagas Pratama',
      className: 'X-A',
      topic: 'Unsur & Prinsip Seni Rupa KD 3.1',
      score: 83,
      unsurScore: 83,
      prinsipScore: 83,
      correctCount: 10,
      totalQuestions: 12,
      predicate: 'Baik',
      notes: 'Pemahaman seimbang antara unsur dan prinsip komposisi.',
      driveSynced: false,
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: 'quiz-seed-3',
      studentName: 'Citra Melati',
      className: 'X-B',
      topic: 'Unsur & Prinsip Seni Rupa KD 3.1',
      score: 75,
      unsurScore: 83,
      prinsipScore: 67,
      correctCount: 9,
      totalQuestions: 12,
      predicate: 'Cukup',
      notes: 'Perlu pendalaman pada perbedaan irama progresif dan proporsi.',
      driveSynced: false,
      createdAt: new Date(Date.now() - 43200000).toISOString(),
    },
  ],
  forum: [
    {
      id: 'forum-1',
      authorName: 'Hamidah Nuril',
      authorRole: 'siswa',
      className: 'Kelas X',
      topicTag: 'Prinsip Seni Rupa',
      title: 'Bagaimana cara membedakan Keseimbangan Asimetris dan Ketidakseimbangan?',
      content:
        'Silakan tuliskan pendapat kalian setelah mencoba simulasi Demo Interaktif. Berikan satu contoh benda atau lukisan di sekitar kelas!',
      replies: [
        {
          id: 'rep-1',
          authorName: 'Aulia Rahma',
          authorRole: 'siswa',
          content:
            'Menurut saya Bu, asimetris tetap terasa tenang dan tidak berat sebelah karena objek kecil diberi warna lebih mencolok untuk mengimbangi objek besar.',
          createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 3600000 * 8).toISOString(),
    },
    {
      id: 'forum-2',
      authorName: 'Bagas Pratama',
      authorRole: 'siswa',
      className: 'X-A',
      topicTag: 'Unsur Seni Rupa',
      title: 'Tips membuat tekstur semu kayu dengan arsiran pensil',
      content:
        'Teman-teman, waktu menggambar di kanvas tadi saya pakai garis lengkung berlapis tipis untuk meniru serat kayu. Ada teknik lain yang lebih cepat?',
      replies: [
        {
          id: 'rep-2',
          authorName: 'Citra Melati',
          authorRole: 'siswa',
          content:
            'Coba kombinasikan garis kontur tipis lalu tambahkan titik-titik gelap di simpul kayunya Bagas, hasilnya langsung terasa bertekstur!',
          createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
        },
      ],
      createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    },
  ],
  notifications: [
    {
      id: 'notif-seed-1',
      type: 'quiz',
      studentName: 'Citra Melati',
      className: 'X-B',
      title: 'Menyelesaikan Kuis Unsur & Prinsip Seni Rupa',
      detail: 'Skor: 75/100 (9 dari 12 soal benar)',
      read: false,
      createdAt: new Date(Date.now() - 43200000).toISOString(),
    },
  ],
  demoState: defaultDemoState,
  collabRooms: {
    'ruang-utama': [],
  },
};

function loadStore(): StoreData {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(STORE_PATH)) {
      fs.writeFileSync(STORE_PATH, JSON.stringify(initialStore, null, 2), 'utf-8');
      return JSON.parse(JSON.stringify(initialStore)) as StoreData;
    }
    const raw = fs.readFileSync(STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<StoreData>;
    return {
      artworks: (parsed.artworks ?? initialStore.artworks).map((a) => ({
        ...a,
        pinned: Boolean(a.pinned),
        likedBy: Array.isArray(a.likedBy) ? a.likedBy : [],
        appreciations: Array.isArray(a.appreciations) ? a.appreciations : [],
      })),
      presentations: parsed.presentations ?? initialStore.presentations,
      quizzes: parsed.quizzes ?? initialStore.quizzes,
      forum: parsed.forum ?? initialStore.forum,
      notifications: parsed.notifications ?? initialStore.notifications,
      demoState: parsed.demoState ?? defaultDemoState,
      collabRooms: parsed.collabRooms ?? initialStore.collabRooms,
    };
  } catch {
    return JSON.parse(JSON.stringify(initialStore)) as StoreData;
  }
}

let store: StoreData = loadStore();

function saveStore() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist store:', err);
  }
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY belum dikonfigurasi pada Secrets panel.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '15mb' }));

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  function broadcast(event: string, payload: unknown) {
    const message = JSON.stringify({ event, payload });
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // Track room membership per WebSocket client for collaborative canvas ("Kanvas Bersama")
  const collabSocketSessions = new Map<
    WebSocket,
    { roomId: string; participant: CollabParticipant }
  >();

  function getRoomParticipants(roomId: string): CollabParticipant[] {
    const seen = new Map<string, CollabParticipant>();
    collabSocketSessions.forEach((session) => {
      if (session.roomId === roomId) {
        seen.set(session.participant.userId, session.participant);
      }
    });
    return Array.from(seen.values());
  }

  function broadcastToRoom(
    roomId: string,
    event: string,
    payload: unknown,
    excludeSocket?: WebSocket
  ) {
    const message = JSON.stringify({ event, payload });
    collabSocketSessions.forEach((session, client) => {
      if (
        session.roomId === roomId &&
        client !== excludeSocket &&
        client.readyState === WebSocket.OPEN
      ) {
        client.send(message);
      }
    });
  }

  wss.on('connection', (ws) => {
    ws.send(
      JSON.stringify({
        event: 'sync:init',
        payload: {
          demoState: store.demoState,
          unreadCount: store.notifications.filter((n) => !n.read).length,
        },
      })
    );

    ws.on('message', (raw) => {
      try {
        const parsed = JSON.parse(raw.toString()) as { event?: string; payload?: unknown };
        if (parsed.event === 'demo:update' && parsed.payload && typeof parsed.payload === 'object') {
          store.demoState = {
            ...store.demoState,
            ...(parsed.payload as Partial<DemoState>),
            updatedAt: new Date().toISOString(),
          };
          saveStore();
          broadcast('demo:sync', store.demoState);
        } else if (
          parsed.event === 'collab:join' &&
          parsed.payload &&
          typeof parsed.payload === 'object'
        ) {
          const { roomId, userId, userName, className, color } = parsed.payload as {
            roomId?: string;
            userId?: string;
            userName?: string;
            className?: string;
            color?: string;
          };
          const cleanRoom = (roomId || 'ruang-utama').trim().slice(0, 64) || 'ruang-utama';
          const prevSession = collabSocketSessions.get(ws);
          if (prevSession && prevSession.roomId !== cleanRoom) {
            collabSocketSessions.delete(ws);
            broadcastToRoom(prevSession.roomId, 'collab:presence', {
              roomId: prevSession.roomId,
              participants: getRoomParticipants(prevSession.roomId),
            });
          }
          const participant: CollabParticipant = {
            userId: (userId || `user-${Date.now()}`).trim(),
            userName: (userName || 'Siswa').trim(),
            className: (className || 'X-A').trim(),
            color: color || '#1D4ED8',
          };
          collabSocketSessions.set(ws, { roomId: cleanRoom, participant });

          if (!store.collabRooms[cleanRoom]) {
            store.collabRooms[cleanRoom] = [];
          }
          const participants = getRoomParticipants(cleanRoom);
          ws.send(
            JSON.stringify({
              event: 'collab:init',
              payload: {
                roomId: cleanRoom,
                strokes: store.collabRooms[cleanRoom],
                participants,
              },
            })
          );
          broadcastToRoom(
            cleanRoom,
            'collab:presence',
            { roomId: cleanRoom, participants },
            ws
          );
        } else if (parsed.event === 'collab:leave') {
          const prevSession = collabSocketSessions.get(ws);
          if (prevSession) {
            collabSocketSessions.delete(ws);
            broadcastToRoom(prevSession.roomId, 'collab:presence', {
              roomId: prevSession.roomId,
              participants: getRoomParticipants(prevSession.roomId),
            });
          }
        } else if (
          parsed.event === 'collab:stroke' &&
          parsed.payload &&
          typeof parsed.payload === 'object'
        ) {
          const { stroke } = parsed.payload as { stroke?: CollabStroke };
          if (!stroke || !stroke.id || !stroke.roomId || !Array.isArray(stroke.points)) return;
          const cleanRoom = stroke.roomId.trim() || 'ruang-utama';
          if (!store.collabRooms[cleanRoom]) {
            store.collabRooms[cleanRoom] = [];
          }
          // Idempotent add: avoid duplicates on reconnect/retry
          if (!store.collabRooms[cleanRoom].some((s) => s.id === stroke.id)) {
            store.collabRooms[cleanRoom].push(stroke);
            if (store.collabRooms[cleanRoom].length > 2000) {
              store.collabRooms[cleanRoom] = store.collabRooms[cleanRoom].slice(-2000);
            }
            saveStore();
            broadcastToRoom(cleanRoom, 'collab:stroke', { roomId: cleanRoom, stroke });
          }
        } else if (
          parsed.event === 'collab:stroke:live' &&
          parsed.payload &&
          typeof parsed.payload === 'object'
        ) {
          const { stroke } = parsed.payload as { stroke?: CollabStroke };
          if (!stroke || !stroke.roomId || !Array.isArray(stroke.points)) return;
          broadcastToRoom(
            stroke.roomId,
            'collab:stroke:live',
            { roomId: stroke.roomId, stroke },
            ws
          );
        } else if (
          parsed.event === 'collab:cursor' &&
          parsed.payload &&
          typeof parsed.payload === 'object'
        ) {
          const cursor = parsed.payload as {
            roomId?: string;
            userId?: string;
            userName?: string;
            color?: string;
            x?: number;
            y?: number;
          };
          if (!cursor.roomId || !cursor.userId) return;
          broadcastToRoom(
            cursor.roomId,
            'collab:cursor',
            {
              roomId: cursor.roomId,
              userId: cursor.userId,
              userName: cursor.userName || 'Siswa',
              color: cursor.color || '#1D4ED8',
              x: Number(cursor.x ?? 0),
              y: Number(cursor.y ?? 0),
            },
            ws
          );
        } else if (
          parsed.event === 'collab:undo' &&
          parsed.payload &&
          typeof parsed.payload === 'object'
        ) {
          const { roomId, userId } = parsed.payload as { roomId?: string; userId?: string };
          const cleanRoom = (roomId || 'ruang-utama').trim();
          const list = store.collabRooms[cleanRoom] || [];
          let targetIdx = -1;
          for (let i = list.length - 1; i >= 0; i -= 1) {
            if (!userId || list[i].userId === userId) {
              targetIdx = i;
              break;
            }
          }
          if (targetIdx !== -1) {
            list.splice(targetIdx, 1);
            store.collabRooms[cleanRoom] = list;
            saveStore();
            broadcastToRoom(cleanRoom, 'collab:sync', {
              roomId: cleanRoom,
              strokes: list,
            });
          }
        } else if (
          parsed.event === 'collab:clear' &&
          parsed.payload &&
          typeof parsed.payload === 'object'
        ) {
          const { roomId, actorName } = parsed.payload as {
            roomId?: string;
            actorName?: string;
          };
          const cleanRoom = (roomId || 'ruang-utama').trim();
          store.collabRooms[cleanRoom] = [];
          saveStore();
          broadcastToRoom(cleanRoom, 'collab:cleared', {
            roomId: cleanRoom,
            actorName: actorName || 'Siswa',
          });
        }
      } catch {
        // Ignore malformed websocket frame
      }
    });

    ws.on('close', () => {
      const prevSession = collabSocketSessions.get(ws);
      if (prevSession) {
        collabSocketSessions.delete(ws);
        broadcastToRoom(prevSession.roomId, 'collab:presence', {
          roomId: prevSession.roomId,
          participants: getRoomParticipants(prevSession.roomId),
        });
      }
    });
  });

  // --- Bootstrap / Data Routes ---
  app.get('/api/state', (_req, res) => {
    res.json(store);
  });

  app.post('/api/notifications/read-all', (_req, res) => {
    store.notifications = store.notifications.map((n) => ({ ...n, read: true }));
    saveStore();
    broadcast('notifications:updated', store.notifications);
    res.json({ ok: true, notifications: store.notifications });
  });

  // --- Artwork Submission ---
  app.post('/api/submissions/artwork', (req, res) => {
    const { studentName, className, title, description, imageDataUrl, aiCritique, driveFileId, driveWebViewLink } =
      req.body as Partial<ArtworkSubmission>;
    if (!studentName || !imageDataUrl) {
      return res.status(400).json({ error: 'Nama siswa dan gambar karya wajib diisi.' });
    }
    const item: ArtworkSubmission = {
      id: `art-${Date.now()}`,
      studentName: studentName.trim(),
      className: (className || 'X-A').trim(),
      title: (title || 'Karya Praktik Seni Rupa').trim(),
      description: (description || '').trim(),
      imageDataUrl,
      aiCritique,
      driveFileId,
      driveWebViewLink,
      pinned: false,
      likedBy: [],
      appreciations: [],
      createdAt: new Date().toISOString(),
    };
    store.artworks.unshift(item);

    const notification: TeacherNotification = {
      id: `notif-${Date.now()}`,
      type: 'artwork',
      studentName: item.studentName,
      className: item.className,
      title: `Karya Gambar Baru: ${item.title}`,
      detail: driveWebViewLink
        ? 'Terkirim ke Google Drive kelas dan E-mail pemantauan.'
        : 'Tersimpan di Galeri Kelas BHOLANG RUPA.',
      driveLink: driveWebViewLink,
      read: false,
      createdAt: item.createdAt,
    };
    store.notifications.unshift(notification);
    saveStore();

    broadcast('artwork:created', item);
    broadcast('notification:new', notification);

    return res.json({ item, notification });
  });

  // --- Galeri Kelas: Pin Best Artwork, Real-Time Like, & Appreciation ---
  app.patch('/api/artworks/:id/pin', (req, res) => {
    const { id } = req.params;
    const { pinned, actorName } = req.body as {
      pinned?: boolean;
      actorName?: string;
    };
    const idx = store.artworks.findIndex((a) => a.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Karya tidak ditemukan.' });
    }
    const nextPinned = Boolean(pinned);
    store.artworks[idx] = {
      ...store.artworks[idx],
      pinned: nextPinned,
      pinnedBy: nextPinned ? (actorName || 'Kurator Kelas').trim() : undefined,
      pinnedAt: nextPinned ? new Date().toISOString() : undefined,
    };
    saveStore();
    broadcast('artwork:updated', store.artworks[idx]);
    return res.json({ item: store.artworks[idx] });
  });

  app.post('/api/artworks/:id/like', (req, res) => {
    const { id } = req.params;
    const { userName } = req.body as { userName?: string };
    const cleanName = userName?.trim();
    if (!cleanName) {
      return res.status(400).json({ error: 'Nama pengguna wajib diisi.' });
    }
    const idx = store.artworks.findIndex((a) => a.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Karya tidak ditemukan.' });
    }
    const currentLikes = store.artworks[idx].likedBy ?? [];
    const alreadyLiked = currentLikes.includes(cleanName);
    const nextLikes = alreadyLiked
      ? currentLikes.filter((n) => n !== cleanName)
      : [...currentLikes, cleanName];

    store.artworks[idx] = {
      ...store.artworks[idx],
      likedBy: nextLikes,
    };
    saveStore();
    broadcast('artwork:updated', store.artworks[idx]);
    return res.json({ item: store.artworks[idx], liked: !alreadyLiked });
  });

  app.post('/api/artworks/:id/appreciations', (req, res) => {
    const { id } = req.params;
    const { authorName, authorRole, badge, message } = req.body as {
      authorName?: string;
      authorRole?: 'guru' | 'siswa';
      badge?: string;
      message?: string;
    };
    if (!authorName?.trim() || !message?.trim()) {
      return res.status(400).json({ error: 'Nama dan pesan apresiasi wajib diisi.' });
    }
    const idx = store.artworks.findIndex((a) => a.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Karya tidak ditemukan.' });
    }
    const appreciation = {
      id: `appr-${Date.now()}`,
      authorName: authorName.trim(),
      authorRole: authorRole === 'guru' ? ('guru' as const) : ('siswa' as const),
      badge: badge?.trim() || undefined,
      message: message.trim(),
      createdAt: new Date().toISOString(),
    };
    store.artworks[idx] = {
      ...store.artworks[idx],
      appreciations: [...(store.artworks[idx].appreciations ?? []), appreciation],
    };
    saveStore();
    broadcast('artwork:appreciation', { artworkId: id, appreciation });
    return res.json({ artworkId: id, appreciation, item: store.artworks[idx] });
  });

  // --- Presentation Submission ---
  app.post('/api/submissions/presentation', (req, res) => {
    const body = req.body as Partial<PresentationSubmission>;
    if (!body.studentName || !body.title) {
      return res.status(400).json({ error: 'Nama siswa dan judul presentasi wajib diisi.' });
    }
    const item: PresentationSubmission = {
      id: `pres-${Date.now()}`,
      studentName: body.studentName.trim(),
      className: (body.className || 'X-A').trim(),
      title: body.title.trim(),
      topic: (body.topic || 'Unsur & Prinsip Seni Rupa').trim(),
      mode: body.mode === 'file' ? 'file' : 'deck',
      slides: body.slides,
      parsedSlides: body.parsedSlides,
      fileName: body.fileName,
      fileMimeType: body.fileMimeType,
      fileDataUrl: body.fileDataUrl,
      driveFileId: body.driveFileId,
      driveWebViewLink: body.driveWebViewLink,
      comments: [],
      createdAt: new Date().toISOString(),
    };
    store.presentations.unshift(item);

    const notification: TeacherNotification = {
      id: `notif-${Date.now()}`,
      type: 'presentation',
      studentName: item.studentName,
      className: item.className,
      title: `Presentasi Baru: ${item.title}`,
      detail: item.driveWebViewLink
        ? 'Diunggah ke Google Drive & dapat dilihat seluruh kelas.'
        : 'Tersedia di galeri presentasi kelas.',
      driveLink: item.driveWebViewLink,
      read: false,
      createdAt: item.createdAt,
    };
    store.notifications.unshift(notification);
    saveStore();

    broadcast('presentation:created', item);
    broadcast('notification:new', notification);

    return res.json({ item, notification });
  });

  app.post('/api/submissions/presentation/:id/comments', (req, res) => {
    const { id } = req.params;
    const { authorName, authorRole, content } = req.body as {
      authorName?: string;
      authorRole?: 'siswa' | 'guru';
      content?: string;
    };
    if (!authorName || !content?.trim()) {
      return res.status(400).json({ error: 'Nama dan komentar wajib diisi.' });
    }
    const target = store.presentations.find((p) => p.id === id);
    if (!target) {
      return res.status(404).json({ error: 'Presentasi tidak ditemukan.' });
    }
    const comment = {
      id: `pcom-${Date.now()}`,
      authorName: authorName.trim(),
      authorRole: authorRole === 'guru' ? ('guru' as const) : ('siswa' as const),
      content: content.trim(),
      createdAt: new Date().toISOString(),
    };
    target.comments = [...(target.comments ?? []), comment];
    saveStore();
    broadcast('presentation:comment', { presentationId: id, comment });
    return res.json({ presentationId: id, comment });
  });

  // --- Quiz Submission ---
  app.post('/api/quiz/submit', (req, res) => {
    const body = req.body as Partial<QuizSubmission>;
    if (!body.studentName || typeof body.score !== 'number') {
      return res.status(400).json({ error: 'Data nilai kuis tidak lengkap.' });
    }
    const item: QuizSubmission = {
      id: `quiz-${Date.now()}`,
      studentName: body.studentName.trim(),
      className: (body.className || 'X-A').trim(),
      topic: body.topic || 'Unsur & Prinsip Seni Rupa KD 3.1',
      score: body.score,
      unsurScore: body.unsurScore ?? body.score,
      prinsipScore: body.prinsipScore ?? body.score,
      correctCount: body.correctCount ?? 0,
      totalQuestions: body.totalQuestions ?? 12,
      predicate: body.predicate || 'Baik',
      notes: body.notes || '',
      essayAnswers: body.essayAnswers ?? [],
      essayScore: body.essayScore,
      driveSynced: Boolean(body.driveSynced),
      spreadsheetUrl: body.spreadsheetUrl,
      createdAt: new Date().toISOString(),
    };
    store.quizzes.unshift(item);

    const essayCount = item.essayAnswers?.filter((e) => e.answer.trim()).length ?? 0;
    const notification: TeacherNotification = {
      id: `notif-${Date.now()}`,
      type: 'quiz',
      studentName: item.studentName,
      className: item.className,
      title: `Nilai Kuis Masuk: ${item.score}/100 (${item.predicate})`,
      detail: `${item.correctCount}/${item.totalQuestions} PG benar${essayCount > 0 ? ` · ${essayCount} Esai C1–C6 dikirim` : ''}`,
      driveLink: item.spreadsheetUrl,
      read: false,
      createdAt: item.createdAt,
    };
    store.notifications.unshift(notification);
    saveStore();

    broadcast('quiz:created', item);
    broadcast('notification:new', notification);

    return res.json({ item, notification });
  });

  app.patch('/api/quiz/:id/grade-essay', (req, res) => {
    const { id } = req.params;
    const { essayAnswers, essayScore } = req.body as {
      essayAnswers?: QuizSubmission['essayAnswers'];
      essayScore?: number;
    };
    const idx = store.quizzes.findIndex((q) => q.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Data kuis tidak ditemukan.' });
    }
    store.quizzes[idx] = {
      ...store.quizzes[idx],
      essayAnswers: essayAnswers ?? store.quizzes[idx].essayAnswers,
      essayScore: typeof essayScore === 'number' ? essayScore : store.quizzes[idx].essayScore,
    };
    saveStore();
    broadcast('quiz:updated', store.quizzes[idx]);
    return res.json({ item: store.quizzes[idx] });
  });

  app.patch('/api/quiz/:id/drive-sync', (req, res) => {
    const { id } = req.params;
    const { driveSynced, spreadsheetUrl } = req.body as { driveSynced?: boolean; spreadsheetUrl?: string };
    const idx = store.quizzes.findIndex((q) => q.id === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'Data kuis tidak ditemukan.' });
    }
    store.quizzes[idx] = {
      ...store.quizzes[idx],
      driveSynced: Boolean(driveSynced),
      spreadsheetUrl: spreadsheetUrl ?? store.quizzes[idx].spreadsheetUrl,
    };
    saveStore();
    broadcast('quiz:updated', store.quizzes[idx]);
    return res.json({ item: store.quizzes[idx] });
  });

  // --- Forum Discussion ---
  app.post('/api/forum/messages', (req, res) => {
    const { authorName, authorRole, className, topicTag, title, content } = req.body as Partial<ForumMessage>;
    if (!authorName || !title || !content) {
      return res.status(400).json({ error: 'Judul dan isi diskusi wajib diisi.' });
    }
    const msg: ForumMessage = {
      id: `forum-${Date.now()}`,
      authorName: authorName.trim(),
      authorRole: authorRole === 'guru' ? 'guru' : 'siswa',
      className: (className || 'X-A').trim(),
      topicTag: (topicTag || 'Umum').trim(),
      title: title.trim(),
      content: content.trim(),
      replies: [],
      createdAt: new Date().toISOString(),
    };
    store.forum.unshift(msg);

    let notification: TeacherNotification | null = null;
    if (msg.authorRole === 'siswa') {
      notification = {
        id: `notif-${Date.now()}`,
        type: 'forum',
        studentName: msg.authorName,
        className: msg.className,
        title: `Diskusi Baru: ${msg.title}`,
        detail: msg.content.slice(0, 90),
        read: false,
        createdAt: msg.createdAt,
      };
      store.notifications.unshift(notification);
    }

    saveStore();
    broadcast('forum:created', msg);
    if (notification) {
      broadcast('notification:new', notification);
    }
    return res.json({ item: msg });
  });

  app.post('/api/forum/messages/:id/replies', (req, res) => {
    const { id } = req.params;
    const { authorName, authorRole, content } = req.body as {
      authorName?: string;
      authorRole?: 'siswa' | 'guru';
      content?: string;
    };
    if (!authorName || !content) {
      return res.status(400).json({ error: 'Nama dan balasan wajib diisi.' });
    }
    const target = store.forum.find((m) => m.id === id);
    if (!target) {
      return res.status(404).json({ error: 'Topik diskusi tidak ditemukan.' });
    }
    const reply = {
      id: `rep-${Date.now()}`,
      authorName: authorName.trim(),
      authorRole: authorRole === 'guru' ? ('guru' as const) : ('siswa' as const),
      content: content.trim(),
      createdAt: new Date().toISOString(),
    };
    target.replies.push(reply);
    saveStore();
    broadcast('forum:reply', { messageId: id, reply });
    return res.json({ messageId: id, reply });
  });

  // --- Gemini AI Endpoints (Server-Side Only) ---
  app.post('/api/ai/tutor', async (req, res) => {
    try {
      const { question, slideContext } = req.body as { question?: string; slideContext?: string };
      if (!question?.trim()) {
        return res.status(400).json({ error: 'Pertanyaan wajib diisi.' });
      }
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Konteks materi saat ini: ${slideContext || 'Unsur-Unsur dan Prinsip Seni Rupa Kelas X KD 3.1'}.\n\nPertanyaan siswa/guru: ${question}`,
        config: {
          systemInstruction:
            'Anda adalah Tutor Seni Rupa profesional untuk jenjang SMA/SMK Kelas X (Kurikulum Merdeka KD 3.1). Jawab dalam bahasa Indonesia yang jelas, hangat, terstruktur singkat (maksimal 3 paragraf atau poin ringkas), disertai contoh visual atau teknik berkarya yang nyata.',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });
      return res.json({ answer: response.text ?? 'Maaf, tidak ada respons teks.' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal menghubungi layanan AI.';
      console.error('AI Tutor error:', err);
      return res.status(500).json({ error: msg });
    }
  });

  app.post('/api/ai/critique-artwork', async (req, res) => {
    try {
      const { imageDataUrl, title } = req.body as { imageDataUrl?: string; title?: string };
      if (!imageDataUrl || !imageDataUrl.includes(',')) {
        return res.status(400).json({ error: 'Gambar karya tidak valid.' });
      }
      const [meta, base64Data] = imageDataUrl.split(',');
      const mimeMatch = meta.match(/data:(.*?);base64/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';

      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: base64Data,
              },
            },
            {
              text: `Berikan apresiasi dan kritik konstruktif terhadap karya gambar siswa berjudul "${title || 'Karya Praktik'}" ditinjau dari Unsur-Unsur Seni Rupa (garis, bidang, warna, tekstur, gelap-terang, ruang) dan Prinsip Seni Rupa (kesatuan, keseimbangan, irama, penekanan, proporsi, keselarasan). Berikan respons dalam JSON.`,
            },
          ],
        },
        config: {
          systemInstruction:
            'Anda adalah Kurator dan Guru Seni Rupa SMA yang suportif dan teliti. Berikan evaluasi edukatif dalam bahasa Indonesia yang memotivasi siswa.',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              ringkasan: {
                type: Type.STRING,
                description: 'Ringkasan apresiasi 1-2 kalimat atas karya siswa.',
              },
              unsurMenonjol: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '2-3 unsur seni rupa yang terlihat pada karya.',
              },
              prinsipTerlihat: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '2-3 prinsip seni rupa yang sudah diterapkan.',
              },
              saranPengembangan: {
                type: Type.STRING,
                description: 'Saran konkret untuk menyempurnakan karya berikutnya.',
              },
            },
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        ringkasan?: string;
        unsurMenonjol?: string[];
        prinsipTerlihat?: string[];
        saranPengembangan?: string;
      };
      return res.json({ critique: parsed });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal menganalisis karya.';
      console.error('AI Critique error:', err);
      return res.status(500).json({ error: msg });
    }
  });

  app.post('/api/ai/quiz-hint', async (req, res) => {
    try {
      const { question, topic } = req.body as { question?: string; topic?: string };
      if (!question) {
        return res.status(400).json({ error: 'Soal wajib dikirim.' });
      }
      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: `Topik: ${topic || 'Seni Rupa'}\nSoal: ${question}\nBerikan 1-2 kalimat petunjuk berpikir agar siswa bisa menemukan jawabannya sendiri TANPA menyebutkan jawaban benarnya secara langsung.`,
        config: {
          systemInstruction:
            'Anda guru seni rupa yang memberikan scaffolding/petunjuk singkat tanpa membocorkan kunci jawaban.',
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        },
      });
      return res.json({ hint: response.text ?? 'Perhatikan kata kunci pada soal.' });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Gagal membuat petunjuk.';
      return res.status(500).json({ error: msg });
    }
  });

  // --- Vite / Static Serving ---
  const distDir = path.resolve(process.cwd(), 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (!isProd) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`BHOLANG RUPA server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
