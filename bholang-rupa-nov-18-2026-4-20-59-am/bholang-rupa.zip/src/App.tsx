import { useCallback, useEffect, useRef, useState } from 'react';
import { Bell, ExternalLink, X } from 'lucide-react';
import type { User } from 'firebase/auth';
import { AnalitikSection } from './components/AnalitikSection';
import { DemoPraktikSection } from './components/DemoPraktikSection';
import { EmailConfirmModal, type PendingEmailPayload } from './components/EmailConfirmModal';
import {
  ExternalFocusModal,
  ExternalReturnBanner,
  type ExternalReturnInfo,
  type FocusViewerResource,
} from './components/ExternalReturnExperience';
import { GaleriKelasSection } from './components/GaleriKelasSection';
import { HeaderNav } from './components/HeaderNav';
import { KuisSection } from './components/KuisSection';
import { MateriSection } from './components/MateriSection';
import { PresentasiDiskusiSection } from './components/PresentasiDiskusiSection';
import { WelcomeModal } from './components/WelcomeModal';
import {
  DRIVE_FOLDER_URL,
  EBOOK_URL,
  TEACHER_MONITOR_EMAIL,
} from './data/learningContent';
import type {
  ActiveTab,
  ArtworkAppreciation,
  ArtworkSubmission,
  DemoState,
  ForumMessage,
  PresentationSubmission,
  QuizSubmission,
  TeacherNotification,
  UserProfile,
} from './types';
import {
  getCachedAccessToken,
  initGoogleAuth,
  sendMonitoringEmail,
  signInWithGoogleWorkspace,
  signOutGoogleWorkspace,
} from './utils/firebaseGoogle';
import {
  playClickSound,
  playNotificationChime,
  setSoundEnabled,
} from './utils/sound';

const DEFAULT_DEMO_STATE: DemoState = {
  mode: 'unsur',
  activeConcept: 'titik-garis',
  density: 64,
  lightAngle: 42,
  primaryHue: 222,
  customColor: '#1D4ED8',
  studentColor: '#1D4ED8',
  teacherColor: '#DC2626',
  selectedPrimaries: ['merah', 'kuning'],
  balanceMode: 'asimetris',
  rhythmCount: 6,
  emphasisStrength: 78,
  teacherNote:
    'Amati bagaimana perubahan sudut cahaya dan kepadatan garis memengaruhi kedalaman ruang pada karyamu.',
  updatedBy: 'Siswa Eksplorasi',
  updatedAt: new Date().toISOString(),
};

function loadInitialProfile(): UserProfile {
  try {
    const saved = localStorage.getItem('bholang_profile');
    if (saved) {
      return JSON.parse(saved) as UserProfile;
    }
  } catch {
    // Ignore storage parse error
  }
  return { name: 'Siswa Seni Rupa', role: 'siswa', className: 'X-A' };
}

export default function App() {
  const [welcomeOpen, setWelcomeOpen] = useState(true);
  const [profile, setProfile] = useState<UserProfile>(loadInitialProfile);
  const [activeTab, setActiveTab] = useState<ActiveTab>('materi');

  // Theme (Light/Dark)
  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      return localStorage.getItem('bholang_theme') === 'dark';
    } catch {
      return false;
    }
  });

  // Sound toggle
  const [soundOn, setSoundOn] = useState(true);

  // Google Workspace Auth & Email confirmation state
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [isLoggingInGoogle, setIsLoggingInGoogle] = useState(false);
  const [authMessage, setAuthMessage] = useState('');
  const [pendingEmail, setPendingEmail] = useState<PendingEmailPayload | null>(null);
  const [sendingEmail, setSendingEmail] = useState(false);
  const [emailStatus, setEmailStatus] = useState<{ ok: boolean; text: string } | null>(null);

  // App state synced with server & WebSocket
  const [artworks, setArtworks] = useState<ArtworkSubmission[]>([]);
  const [presentations, setPresentations] = useState<PresentationSubmission[]>([]);
  const [quizzes, setQuizzes] = useState<QuizSubmission[]>([]);
  const [forumMessages, setForumMessages] = useState<ForumMessage[]>([]);
  const [notifications, setNotifications] = useState<TeacherNotification[]>([]);
  const [demoState, setDemoState] = useState<DemoState>(DEFAULT_DEMO_STATE);
  const [wsConnected, setWsConnected] = useState(false);
  const [liveToast, setLiveToast] = useState<TeacherNotification | null>(null);
  const [focusViewerResource, setFocusViewerResource] =
    useState<FocusViewerResource | null>(null);
  const [externalReturn, setExternalReturn] = useState<ExternalReturnInfo | null>(null);

  const wsRef = useRef<WebSocket | null>(null);
  const wsListenersRef = useRef<Set<(event: string, payload: unknown) => void>>(new Set());

  const subscribeWs = useCallback(
    (listener: (event: string, payload: unknown) => void) => {
      wsListenersRef.current.add(listener);
      return () => {
        wsListenersRef.current.delete(listener);
      };
    },
    []
  );

  const sendWs = useCallback((event: string, payload: unknown) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ event, payload }));
    }
  }, []);

  // Apply dark class to <html>
  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
    try {
      localStorage.setItem('bholang_theme', isDark ? 'dark' : 'light');
    } catch {
      // Ignore
    }
  }, [isDark]);

  // Sync audio toggle & global click audio feedback on interactive buttons
  useEffect(() => {
    setSoundEnabled(soundOn);
  }, [soundOn]);

  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      if (target.closest('button, [role="button"], a')) {
        playClickSound();
      }
    };
    document.addEventListener('click', handleGlobalClick, true);
    return () => document.removeEventListener('click', handleGlobalClick, true);
  }, []);

  // Track clicks on external links (YouTube, E-Book PDF, Google Drive, Sheets, Wayground)
  // and highlight the "Kembali ke Web" bar when the student returns to this tab.
  useEffect(() => {
    const handleExternalLinkClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const anchor = target?.closest('a') as HTMLAnchorElement | null;
      if (!anchor) return;
      const href = anchor.getAttribute('href') || '';
      const isExternal =
        href.startsWith('http') && !href.startsWith(window.location.origin);
      if (isExternal && anchor.target === '_blank') {
        const label =
          anchor.dataset.resourceLabel ||
          anchor.textContent?.trim() ||
          'Halaman Eksternal';
        setExternalReturn({
          label,
          url: href,
          openedAt: Date.now(),
          returnedToTab: false,
        });
      }
    };

    const markReturned = () => {
      if (document.visibilityState === 'visible') {
        setExternalReturn((prev) =>
          prev ? { ...prev, returnedToTab: true } : null
        );
      }
    };

    document.addEventListener('click', handleExternalLinkClick, true);
    window.addEventListener('focus', markReturned);
    document.addEventListener('visibilitychange', markReturned);
    return () => {
      document.removeEventListener('click', handleExternalLinkClick, true);
      window.removeEventListener('focus', markReturned);
      document.removeEventListener('visibilitychange', markReturned);
    };
  }, []);

  // Initialize Firebase Google Auth listener
  useEffect(() => {
    const unsub = initGoogleAuth(
      (user) => {
        setGoogleUser(user);
      },
      () => {
        setGoogleUser(null);
      }
    );
    return () => unsub();
  }, []);

  // Load initial state from Express backend
  useEffect(() => {
    fetch('/api/state')
      .then((res) => res.json())
      .then((data) => {
        if (data.artworks) setArtworks(data.artworks);
        if (data.presentations) setPresentations(data.presentations);
        if (data.quizzes) setQuizzes(data.quizzes);
        if (data.forum) setForumMessages(data.forum);
        if (data.notifications) setNotifications(data.notifications);
        if (data.demoState) setDemoState(data.demoState);
      })
      .catch((err) => console.error('Failed to fetch initial state:', err));
  }, []);

  // Real-Time WebSocket connection
  useEffect(() => {
    let reconnectTimer: number | null = null;
    let isUnmounted = false;

    const connect = () => {
      if (isUnmounted) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
      };

      ws.onclose = () => {
        setWsConnected(false);
        if (!isUnmounted) {
          reconnectTimer = window.setTimeout(connect, 2500);
        }
      };

      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data) as { event: string; payload: unknown };
          if (msg.event === 'sync:init') {
            const init = msg.payload as { demoState?: DemoState };
            if (init.demoState) setDemoState(init.demoState);
          } else if (msg.event === 'demo:sync') {
            setDemoState(msg.payload as DemoState);
          } else if (msg.event === 'artwork:created') {
            const item = msg.payload as ArtworkSubmission;
            setArtworks((prev) =>
              prev.some((a) => a.id === item.id) ? prev : [item, ...prev]
            );
          } else if (msg.event === 'artwork:updated') {
            const item = msg.payload as ArtworkSubmission;
            setArtworks((prev) => prev.map((a) => (a.id === item.id ? item : a)));
          } else if (msg.event === 'artwork:appreciation') {
            const { artworkId, appreciation } = msg.payload as {
              artworkId: string;
              appreciation: ArtworkAppreciation;
            };
            setArtworks((prev) =>
              prev.map((a) => {
                if (a.id !== artworkId) return a;
                const existing = a.appreciations ?? [];
                if (existing.some((ap) => ap.id === appreciation.id)) return a;
                return { ...a, appreciations: [...existing, appreciation] };
              })
            );
          } else if (msg.event === 'presentation:created') {
            const item = msg.payload as PresentationSubmission;
            setPresentations((prev) =>
              prev.some((p) => p.id === item.id) ? prev : [item, ...prev]
            );
          } else if (msg.event === 'presentation:comment') {
            const { presentationId, comment } = msg.payload as {
              presentationId: string;
              comment: NonNullable<PresentationSubmission['comments']>[number];
            };
            setPresentations((prev) =>
              prev.map((p) => {
                if (p.id !== presentationId) return p;
                const existing = p.comments ?? [];
                if (existing.some((c) => c.id === comment.id)) return p;
                return { ...p, comments: [...existing, comment] };
              })
            );
          } else if (msg.event === 'quiz:created') {
            const item = msg.payload as QuizSubmission;
            setQuizzes((prev) =>
              prev.some((q) => q.id === item.id) ? prev : [item, ...prev]
            );
          } else if (msg.event === 'quiz:updated') {
            const item = msg.payload as QuizSubmission;
            setQuizzes((prev) => prev.map((q) => (q.id === item.id ? item : q)));
          } else if (msg.event === 'forum:created') {
            const item = msg.payload as ForumMessage;
            setForumMessages((prev) =>
              prev.some((m) => m.id === item.id) ? prev : [item, ...prev]
            );
          } else if (msg.event === 'forum:reply') {
            const { messageId, reply } = msg.payload as {
              messageId: string;
              reply: ForumMessage['replies'][number];
            };
            setForumMessages((prev) =>
              prev.map((m) => {
                if (m.id !== messageId) return m;
                if (m.replies.some((r) => r.id === reply.id)) return m;
                return { ...m, replies: [...m.replies, reply] };
              })
            );
          } else if (msg.event === 'notification:new') {
            const notif = msg.payload as TeacherNotification;
            setNotifications((prev) =>
              prev.some((n) => n.id === notif.id) ? prev : [notif, ...prev]
            );
            setLiveToast(notif);
            playNotificationChime();
            window.setTimeout(() => {
              setLiveToast((curr) => (curr?.id === notif.id ? null : curr));
            }, 6000);
          } else if (msg.event === 'notifications:updated') {
            setNotifications(msg.payload as TeacherNotification[]);
          }
          wsListenersRef.current.forEach((listener) => {
            listener(msg.event, msg.payload);
          });
        } catch {
          // Ignore invalid WS messages
        }
      };
    };

    connect();
    return () => {
      isUnmounted = true;
      if (reconnectTimer) window.clearTimeout(reconnectTimer);
      wsRef.current?.close();
    };
  }, []);

  const handleEnterApp = (newProfile: UserProfile) => {
    setProfile(newProfile);
    try {
      localStorage.setItem('bholang_profile', JSON.stringify(newProfile));
    } catch {
      // Ignore
    }
    setWelcomeOpen(false);
  };

  const handleGoogleLogin = useCallback(async (): Promise<boolean> => {
    setIsLoggingInGoogle(true);
    setAuthMessage('');
    try {
      const res = await signInWithGoogleWorkspace();
      if (res) {
        setGoogleUser(res.user);
        return true;
      }
      return false;
    } catch (err) {
      setAuthMessage(
        err instanceof Error
          ? err.message
          : 'Gagal masuk dengan Google. Pastikan pop-up browser diizinkan.'
      );
      return false;
    } finally {
      setIsLoggingInGoogle(false);
    }
  }, []);

  const handleGoogleLogout = async () => {
    await signOutGoogleWorkspace();
    setGoogleUser(null);
  };

  const handleUpdateDemoState = (patch: Partial<DemoState>) => {
    const next = { ...demoState, ...patch, updatedAt: new Date().toISOString() };
    setDemoState(next);
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ event: 'demo:update', payload: patch }));
    }
  };

  const handleMarkAllRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    await fetch('/api/notifications/read-all', { method: 'POST' }).catch(() => {});
  };

  const handleRequestSendEmail = useCallback(
    async (payload: { subject: string; summaryText: string; htmlBody: string }) => {
      setEmailStatus(null);
      if (!getCachedAccessToken()) {
        const loggedIn = await handleGoogleLogin();
        if (!loggedIn) return;
      }
      setPendingEmail({
        to: TEACHER_MONITOR_EMAIL,
        subject: payload.subject,
        summaryText: payload.summaryText,
        htmlBody: payload.htmlBody,
      });
    },
    [handleGoogleLogin]
  );

  const handleConfirmSendEmail = async () => {
    if (!pendingEmail || sendingEmail) return;
    setSendingEmail(true);
    try {
      await sendMonitoringEmail({
        to: pendingEmail.to,
        subject: pendingEmail.subject,
        htmlBody: pendingEmail.htmlBody,
      });
      setEmailStatus({
        ok: true,
        text: `Laporan pemantauan & penilaian berhasil dikirim ke ${pendingEmail.to}.`,
      });
      setPendingEmail(null);
    } catch (err) {
      setEmailStatus({
        ok: false,
        text: err instanceof Error ? err.message : 'Gagal mengirim laporan ke E-mail.',
      });
      setPendingEmail(null);
    } finally {
      setSendingEmail(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F7] text-[#171923] transition-colors duration-200 dark:bg-[#0D1017] dark:text-[#F1F5F9]">
      <EmailConfirmModal
        pending={pendingEmail}
        sending={sendingEmail}
        onCancel={() => setPendingEmail(null)}
        onConfirm={handleConfirmSendEmail}
      />

      <WelcomeModal
        open={welcomeOpen}
        initialProfile={profile}
        isDark={isDark}
        onToggleTheme={() => setIsDark((d) => !d)}
        onEnter={handleEnterApp}
      />

      <ExternalFocusModal
        resource={focusViewerResource}
        onClose={() => setFocusViewerResource(null)}
        onOpenExternal={(label, url) =>
          setExternalReturn({
            label,
            url,
            openedAt: Date.now(),
            returnedToTab: false,
          })
        }
      />

      <ExternalReturnBanner
        info={externalReturn}
        onReturnToWeb={() => {
          setExternalReturn(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateTab={setActiveTab}
      />

      <HeaderNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        profile={profile}
        onOpenProfileModal={() => setWelcomeOpen(true)}
        isDark={isDark}
        onToggleTheme={() => setIsDark((d) => !d)}
        soundOn={soundOn}
        onToggleSound={() => setSoundOn((s) => !s)}
        googleUser={googleUser}
        isLoggingInGoogle={isLoggingInGoogle}
        onGoogleLogin={handleGoogleLogin}
        onGoogleLogout={handleGoogleLogout}
        notifications={notifications}
        onMarkAllRead={handleMarkAllRead}
        wsConnected={wsConnected}
      />

      {authMessage && (
        <div className="mx-auto mt-3 flex w-full max-w-[1360px] items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex w-full items-center justify-between rounded-xl border border-[#DC2626]/30 bg-red-50 px-4 py-2.5 text-xs text-[#991B1B] dark:bg-red-950/30 dark:text-red-200">
            <span>{authMessage}</span>
            <button type="button" onClick={() => setAuthMessage('')}>
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {emailStatus && (
        <div className="mx-auto mt-3 flex w-full max-w-[1360px] items-center justify-between gap-3 px-4 sm:px-6">
          <div
            className={`flex w-full items-center justify-between rounded-xl border px-4 py-2.5 text-xs ${
              emailStatus.ok
                ? 'border-[#059669]/30 bg-emerald-50 text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-200'
                : 'border-[#DC2626]/30 bg-red-50 text-[#991B1B] dark:bg-red-950/30 dark:text-red-200'
            }`}
          >
            <span>{emailStatus.text}</span>
            <button type="button" onClick={() => setEmailStatus(null)}>
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Real-time Submission Toast */}
      {liveToast && (
        <div className="fixed right-5 bottom-5 z-50 max-w-sm rounded-xl border border-[#1D4ED8]/30 bg-white p-4 shadow-xl dark:border-[#3B82F6]/40 dark:bg-[#151923]">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <Bell className="mt-0.5 h-4 w-4 shrink-0 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <div className="text-xs">
                <div className="font-bold text-[#171923] dark:text-white">
                  Kiriman Baru: {liveToast.studentName} ({liveToast.className})
                </div>
                <div className="mt-0.5 font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                  {liveToast.title}
                </div>
                <p className="mt-0.5 text-[#4A505E] dark:text-[#A3B1C6]">{liveToast.detail}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setLiveToast(null)}
              aria-label="Tutup notifikasi"
              className="text-[#646B7A] hover:text-[#171923] dark:hover:text-white"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content Container */}
      <main className="mx-auto w-full max-w-[1360px] flex-1 px-4 py-7 sm:px-6">
        {activeTab === 'materi' && (
          <MateriSection
            onNavigateTab={setActiveTab}
            onOpenFocusViewer={setFocusViewerResource}
          />
        )}

        {activeTab === 'demo-praktik' && (
          <DemoPraktikSection
            profile={profile}
            demoState={demoState}
            onUpdateDemoState={handleUpdateDemoState}
            artworks={artworks}
            onArtworkSubmitted={(item) =>
              setArtworks((prev) =>
                prev.some((a) => a.id === item.id) ? prev : [item, ...prev]
              )
            }
            onRequireGoogleLogin={handleGoogleLogin}
            onRequestSendEmail={handleRequestSendEmail}
            wsConnected={wsConnected}
            sendWs={sendWs}
            subscribeWs={subscribeWs}
            onOpenFocusViewer={setFocusViewerResource}
          />
        )}

        {activeTab === 'galeri' && (
          <GaleriKelasSection
            profile={profile}
            artworks={artworks}
            onArtworkSubmitted={(item) =>
              setArtworks((prev) =>
                prev.some((a) => a.id === item.id) ? prev : [item, ...prev]
              )
            }
            onArtworkUpdated={(item) =>
              setArtworks((prev) => prev.map((a) => (a.id === item.id ? item : a)))
            }
            onAppreciationAdded={(artworkId, appreciation) =>
              setArtworks((prev) =>
                prev.map((a) => {
                  if (a.id !== artworkId) return a;
                  const existing = a.appreciations ?? [];
                  if (existing.some((ap) => ap.id === appreciation.id)) return a;
                  return { ...a, appreciations: [...existing, appreciation] };
                })
              )
            }
            onNavigateTab={setActiveTab}
            onRequireGoogleLogin={handleGoogleLogin}
            onRequestSendEmail={handleRequestSendEmail}
          />
        )}

        {activeTab === 'presentasi-diskusi' && (
          <PresentasiDiskusiSection
            profile={profile}
            presentations={presentations}
            onPresentationSubmitted={(item) =>
              setPresentations((prev) =>
                prev.some((p) => p.id === item.id) ? prev : [item, ...prev]
              )
            }
            onPresentationCommentAdded={(presentationId, comment) =>
              setPresentations((prev) =>
                prev.map((p) =>
                  p.id === presentationId &&
                  !(p.comments ?? []).some((c) => c.id === comment.id)
                    ? { ...p, comments: [...(p.comments ?? []), comment] }
                    : p
                )
              )
            }
            forumMessages={forumMessages}
            onForumCreated={(msg) =>
              setForumMessages((prev) =>
                prev.some((m) => m.id === msg.id) ? prev : [msg, ...prev]
              )
            }
            onForumReply={(messageId, reply) =>
              setForumMessages((prev) =>
                prev.map((m) =>
                  m.id === messageId && !m.replies.some((r) => r.id === reply.id)
                    ? { ...m, replies: [...m.replies, reply] }
                    : m
                )
              )
            }
            onRequireGoogleLogin={handleGoogleLogin}
            onRequestSendEmail={handleRequestSendEmail}
          />
        )}

        {activeTab === 'kuis' && (
          <KuisSection
            profile={profile}
            quizSubmissions={quizzes}
            artworkCount={artworks.filter((a) => a.studentName === profile.name).length}
            presentationCount={
              presentations.filter((p) => p.studentName === profile.name).length
            }
            onQuizSubmitted={(item) =>
              setQuizzes((prev) =>
                prev.some((q) => q.id === item.id) ? prev : [item, ...prev]
              )
            }
            onQuizUpdated={(item) =>
              setQuizzes((prev) => prev.map((q) => (q.id === item.id ? item : q)))
            }
            onRequireGoogleLogin={handleGoogleLogin}
            onRequestSendEmail={handleRequestSendEmail}
            onOpenFocusViewer={setFocusViewerResource}
            onBackToMateri={() => setActiveTab('materi')}
          />
        )}

        {activeTab === 'analitik' && (
          <AnalitikSection
            profile={profile}
            quizSubmissions={quizzes}
            artworks={artworks}
            presentations={presentations}
            notifications={notifications}
            onMarkAllRead={handleMarkAllRead}
            onQuizUpdated={(item) =>
              setQuizzes((prev) => prev.map((q) => (q.id === item.id ? item : q)))
            }
            onArtworkUpdated={(item) =>
              setArtworks((prev) => prev.map((a) => (a.id === item.id ? item : a)))
            }
            onRequireGoogleLogin={handleGoogleLogin}
            onRequestSendEmail={handleRequestSendEmail}
          />
        )}
      </main>

      {/* Quiet Editorial Footer */}
      <footer className="border-t border-[#E5E0D8] bg-white py-5 text-xs text-[#646B7A] dark:border-[#272E3F] dark:bg-[#151923] dark:text-[#94A3B8]">
        <div className="mx-auto flex max-w-[1360px] flex-wrap items-center justify-between gap-4 px-4 sm:px-6">
          <div>
            <span className="font-semibold text-[#171923] dark:text-white">BHOLANG RUPA</span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>Materi Unsur-Unsur &amp; Prinsip Seni Rupa Kelas X KD 3.1</span>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={EBOOK_URL}
              target="_blank"
              rel="noreferrer"
              data-resource-label="E-Book Kemendikdasmen KD 3.1"
              className="inline-flex items-center gap-1 hover:text-[#1D4ED8] dark:hover:text-[#60A5FA]"
            >
              <span>E-Book Kemendikdasmen</span>
              <ExternalLink className="h-3 w-3" />
            </a>
            <a
              href={DRIVE_FOLDER_URL}
              target="_blank"
              rel="noreferrer"
              data-resource-label="Folder Google Drive Kelas"
              className="inline-flex items-center gap-1 hover:text-[#1D4ED8] dark:hover:text-[#60A5FA]"
            >
              <span>Folder Google Drive Kelas</span>
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
