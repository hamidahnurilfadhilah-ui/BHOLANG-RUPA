export type UserRole = 'siswa' | 'guru';

export interface UserProfile {
  name: string;
  role: UserRole;
  className: string;
}

export type ActiveTab =
  | 'materi'
  | 'demo-praktik'
  | 'galeri'
  | 'presentasi-diskusi'
  | 'kuis'
  | 'analitik';

export type BloomLevel = 'C1' | 'C2' | 'C3' | 'C4' | 'C5' | 'C6';

export interface SlideItem {
  id: string;
  index: string;
  category: 'Pengantar' | 'Unsur Seni Rupa' | 'Prinsip Seni Rupa' | 'Analisis Karya';
  title: string;
  subtitle: string;
  summary: string;
  points: { label: string; detail: string }[];
  visualType:
    | 'intro'
    | 'titik-garis'
    | 'bidang-bentuk'
    | 'ruang-warna'
    | 'tekstur-gelap'
    | 'kesatuan-keseimbangan'
    | 'irama-penekanan'
    | 'proporsi-keselarasan'
    | 'analisis'
    | 'ringkasan';
  imageUrl?: string;
}

export interface QuizQuestion {
  id: string;
  bloomLevel: BloomLevel;
  category: 'Unsur Seni Rupa' | 'Prinsip Seni Rupa';
  topic: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  visualCue?: 'garis' | 'warna' | 'keseimbangan' | 'irama' | 'penekanan' | 'gelap-terang';
}

export interface EssayQuestion {
  id: string;
  bloomLevel: BloomLevel;
  bloomLabel: string;
  category: 'Unsur Seni Rupa' | 'Prinsip Seni Rupa' | 'Terpadu';
  topic: string;
  question: string;
  rubricHint: string;
}

export interface EssayAnswerSubmission {
  questionId: string;
  bloomLevel: BloomLevel;
  question: string;
  answer: string;
  teacherScore?: number;
  teacherFeedback?: string;
}

export interface QuizAnswerDetail {
  questionId: string;
  selectedIndex: number;
  isCorrect: boolean;
}

export interface QuizSubmission {
  id: string;
  studentName: string;
  className: string;
  topic: string;
  score: number;
  unsurScore: number;
  prinsipScore: number;
  correctCount: number;
  totalQuestions: number;
  predicate: string;
  notes: string;
  essayAnswers?: EssayAnswerSubmission[];
  essayScore?: number;
  driveSynced: boolean;
  spreadsheetUrl?: string;
  createdAt: string;
}

export interface ArtworkAppreciation {
  id: string;
  authorName: string;
  authorRole: UserRole;
  badge?: string;
  message: string;
  createdAt: string;
}

export interface ArtworkSubmission {
  id: string;
  studentName: string;
  className: string;
  title: string;
  description: string;
  imageDataUrl: string;
  aiCritique?: string;
  driveFileId?: string;
  driveWebViewLink?: string;
  pinned?: boolean;
  pinnedBy?: string;
  pinnedAt?: string;
  likedBy?: string[];
  appreciations?: ArtworkAppreciation[];
  createdAt: string;
}

export interface PresentationSlide {
  id: string;
  heading: string;
  bullets: string[];
  note: string;
  accentColor: string;
}

export interface ParsedPptxSlide {
  slideNumber: number;
  title: string;
  texts: string[];
  images: string[];
}

export interface PresentationComment {
  id: string;
  authorName: string;
  authorRole: UserRole;
  content: string;
  createdAt: string;
}

export interface PresentationSubmission {
  id: string;
  studentName: string;
  className: string;
  title: string;
  topic: string;
  mode: 'deck' | 'file';
  slides?: PresentationSlide[];
  parsedSlides?: ParsedPptxSlide[];
  fileName?: string;
  fileMimeType?: string;
  fileDataUrl?: string;
  driveFileId?: string;
  driveWebViewLink?: string;
  comments?: PresentationComment[];
  createdAt: string;
}

export interface ForumReply {
  id: string;
  authorName: string;
  authorRole: UserRole;
  content: string;
  createdAt: string;
}

export interface ForumMessage {
  id: string;
  authorName: string;
  authorRole: UserRole;
  className: string;
  topicTag: string;
  title: string;
  content: string;
  replies: ForumReply[];
  createdAt: string;
}

export interface TeacherNotification {
  id: string;
  type: 'artwork' | 'quiz' | 'presentation' | 'forum';
  studentName: string;
  className: string;
  title: string;
  detail: string;
  driveLink?: string;
  read: boolean;
  createdAt: string;
}

export interface DemoState {
  mode: 'unsur' | 'prinsip';
  activeConcept:
    | 'titik-garis'
    | 'warna'
    | 'gelap-terang'
    | 'keseimbangan'
    | 'irama'
    | 'penekanan';
  density: number;
  lightAngle: number;
  primaryHue: number;
  customColor?: string;
  studentColor?: string;
  teacherColor?: string;
  selectedPrimaries?: string[];
  balanceMode: 'simetris' | 'asimetris' | 'radial';
  rhythmCount: number;
  emphasisStrength: number;
  teacherNote: string;
  updatedBy: string;
  updatedAt: string;
}

export interface SubjectScoreComparison {
  subject: string;
  classAverage: number;
  studentScore: number;
}

export type CollabToolType =
  | 'brush'
  | 'pencil'
  | 'calligraphy'
  | 'stipple'
  | 'crayon'
  | 'line'
  | 'rect'
  | 'circle'
  | 'eraser';

export type CollabBlendOp =
  | 'source-over'
  | 'multiply'
  | 'screen'
  | 'overlay'
  | 'darken'
  | 'lighten';

export type CollabMirrorMode = 'none' | 'horizontal' | 'vertical' | 'quad';

export interface CollabStroke {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  color: string;
  tool: CollabToolType;
  size: number;
  opacity: number;
  blendMode: CollabBlendOp;
  mirrorMode: CollabMirrorMode;
  points: { x: number; y: number }[];
  createdAt: string;
}

export interface CollabParticipant {
  userId: string;
  userName: string;
  className: string;
  color: string;
}

export interface CollabCursor {
  userId: string;
  userName: string;
  color: string;
  x: number;
  y: number;
  lastSeen: number;
}

