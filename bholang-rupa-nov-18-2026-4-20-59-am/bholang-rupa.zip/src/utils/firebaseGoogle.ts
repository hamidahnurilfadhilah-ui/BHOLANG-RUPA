import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  type User,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { DRIVE_FOLDER_ID } from '../data/learningContent';
import type { QuizSubmission } from '../types';

export const WORKSPACE_SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/gmail.send',
];

const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
WORKSPACE_SCOPES.forEach((scope) => provider.addScope(scope));

let isSigningIn = false;
let cachedAccessToken: string | null = null;

export function initGoogleAuth(
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) {
  return onAuthStateChanged(auth, (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        onAuthSuccess?.(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        onAuthFailure?.();
      }
    } else {
      cachedAccessToken = null;
      onAuthFailure?.();
    }
  });
}

export async function signInWithGoogleWorkspace(): Promise<{
  user: User;
  accessToken: string;
} | null> {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Gagal mendapatkan izin akses Google Drive & Sheets.');
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } finally {
    isSigningIn = false;
  }
}

export function getCachedAccessToken(): string | null {
  return cachedAccessToken;
}

export async function signOutGoogleWorkspace(): Promise<void> {
  await auth.signOut();
  cachedAccessToken = null;
}

export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  webViewLink?: string;
  webContentLink?: string;
  createdTime?: string;
  size?: string;
}

export async function uploadBlobToDriveFolder(
  blob: Blob,
  fileName: string,
  mimeType: string,
  folderId: string = DRIVE_FOLDER_ID
): Promise<DriveFileItem> {
  const token = cachedAccessToken;
  if (!token) {
    throw new Error('Silakan masuk dengan akun Google terlebih dahulu untuk menyimpan ke Google Drive.');
  }

  const metadata = {
    name: fileName,
    parents: [folderId],
    mimeType,
  };

  const formData = new FormData();
  formData.append(
    'metadata',
    new Blob([JSON.stringify(metadata)], { type: 'application/json' })
  );
  formData.append('file', blob, fileName);

  const res = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id,name,mimeType,webViewLink,webContentLink,createdTime',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    }
  );

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Upload Google Drive gagal (${res.status}): ${errText}`);
  }

  return (await res.json()) as DriveFileItem;
}

export async function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  const response = await fetch(dataUrl);
  return await response.blob();
}

const SPREADSHEET_TITLE = 'Evaluasi Hasil Belajar - BHOLANG RUPA';

async function findOrCreateQuizSpreadsheet(
  token: string,
  folderId: string = DRIVE_FOLDER_ID
): Promise<{ spreadsheetId: string; spreadsheetUrl: string; sheetTitle: string }> {
  const q = encodeURIComponent(
    `name='${SPREADSHEET_TITLE}' and mimeType='application/vnd.google-apps.spreadsheet' and '${folderId}' in parents and trashed=false`
  );

  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=files(id,name,webViewLink)`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );

  if (!searchRes.ok) {
    throw new Error(`Gagal mencari spreadsheet di Google Drive (${searchRes.status}).`);
  }

  const searchJson = (await searchRes.json()) as {
    files?: { id: string; name: string; webViewLink?: string }[];
  };

  if (searchJson.files && searchJson.files.length > 0) {
    const existing = searchJson.files[0];
    const metaRes = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${existing.id}?fields=spreadsheetUrl,sheets.properties`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    if (!metaRes.ok) {
      throw new Error('Gagal membaca metadata tab Google Sheets.');
    }
    const meta = (await metaRes.json()) as {
      spreadsheetUrl?: string;
      sheets?: { properties?: { title?: string } }[];
    };
    const sheetTitle = meta.sheets?.[0]?.properties?.title || 'Sheet1';
    return {
      spreadsheetId: existing.id,
      spreadsheetUrl:
        meta.spreadsheetUrl ||
        existing.webViewLink ||
        `https://docs.google.com/spreadsheets/d/${existing.id}`,
      sheetTitle,
    };
  }

  // Create spreadsheet inside target Drive folder
  const createDriveRes = await fetch(
    'https://www.googleapis.com/drive/v3/files?supportsAllDrives=true&fields=id,name,webViewLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: SPREADSHEET_TITLE,
        mimeType: 'application/vnd.google-apps.spreadsheet',
        parents: [folderId],
      }),
    }
  );

  if (!createDriveRes.ok) {
    const errText = await createDriveRes.text();
    throw new Error(`Gagal membuat Google Sheets di folder tujuan (${createDriveRes.status}): ${errText}`);
  }

  const created = (await createDriveRes.json()) as { id: string; webViewLink?: string };

  // Fetch actual sheet metadata (never hardcode tab name blindly)
  const metaRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${created.id}?fields=spreadsheetUrl,sheets.properties`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
  const meta = (await metaRes.json()) as {
    spreadsheetUrl?: string;
    sheets?: { properties?: { sheetId?: number; title?: string } }[];
  };
  const sheetId = meta.sheets?.[0]?.properties?.sheetId ?? 0;
  const sheetTitle = meta.sheets?.[0]?.properties?.title || 'Sheet1';

  // Write clean header row
  const headers = [
    [
      'Tanggal & Waktu',
      'Nama Siswa',
      'Kelas',
      'Topik Evaluasi',
      'Skor Akhir',
      'Skor Unsur (%)',
      'Skor Prinsip (%)',
      'Benar / Total',
      'Predikat',
      'Catatan Evaluasi',
    ],
  ];

  await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${created.id}/values/${encodeURIComponent(
      `${sheetTitle}!A1:J1`
    )}?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: headers }),
    }
  );

  // Format header row cleanly (indigo header, bold white text, freeze top row, auto-resize)
  await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${created.id}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      requests: [
        {
          repeatCell: {
            range: { sheetId, startRowIndex: 0, endRowIndex: 1 },
            cell: {
              userEnteredFormat: {
                backgroundColor: { red: 0.11, green: 0.3, blue: 0.85 },
                textFormat: {
                  foregroundColor: { red: 1, green: 1, blue: 1 },
                  bold: true,
                  fontSize: 10,
                },
                horizontalAlignment: 'CENTER',
              },
            },
            fields: 'userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)',
          },
        },
        {
          updateSheetProperties: {
            properties: {
              sheetId,
              gridProperties: { frozenRowCount: 1 },
            },
            fields: 'gridProperties.frozenRowCount',
          },
        },
        {
          autoResizeDimensions: {
            dimensions: {
              sheetId,
              dimension: 'COLUMNS',
              startIndex: 0,
              endIndex: 10,
            },
          },
        },
      ],
    }),
  });

  return {
    spreadsheetId: created.id,
    spreadsheetUrl:
      meta.spreadsheetUrl ||
      created.webViewLink ||
      `https://docs.google.com/spreadsheets/d/${created.id}`,
    sheetTitle,
  };
}

export async function appendQuizScoreToSpreadsheet(
  submission: QuizSubmission,
  folderId: string = DRIVE_FOLDER_ID
): Promise<{ spreadsheetUrl: string }> {
  const token = cachedAccessToken;
  if (!token) {
    throw new Error('Akun Google belum terhubung. Masuk dengan Google untuk menyimpan otomatis ke Sheets.');
  }

  const { spreadsheetId, spreadsheetUrl, sheetTitle } = await findOrCreateQuizSpreadsheet(
    token,
    folderId
  );

  const formattedDate = new Date(submission.createdAt).toLocaleString('id-ID', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const essaySummary =
    submission.essayAnswers && submission.essayAnswers.length > 0
      ? submission.essayAnswers
          .filter((e) => e.answer.trim())
          .map((e) => `[${e.bloomLevel}] ${e.answer.trim().slice(0, 120)}`)
          .join(' | ')
      : 'Tidak ada esai';

  const row = [
    [
      formattedDate,
      submission.studentName,
      submission.className,
      submission.topic,
      submission.score,
      submission.unsurScore,
      submission.prinsipScore,
      `${submission.correctCount} / ${submission.totalQuestions}`,
      submission.predicate,
      `${submission.notes} || Esai: ${essaySummary}`,
    ],
  ];

  const appendRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(
      `${sheetTitle}!A1`
    )}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: row }),
    }
  );

  if (!appendRes.ok) {
    const errText = await appendRes.text();
    throw new Error(`Gagal menambahkan baris nilai ke Google Sheets (${appendRes.status}): ${errText}`);
  }

  return { spreadsheetUrl };
}

export async function listDriveFolderFiles(
  folderId: string = DRIVE_FOLDER_ID
): Promise<DriveFileItem[]> {
  const token = cachedAccessToken;
  if (!token) return [];

  const q = encodeURIComponent(`'${folderId}' in parents and trashed=false`);
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=createdTime desc&pageSize=30&supportsAllDrives=true&includeItemsFromAllDrives=true&fields=files(id,name,mimeType,webViewLink,webContentLink,createdTime,size)`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
  if (!res.ok) {
    throw new Error(`Gagal membaca isi folder Google Drive (${res.status}).`);
  }
  const data = (await res.json()) as { files?: DriveFileItem[] };
  return data.files ?? [];
}

function encodeBase64Utf8(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 1) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function encodeBase64UrlUtf8(str: string): string {
  return encodeBase64Utf8(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export async function sendMonitoringEmail({
  to,
  subject,
  htmlBody,
}: {
  to: string;
  subject: string;
  htmlBody: string;
}): Promise<{ id: string }> {
  const token = cachedAccessToken;
  if (!token) {
    throw new Error('Akun Google belum terhubung. Masuk dengan Google untuk mengirim laporan via Gmail.');
  }

  const encodedSubject = `=?UTF-8?B?${encodeBase64Utf8(subject)}?=`;
  const rawMime = [
    `To: ${to}`,
    `Subject: ${encodedSubject}`,
    'MIME-Version: 1.0',
    'Content-Type: text/html; charset="UTF-8"',
    '',
    htmlBody,
  ].join('\r\n');

  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      raw: encodeBase64UrlUtf8(rawMime),
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gagal mengirim laporan ke E-mail (${res.status}): ${errText}`);
  }

  return (await res.json()) as { id: string };
}
