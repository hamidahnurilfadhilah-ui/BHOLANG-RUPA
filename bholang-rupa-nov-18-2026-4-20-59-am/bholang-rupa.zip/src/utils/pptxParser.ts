import JSZip from 'jszip';
import type { ParsedPptxSlide } from '../types';

function extractSlideTexts(xmlString: string): string[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlString, 'application/xml');
  const paragraphs = Array.from(doc.getElementsByTagName('a:p'));
  const lines: string[] = [];

  for (const p of paragraphs) {
    const runs = Array.from(p.getElementsByTagName('a:t'));
    const text = runs
      .map((r) => r.textContent || '')
      .join('')
      .trim();
    if (text) {
      lines.push(text);
    }
  }
  return lines;
}

function getMimeFromExt(path: string): string {
  const lower = path.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) return 'image/jpeg';
  if (lower.endsWith('.gif')) return 'image/gif';
  if (lower.endsWith('.svg')) return 'image/svg+xml';
  if (lower.endsWith('.webp')) return 'image/webp';
  return 'image/png';
}

export async function parsePptxFileToSlides(file: File | Blob): Promise<ParsedPptxSlide[]> {
  try {
    const zip = await JSZip.loadAsync(file);
    const slideFiles = Object.keys(zip.files)
      .filter((name) => /^ppt\/slides\/slide\d+\.xml$/i.test(name))
      .sort((a, b) => {
        const na = parseInt(a.match(/\d+/)?.[0] || '0', 10);
        const nb = parseInt(b.match(/\d+/)?.[0] || '0', 10);
        return na - nb;
      });

    const parsed: ParsedPptxSlide[] = [];

    for (let i = 0; i < slideFiles.length; i++) {
      const slidePath = slideFiles[i];
      const slideNum = parseInt(slidePath.match(/\d+/)?.[0] || String(i + 1), 10);
      const xml = await zip.files[slidePath].async('text');
      const allTexts = extractSlideTexts(xml);

      // Extract linked images via slide rels if available
      const relsPath = `ppt/slides/_rels/slide${slideNum}.xml.rels`;
      const images: string[] = [];
      if (zip.files[relsPath]) {
        const relsXml = await zip.files[relsPath].async('text');
        const relDoc = new DOMParser().parseFromString(relsXml, 'application/xml');
        const rels = Array.from(relDoc.getElementsByTagName('Relationship'));
        for (const rel of rels) {
          const target = rel.getAttribute('Target') || '';
          if (target.includes('media/')) {
            const mediaPath = target.startsWith('../')
              ? `ppt/${target.replace(/^\.\.\//, '')}`
              : target.startsWith('/')
                ? target.slice(1)
                : `ppt/slides/${target}`;
            const mediaEntry = zip.files[mediaPath];
            if (mediaEntry) {
              const base64 = await mediaEntry.async('base64');
              const mime = getMimeFromExt(mediaPath);
              images.push(`data:${mime};base64,${base64}`);
            }
          }
        }
      }

      const [firstLine, ...restLines] = allTexts;
      parsed.push({
        slideNumber: slideNum,
        title: firstLine || `Slide ${slideNum}`,
        texts: restLines,
        images: images.slice(0, 4),
      });
    }

    return parsed;
  } catch (err) {
    console.warn('PPTX parse failed:', err);
    return [];
  }
}
