import { jsPDF } from 'jspdf';
import type { QuizSubmission, SubjectScoreComparison } from '../types';

export function exportStudentReportPdf(params: {
  studentName: string;
  className: string;
  submissions: QuizSubmission[];
  subjectComparisons: SubjectScoreComparison[];
  artworkCount: number;
  presentationCount: number;
}) {
  const {
    studentName,
    className,
    submissions,
    subjectComparisons,
    artworkCount,
    presentationCount,
  } = params;

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  // Header band
  doc.setFillColor(29, 78, 216);
  doc.rect(0, 0, 210, 32, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('BHOLANG RUPA', 16, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Laporan Evaluasi Hasil Belajar — Unsur-Unsur & Prinsip Seni Rupa (KD 3.1)', 16, 23);

  // Student info
  doc.setTextColor(23, 25, 35);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Identitas Siswa', 16, 44);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Nama Lengkap   : ${studentName}`, 16, 51);
  doc.text(`Kelas / Rombel : ${className}`, 16, 57);
  doc.text(
    `Tanggal Cetak  : ${new Date().toLocaleDateString('id-ID', {
      dateStyle: 'long',
    })}`,
    16,
    63
  );

  // Summary box
  const avgQuiz =
    submissions.length > 0
      ? Math.round(submissions.reduce((acc, s) => acc + s.score, 0) / submissions.length)
      : 0;
  const bestQuiz =
    submissions.length > 0 ? Math.max(...submissions.map((s) => s.score)) : 0;

  doc.setDrawColor(215, 210, 200);
  doc.setFillColor(248, 247, 244);
  doc.roundedRect(16, 70, 178, 24, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text('Rata-rata Kuis', 24, 79);
  doc.text('Skor Tertinggi', 70, 79);
  doc.text('Karya Praktik', 118, 79);
  doc.text('Presentasi', 162, 79);

  doc.setFontSize(14);
  doc.setTextColor(29, 78, 216);
  doc.text(`${avgQuiz}`, 24, 88);
  doc.text(`${bestQuiz}`, 70, 88);
  doc.text(`${artworkCount}`, 118, 88);
  doc.text(`${presentationCount}`, 162, 88);

  // Quiz Table
  let y = 106;
  doc.setTextColor(23, 25, 35);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Riwayat Evaluasi Kuis Interaktif', 16, y);
  y += 6;

  doc.setFillColor(238, 242, 255);
  doc.rect(16, y, 178, 8, 'F');
  doc.setFontSize(9);
  doc.text('Tanggal', 19, y + 5.5);
  doc.text('Topik Evaluasi', 55, y + 5.5);
  doc.text('Unsur', 120, y + 5.5);
  doc.text('Prinsip', 138, y + 5.5);
  doc.text('Skor', 158, y + 5.5);
  doc.text('Predikat', 173, y + 5.5);
  y += 10;

  doc.setFont('helvetica', 'normal');
  if (submissions.length === 0) {
    doc.text('Belum ada riwayat kuis yang diselesaikan.', 19, y + 4);
    y += 10;
  } else {
    submissions.slice(0, 8).forEach((s) => {
      const dateLabel = new Date(s.createdAt).toLocaleDateString('id-ID');
      doc.text(dateLabel, 19, y + 4);
      doc.text(s.topic.slice(0, 32), 55, y + 4);
      doc.text(`${s.unsurScore}%`, 120, y + 4);
      doc.text(`${s.prinsipScore}%`, 138, y + 4);
      doc.text(`${s.score}`, 158, y + 4);
      doc.text(s.predicate, 173, y + 4);
      doc.setDrawColor(230, 228, 222);
      doc.line(16, y + 6.5, 194, y + 6.5);
      y += 8;
    });
  }

  // Subject comparison
  y += 8;
  if (y > 230) {
    doc.addPage();
    y = 20;
  }
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('Perbandingan Performa per Mata Pelajaran / Kompetensi', 16, y);
  y += 7;

  subjectComparisons.forEach((row) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.text(row.subject, 16, y);
    doc.text(`Siswa: ${row.studentScore}  |  Rata-rata Kelas: ${row.classAverage}`, 130, y);

    // Mini bar visualization
    doc.setFillColor(230, 232, 236);
    doc.rect(16, y + 2, 100, 3, 'F');
    doc.setFillColor(29, 78, 216);
    doc.rect(16, y + 2, Math.min(100, row.studentScore), 3, 'F');
    y += 10;
  });

  // Footer
  doc.setFontSize(8.5);
  doc.setTextColor(110, 115, 125);
  doc.text(
    'Dokumen ini dibuat otomatis oleh platform pembelajaran BHOLANG RUPA.',
    16,
    285
  );

  const safeName = studentName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
  doc.save(`Laporan-Nilai-BHOLANG-RUPA-${safeName || 'siswa'}.pdf`);
}
