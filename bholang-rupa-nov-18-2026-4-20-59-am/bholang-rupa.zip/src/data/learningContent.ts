import type { EssayQuestion, QuizQuestion, SlideItem, SubjectScoreComparison } from '../types';

export const DRIVE_FOLDER_ID = '1TkzEz7v37vqse7NDGpANNhaGbV5pUdJ0';
export const DRIVE_FOLDER_URL =
  'https://drive.google.com/drive/folders/1TkzEz7v37vqse7NDGpANNhaGbV5pUdJ0?usp=sharing';
export const TEACHER_MONITOR_EMAIL = 'hamidahnurilfadhilah@gmail.com';

export const EBOOK_URL =
  'https://repositori.kemendikdasmen.go.id/19389/1/Kelas%20X_Seni%20Budaya%28Seni%20Rupa%29_KD%203.1.pdf';

export const WAYGROUND_QUIZ_URL =
  'https://wayground.com/activity/admin/quiz/6ad8fbc355bf171aa987d635';

export const ARTVENTURE_URL =
  'https://murid.kemendikdasmen.go.id/sumber-belajar/materi/Gim%20Edukasi/artventure-unsur-rupa-prinsip-desain-4c880e67-04d4-4b25-933f-07056949c099';

export const YOUTUBE_VIDEOS = [
  {
    id: '0zu9Sh3eZ0I',
    title: 'Unsur-Unsur Seni Rupa & Penerapannya pada Karya',
    duration: 'Materi Video 01',
    url: 'https://youtu.be/0zu9Sh3eZ0I?si=dFK6bNehUHhht_Kt',
    embedUrl: 'https://www.youtube.com/embed/0zu9Sh3eZ0I?rel=0',
    focus: 'Titik, Garis, Bidang, Bentuk, Ruang, Warna, Tekstur, dan Gelap-Terang',
  },
  {
    id: 'g15tFYyiSlc',
    title: 'Prinsip-Prinsip Seni Rupa dalam Komposisi Visual',
    duration: 'Materi Video 02',
    url: 'https://youtu.be/g15tFYyiSlc?si=O2THDGsWbws5O9ed',
    embedUrl: 'https://www.youtube.com/embed/g15tFYyiSlc?rel=0',
    focus: 'Kesatuan, Keseimbangan, Irama, Penekanan, Proporsi, dan Keselarasan',
  },
];

export const SLIDES: SlideItem[] = [
  {
    id: 'slide-1',
    index: '01 / 10',
    category: 'Pengantar',
    title: 'Fondasi Bahasa Visual Seni Rupa (KD 3.1)',
    subtitle: 'Memahami bagaimana unsur fisik dan prinsip komposisi membentuk karya bermakna.',
    summary:
      'Setiap karya seni rupa dua dimensi maupun tiga dimensi tersusun dari unsur-unsur dasar (elemen visual) yang ditata menggunakan prinsip-prinsip seni rupa agar menghasilkan kesatuan estetik.',
    points: [
      {
        label: 'Unsur Seni Rupa',
        detail: 'Bahan baku visual: titik, garis, bidang, bentuk, ruang, warna, tekstur, dan gelap-terang.',
      },
      {
        label: 'Prinsip Seni Rupa',
        detail: 'Aturan penataan: kesatuan, keseimbangan, irama, penekanan, proporsi, dan keselarasan.',
      },
      {
        label: 'Tujuan Pembelajaran',
        detail: 'Mampu menganalisis karya rupa secara kritis dan menciptakan karya gambar harmonis.',
      },
    ],
    visualType: 'intro',
    imageUrl: '/src/assets/images/hero_art_studio_1794935614952.jpg',
  },
  {
    id: 'slide-2',
    index: '02 / 10',
    category: 'Unsur Seni Rupa',
    title: 'Titik (Bintik) dan Garis',
    subtitle: 'Elemen paling dasar yang melahirkan kontur, arah gerak, dan ekspresi.',
    summary:
      'Titik adalah unsur terkecil seni rupa. Ketika titik bergerak atau berjajar rapat, terbentuklah garis dengan karakter psikologis yang beragam.',
    points: [
      {
        label: 'Garis Lurus & Tegas',
        detail: 'Memberi kesan kokoh, stabil, formal, dan terstruktur (vertikal maupun horizontal).',
      },
      {
        label: 'Garis Lengkung & S-Curve',
        detail: 'Menghadirkan rasa luwes, dinamis, lembut, dan mengalir alami.',
      },
      {
        label: 'Garis Zig-Zag & Diagonal',
        detail: 'Menciptakan energi, ketegangan, gerak cepat, dan dinamika visual.',
      },
    ],
    visualType: 'titik-garis',
    imageUrl: '/src/assets/images/unsur_seni_rupa_plate_1794935615333.jpg',
  },
  {
    id: 'slide-3',
    index: '03 / 10',
    category: 'Unsur Seni Rupa',
    title: 'Bidang dan Bentuk',
    subtitle: 'Dari keluasan dwimatra (2D) menuju volume trimatra (3D).',
    summary:
      'Bidang terbentuk dari pertemuan beberapa garis yang menutup area dua dimensi. Bentuk (form) menghadirkan kesan volume atau kedalaman tiga dimensi.',
    points: [
      {
        label: 'Bidang Geometris',
        detail: 'Segitiga, persegi, lingkaran, dan trapesium yang terukur secara matematis.',
      },
      {
        label: 'Bidang Organis',
        detail: 'Bentuk bebas meniru alam seperti daun, ombak, awan, atau siluet tubuh.',
      },
      {
        label: 'Bentuk Plastis (3D)',
        detail: 'Memiliki panjang, lebar, dan tinggi—baik nyata (patung) maupun ilusi (kubus terarsir).',
      },
    ],
    visualType: 'bidang-bentuk',
  },
  {
    id: 'slide-4',
    index: '04 / 10',
    category: 'Unsur Seni Rupa',
    title: 'Ruang dan Teori Warna',
    subtitle: 'Kedalaman komposisi serta spektrum psikologi warna.',
    summary:
      'Ruang terbagi menjadi ruang positif (objek) dan ruang negatif (latar). Warna memperkuat suasana emosional melalui klasifikasi primer, sekunder, dan tersier.',
    points: [
      {
        label: 'Warna Primer & Sekunder',
        detail: 'Primer (Merah, Kuning, Biru); Sekunder hasil campuran primer (Oranye, Hijau, Ungu).',
      },
      {
        label: 'Kontras & Harmoni Warna',
        detail: 'Komplementer (berseberangan pada roda warna) memberi kontras kuat; analogus memberi tenang.',
      },
      {
        label: 'Ruang Positif & Negatif',
        detail: 'Keseimbangan area terisi dan area kosong menjaga karya tidak terasa sesak.',
      },
    ],
    visualType: 'ruang-warna',
  },
  {
    id: 'slide-5',
    index: '05 / 10',
    category: 'Unsur Seni Rupa',
    title: 'Tekstur dan Gelap-Terang (Value)',
    subtitle: 'Kualitas permukaan indrawi dan ilusi pencahayaan tiga dimensi.',
    summary:
      'Tekstur adalah nilai raba permukaan benda (nyata atau semu). Gelap-terang (chiaroscuro) menentukan di mana cahaya jatuh dan menciptakan kesan volume.',
    points: [
      {
        label: 'Tekstur Nyata vs Semu',
        detail: 'Tekstur nyata terasa saat disentuh (impasto/kolase); tekstur semu terlihat kasar namun rata.',
      },
      {
        label: 'Skala Nada (Value Scale)',
        detail: 'Gradasi dari highlight, midtone, core shadow, hingga cast shadow.',
      },
      {
        label: 'Teknik Arsiran',
        detail: 'Hatching, cross-hatching, stippling (titik), dan dusel membangun volume plastis.',
      },
    ],
    visualType: 'tekstur-gelap',
  },
  {
    id: 'slide-6',
    index: '06 / 10',
    category: 'Prinsip Seni Rupa',
    title: 'Kesatuan (Unity) dan Keseimbangan (Balance)',
    subtitle: 'Menyatukan seluruh elemen agar terasa utuh dan stabil.',
    summary:
      'Kesatuan membuat semua unsur saling mendukung sebagai satu pesan utuh. Keseimbangan mengatur bobot visual kiri-kanan atau atas-bawah karya.',
    points: [
      {
        label: 'Keseimbangan Simetris',
        detail: 'Elemen kanan dan kiri cerminan seimbang—memberi kesan resmi, agung, dan tenang.',
      },
      {
        label: 'Keseimbangan Asimetris',
        detail: 'Bobot visual tetap seimbang walau bentuknya berbeda ukuran, warna, atau posisi.',
      },
      {
        label: 'Keseimbangan Radial',
        detail: 'Susunan unsur memancar dari satu titik pusat, lazim pada mandala atau ornamen.',
      },
    ],
    visualType: 'kesatuan-keseimbangan',
    imageUrl: '/src/assets/images/prinsip_seni_rupa_plate_1794935615550.jpg',
  },
  {
    id: 'slide-7',
    index: '07 / 10',
    category: 'Prinsip Seni Rupa',
    title: 'Irama (Rhythm) dan Penekanan (Emphasis)',
    subtitle: 'Menggerakkan pandangan mata dan menonjolkan pusat perhatian.',
    summary:
      'Irama lahir dari pengulangan unsur secara teratur atau progresif. Penekanan (center of interest) mengarahkan mata pengamat langsung pada fokus utama karya.',
    points: [
      {
        label: 'Irama Repetitif & Progresif',
        detail: 'Pengulangan pola dengan variasi ukuran, jarak, atau warna menciptakan alur visual.',
      },
      {
        label: 'Pusat Perhatian (Focal Point)',
        detail: 'Diciptakan lewat kontras warna mencolok, isolasi objek, atau skala yang lebih dominan.',
      },
      {
        label: 'Kontras Terkendali',
        detail: 'Tanpa penekanan karya terasa datar; terlalu banyak fokus justru membingungkan.',
      },
    ],
    visualType: 'irama-penekanan',
  },
  {
    id: 'slide-8',
    index: '08 / 10',
    category: 'Prinsip Seni Rupa',
    title: 'Proporsi dan Keselarasan (Harmony)',
    subtitle: 'Perbandingan ukuran yang wajar dan keserasian antarbagian.',
    summary:
      'Proporsi membandingkan ukuran antarbagian objek atau objek dengan bidang gambar. Keselarasan menjaga agar seluruh warna, bentuk, dan garis berpadu harmonis.',
    points: [
      {
        label: 'Proporsi Realistis & Golden Ratio',
        detail: 'Perbandingan bagian wajah/tubuh maupun rasio emas 1 : 1,618 pada tata letak.',
      },
      {
        label: 'Keselarasan (Harmony)',
        detail: 'Kesinambungan tema warna dan gaya goresan sehingga tidak ada unsur yang bertabrakan.',
      },
      {
        label: 'Gradasi & Transisi',
        detail: 'Peralihan lembut antar-nada membantu menyatukan bagian kontras.',
      },
    ],
    visualType: 'proporsi-keselarasan',
  },
  {
    id: 'slide-9',
    index: '09 / 10',
    category: 'Analisis Karya',
    title: 'Membaca Karya Seni Rupa Nusantara & Modern',
    subtitle: 'Menggabungkan unsur dan prinsip untuk apresiasi kritis.',
    summary:
      'Dalam batik klasik, lukisan naturalis, hingga desain poster kontemporer, pengamat membaca garis, warna, ritme pengulangan, serta titik fokusnya.',
    points: [
      {
        label: 'Motif Parang & Kawung',
        detail: 'Menonjolkan irama diagonal, keseimbangan berulang, serta keselarasan soga-indigo.',
      },
      {
        label: 'Lukisan Ekspresionis',
        detail: 'Memanfaatkan garis tebal dinamis, tekstur impasto, dan kontras gelap-terang dramatis.',
      },
      {
        label: 'Poster & Desain Grafis',
        detail: 'Mengandalkan proporsi tipografi, ruang negatif bersih, dan penekanan visual.',
      },
    ],
    visualType: 'analisis',
    imageUrl: '/src/assets/images/ebook_cover_seni_rupa_1794935616200.jpg',
  },
  {
    id: 'slide-10',
    index: '10 / 10',
    category: 'Analisis Karya',
    title: 'Langkah Praktik Berkarya di BHOLANG RUPA',
    subtitle: 'Dari konsep sketsa hingga evaluasi berbasis AI dan Google Drive.',
    summary:
      'Gunakan seluruh pemahaman unsur dan prinsip untuk berkarya langsung pada Studio Gambar, berdiskusi di Forum, mempresentasikan analisis, dan menyelesaikan Kuis.',
    points: [
      {
        label: '1. Eksplorasi Demo',
        detail: 'Uji sudut cahaya, irama, dan keseimbangan secara interaktif pada papan laboratorium.',
      },
      {
        label: '2. Praktik Menggambar',
        detail: 'Gambar karya orisinal dengan multi-layer & tekstur kuas, minta kritik AI, lalu kirim ke Drive.',
      },
      {
        label: '3. Kuis C1–C6 & Laporan PDF',
        detail: 'Selesaikan pilihan ganda & esai C1–C6 dengan penyimpanan otomatis ke Google Sheets.',
      },
    ],
    visualType: 'ringkasan',
  },
];

// 12 Soal Pilihan Ganda Terstruktur dari C1 hingga C6 (2 soal per tingkat Taksonomi Bloom)
export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    bloomLevel: 'C1',
    category: 'Unsur Seni Rupa',
    topic: 'Titik & Garis',
    question:
      '[C1 - Mengingat] Unsur seni rupa paling dasar yang terbentuk dari pergerakan atau deretan titik yang saling bersambung adalah...',
    options: ['Bidang', 'Garis', 'Tekstur', 'Proporsi'],
    correctIndex: 1,
    explanation:
      'Pada tingkat C1 (Mengingat), garis didefinisikan sebagai unsur seni rupa yang lahir dari deretan titik yang berkesinambungan.',
    visualCue: 'garis',
  },
  {
    id: 'q2',
    bloomLevel: 'C1',
    category: 'Unsur Seni Rupa',
    topic: 'Teori Warna',
    question:
      '[C1 - Mengingat] Manakah kelompok warna yang termasuk ke dalam warna primer dalam teori pigmen seni rupa?',
    options: [
      'Hijau, Oranye, Ungu',
      'Merah, Kuning, Biru',
      'Cokelat, Hitam, Putih',
      'Toska, Magenta, Abu-abu',
    ],
    correctIndex: 1,
    explanation:
      'Merah, kuning, dan biru merupakan tiga warna primer pokok yang tidak dapat dibentuk dari campuran warna lain.',
    visualCue: 'warna',
  },
  {
    id: 'q3',
    bloomLevel: 'C2',
    category: 'Unsur Seni Rupa',
    topic: 'Bidang & Bentuk',
    question:
      '[C2 - Memahami] Mengapa sebuah kubus yang diarsir di atas kertas dikategorikan sebagai ilustrasi "bentuk", bukan sekadar "bidang"?',
    options: [
      'Karena kubus selalu digambar menggunakan warna primer',
      'Karena bidang bersifat dua dimensi datar, sedangkan bentuk menampilkan ilusi panjang, lebar, dan volume kedalaman',
      'Karena bidang hanya dipakai pada karya patung batu',
      'Karena bentuk tidak memiliki garis batas sama sekali',
    ],
    correctIndex: 1,
    explanation:
      'Bidang hanya memetakan luas dwimatra (2D), sedangkan bentuk (form) menghadirkan kesan volume atau ruang tiga dimensi.',
  },
  {
    id: 'q4',
    bloomLevel: 'C2',
    category: 'Unsur Seni Rupa',
    topic: 'Tekstur',
    question:
      '[C2 - Memahami] Sebuah lukisan menampilkan permukaan kulit kayu yang tampak sangat kasar dan berlekuk secara visual, namun ketika kanvas diraba permukaannya terasa licin rata. Kondisi ini menjelaskan konsep...',
    options: ['Tekstur nyata', 'Tekstur semu (optik)', 'Ruang positif', 'Keselarasan'],
    correctIndex: 1,
    explanation:
      'Tekstur semu terlihat kasar atau berpola secara indra penglihatan, tetapi saat diraba permukaannya rata.',
  },
  {
    id: 'q5',
    bloomLevel: 'C3',
    category: 'Unsur Seni Rupa',
    topic: 'Gelap-Terang',
    question:
      '[C3 - Menerapkan] Jika seorang siswa menggambar bola dan cahaya lampu berasal dari arah kiri atas, teknik gelap-terang yang tepat diterapkan pada sisi kanan bawah bola adalah...',
    options: [
      'Memberikan warna putih paling terang (highlight) di sisi kanan bawah',
      'Menghilangkan bayangan jatuh agar bola tampak melayang datar',
      'Menerapkan gradasi bayangan inti (core shadow) dan bayangan jatuh (cast shadow) ke arah kanan bawah',
      'Mengisi seluruh permukaan bola dengan warna datar tanpa gradasi',
    ],
    correctIndex: 2,
    explanation:
      'Penerapan gelap-terang mengikuti arah datang cahaya: sisi berlawanan (kanan bawah) menerima bayangan inti dan menghasilkan bayangan jatuh.',
    visualCue: 'gelap-terang',
  },
  {
    id: 'q6',
    bloomLevel: 'C3',
    category: 'Prinsip Seni Rupa',
    topic: 'Keseimbangan',
    question:
      '[C3 - Menerapkan] Dalam membuat poster bertema lingkungan, seorang siswa meletakkan ilustrasi pohon besar di sisi kiri. Agar tercapai keseimbangan asimetris yang stabil di sisi kanan, langkah yang paling tepat adalah...',
    options: [
      'Mengosongkan seluruh sisi kanan tanpa teks maupun warna',
      'Menempatkan judul tebal dan beberapa ikon daun berwarna cerah kontras di sisi kanan',
      'Menggandakan pohon yang sama persis ukuran dan posisinya di kanan',
      'Menghapus pohon di sisi kiri agar kanvas bersih',
    ],
    correctIndex: 1,
    explanation:
      'Keseimbangan asimetris dicapai dengan menyeimbangkan bobot visual melalui kontras warna, kepadatan tipografi, atau sekelompok elemen kecil.',
    visualCue: 'keseimbangan',
  },
  {
    id: 'q7',
    bloomLevel: 'C4',
    category: 'Prinsip Seni Rupa',
    topic: 'Irama',
    question:
      '[C4 - Menganalisis] Pada motif batik Parang, pengulangan bilah miring yang disusun berjajar konsisten dari sudut ke sudut membuat mata pengamat bergerak menyusuri bidang kain. Unsur dan prinsip utama yang bekerja bersama dalam fenomena tersebut adalah...',
    options: [
      'Unsur tekstur nyata dan prinsip proporsi tubuh',
      'Unsur garis diagonal berulang yang membangun prinsip irama (rhythm) progresif',
      'Unsur ruang kosong tanpa prinsip kesatuan',
      'Unsur warna monokrom yang menghapus arah gerak',
    ],
    correctIndex: 1,
    explanation:
      'Analisis struktur motif Parang menunjukkan keterkaitan antara garis/bidang miring berulang dengan prinsip irama visual yang dinamis.',
    visualCue: 'irama',
  },
  {
    id: 'q8',
    bloomLevel: 'C4',
    category: 'Unsur Seni Rupa',
    topic: 'Ruang & Warna',
    question:
      '[C4 - Menganalisis] Ketika sebuah poster menggunakan latar belakang abu-abu muda yang luas serta satu lingkaran merah menyala di kuadran kanan, mengapa mata audiens otomatis tertuju pada lingkaran merah tersebut?',
    options: [
      'Karena abu-abu muda memiliki saturasi lebih tinggi dari merah',
      'Karena interaksi ruang negatif yang lapang dan kontras warna jenuh menciptakan pusat perhatian (emphasis)',
      'Karena warna primer tidak dapat dilihat bersamaan dengan warna netral',
      'Karena lingkaran menghilangkan seluruh unsur garis',
    ],
    correctIndex: 1,
    explanation:
      'Ruang negatif yang lega mengurangi gangguan visual sehingga kontras warna merah menjadi pusat fokus yang kuat.',
    visualCue: 'penekanan',
  },
  {
    id: 'q9',
    bloomLevel: 'C5',
    category: 'Prinsip Seni Rupa',
    topic: 'Kesatuan & Keselarasan',
    question:
      '[C5 - Mengevaluasi] Seorang siswa mengkritik sebuah karya kolase karena setiap sudutnya memakai lima warna neon berbeda, gaya garis yang bertabrakan, dan lima objek utama berukuran sama besar. Evaluasi perbaikan yang paling efektif adalah...',
    options: [
      'Menambahkan lebih banyak teks berukuran besar di setiap sudut',
      'Menyederhanakan palet ke skema warna analogus/komplementer terbatas dan menetapkan satu objek sebagai focal point agar kesatuan terjaga',
      'Mengubah semua objek menjadi kotak hitam yang identik',
      'Menghapus seluruh warna sehingga hanya tersisa titik-titik acak',
    ],
    correctIndex: 1,
    explanation:
      'Mengevaluasi komposisi yang terlalu ramai menuntut pengendalian palet warna (keselarasan) serta hierarki fokus (penekanan & kesatuan).',
  },
  {
    id: 'q10',
    bloomLevel: 'C5',
    category: 'Prinsip Seni Rupa',
    topic: 'Proporsi',
    question:
      '[C5 - Mengevaluasi] Saat menilai gambar potret realis teman sekelas, ditemukan bahwa ukuran telinga digambar hampir sebesar bahu. Berdasarkan prinsip seni rupa, penilaian yang paling tepat atas kelemahan karya tersebut adalah...',
    options: [
      'Karya gagal menerapkan proporsi anatomi yang wajar antara bagian wajah dan tubuh',
      'Karya kekurangan unsur warna tersier',
      'Karya terlalu kuat menggunakan keseimbangan radial',
      'Karya tidak memiliki tekstur semu',
    ],
    correctIndex: 0,
    explanation:
      'Ketidaksesuaian perbandingan ukuran antarbagian objek secara langsung merupakan persoalan prinsip proporsi.',
  },
  {
    id: 'q11',
    bloomLevel: 'C6',
    category: 'Prinsip Seni Rupa',
    topic: 'Perancangan Komposisi',
    question:
      '[C6 - Mencipta] Anda ditugaskan merancang ilustrasi sampul buku bertema "Harmoni Alam Nusantara" dengan kesan tenang, mengalir, dan tetap memiliki satu titik fokus utama. Rancangan kombinasi unsur dan prinsip paling tepat adalah...',
    options: [
      'Menggunakan garis zig-zag tajam bertabrakan, warna komplementer neon ekstrem, dan komposisi acak',
      'Memadukan garis lengkung organik berirama, palet warna analogus hijau-biru yang selaras, serta satu aksen warna hangat keemasan sebagai penekanan',
      'Menggambar satu titik kecil hitam di pojok kiri bawah tanpa unsur lain',
      'Menggunakan bidang kotak abu-abu seragam memenuhi 100% bidang gambar',
    ],
    correctIndex: 1,
    explanation:
      'Merancang karya bertema tenang dan harmonis memadukan garis lengkung, irama lembut, keselarasan warna analogus, serta aksen fokus terukur.',
  },
  {
    id: 'q12',
    bloomLevel: 'C6',
    category: 'Unsur Seni Rupa',
    topic: 'Eksplorasi Tekstur & Blending',
    question:
      '[C6 - Mencipta] Untuk menciptakan karya lukis digital suasana senja di pegunungan yang terasa berdimensi dalam dan tidak datar, strategi penciptaan layer dan kuas yang paling inovatif adalah...',
    options: [
      'Menggambar langit, gunung, dan bayangan pada satu warna datar yang sama tanpa gradasi',
      'Memisahkan latar langit dengan blending gradasi halus, menerapkan tekstur kuas bintik/kanvas pada siluet pegunungan, dan memakai mode blend multiply untuk bayangan',
      'Menggunakan alat penghapus di seluruh kanvas putih',
      'Menggambar garis lurus vertikal sejajar dengan opasitas 100% di seluruh layar',
    ],
    correctIndex: 1,
    explanation:
      'Sintesis teknik multi-layer, kuas tekstur, blending gradasi, dan kontrol gelap-terang menciptakan kedalaman atmosferik yang kuat.',
  },
];

// 6 Soal Esai Terstruktur dari C1 hingga C6
export const ESSAY_QUESTIONS: EssayQuestion[] = [
  {
    id: 'e1',
    bloomLevel: 'C1',
    bloomLabel: 'C1 · Mengingat',
    category: 'Unsur Seni Rupa',
    topic: 'Unsur Dasar',
    question:
      'Sebutkan 8 unsur seni rupa beserta satu contoh wujudnya yang sering kamu temui pada benda di ruang kelas!',
    rubricHint: 'Sebutkan titik, garis, bidang, bentuk, ruang, warna, tekstur, dan gelap-terang dengan contoh nyata.',
  },
  {
    id: 'e2',
    bloomLevel: 'C2',
    bloomLabel: 'C2 · Memahami',
    category: 'Prinsip Seni Rupa',
    topic: 'Keseimbangan',
    question:
      'Jelaskan dengan bahasamu sendiri perbedaan antara keseimbangan simetris, asimetris, dan radial dalam karya seni rupa!',
    rubricHint: 'Uraikan ciri susunan bobot visual dan kesan yang ditimbulkan masing-masing jenis keseimbangan.',
  },
  {
    id: 'e3',
    bloomLevel: 'C3',
    bloomLabel: 'C3 · Menerapkan',
    category: 'Unsur Seni Rupa',
    topic: 'Gelap-Terang & Warna',
    question:
      'Jika kamu diminta menggambar kendi tanah liat di atas meja yang terkena cahaya matahari pagi dari jendela sebelah kanan, bagaimana langkahmu menerapkan gelap-terang dan warna agar kendi tampak 3 dimensi?',
    rubricHint: 'Jelaskan posisi highlight, midtone, core shadow, cast shadow, serta gradasi warna hangat-dingin.',
  },
  {
    id: 'e4',
    bloomLevel: 'C4',
    bloomLabel: 'C4 · Menganalisis',
    category: 'Terpadu',
    topic: 'Analisis Karya',
    question:
      'Amati motif batik tradisional atau poster kegiatan sekolah yang kamu sukai. Analisislah unsur apa yang paling dominan dan bagaimana prinsip irama serta penekanan bekerja pada karya tersebut!',
    rubricHint: 'Hubungkan temuan unsur (garis/warna/bidang) dengan cara prinsip irama dan focal point memandu mata pengamat.',
  },
  {
    id: 'e5',
    bloomLevel: 'C5',
    bloomLabel: 'C5 · Mengevaluasi',
    category: 'Prinsip Seni Rupa',
    topic: 'Kritik Komposisi',
    question:
      'Mengapa sebuah karya gambar yang memakai banyak warna cerah sekaligus tanpa pembagian ruang negatif sering terasa melelahkan untuk dilihat? Berikan penilaian dan dua saran perbaikan konkret!',
    rubricHint: 'Evaluasi dampak hilangnya keselarasan warna, penekanan, serta keseimbangan ruang positif-negatif.',
  },
  {
    id: 'e6',
    bloomLevel: 'C6',
    bloomLabel: 'C6 · Mencipta',
    category: 'Terpadu',
    topic: 'Konsep Penciptaan Karya',
    question:
      'Rancanglah konsep sebuah karya gambar bertema "Semangat Muda Pelajar Indonesia". Jelaskan pilihan garis, kombinasi warna, tekstur kuas, jenis keseimbangan, serta pusat perhatian yang akan kamu bangun!',
    rubricHint: 'Susun rencana penciptaan yang memadukan unsur dan prinsip secara kohesif dan orisinal.',
  },
];

export const DEFAULT_SUBJECT_COMPARISONS: SubjectScoreComparison[] = [
  { subject: 'Unsur Seni Rupa', classAverage: 82, studentScore: 88 },
  { subject: 'Prinsip Seni Rupa', classAverage: 79, studentScore: 85 },
  { subject: 'Praktik Menggambar', classAverage: 84, studentScore: 90 },
  { subject: 'Presentasi & Apresiasi', classAverage: 81, studentScore: 86 },
  { subject: 'Desain Grafis Dasar', classAverage: 78, studentScore: 84 },
  { subject: 'Sejarah Seni Budaya', classAverage: 80, studentScore: 82 },
];
