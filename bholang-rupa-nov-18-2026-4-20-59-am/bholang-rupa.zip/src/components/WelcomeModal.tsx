import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, GraduationCap, Palette, Sun, Moon } from 'lucide-react';
import type { UserProfile, UserRole } from '../types';
import { playClickSound } from '../utils/sound';

interface WelcomeModalProps {
  open: boolean;
  initialProfile: UserProfile;
  isDark: boolean;
  onToggleTheme: () => void;
  onEnter: (profile: UserProfile) => void;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({
  open,
  initialProfile,
  isDark,
  onToggleTheme,
  onEnter,
}) => {
  const [name, setName] = useState(initialProfile.name || '');
  const [className, setClassName] = useState(
    initialProfile.className && initialProfile.className !== 'Guru Pengampu'
      ? initialProfile.className
      : 'X-A'
  );
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Mohon masukkan nama lengkap Anda terlebih dahulu.');
      return;
    }
    onEnter({
      name: trimmed,
      role: 'siswa',
      className: className.trim() || 'X-A',
    });
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.22 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="welcome-heading"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.26, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-[#E5E0D8] bg-[#FFFFFF] shadow-2xl dark:border-[#272E3F] dark:bg-[#151923]"
          >
            {/* Top visual header strip */}
            <div className="relative h-40 w-full overflow-hidden bg-[#1D4ED8] sm:h-48">
              <img
                src="/src/assets/images/hero_art_studio_1794935614952.jpg"
                alt="Studio Pembelajaran Seni Rupa BHOLANG RUPA"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover opacity-85"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0D1017]/90 via-[#0D1017]/45 to-transparent" />
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  onToggleTheme();
                }}
                aria-label="Ubah tema gelap atau terang"
                className="absolute top-4 right-4 inline-flex items-center gap-2 rounded-lg border border-white/25 bg-black/35 px-3 py-1.5 text-xs font-medium text-white backdrop-blur-md transition-colors hover:bg-black/55 whitespace-nowrap shrink-0"
              >
                {isDark ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
                <span>{isDark ? 'Mode Terang' : 'Mode Gelap'}</span>
              </button>
              <div className="absolute right-6 bottom-5 left-6">
                <p className="text-xs font-medium text-blue-200">
                  Studio Seni Rupa Interaktif · Kelas X KD 3.1
                </p>
                <h1
                  id="welcome-heading"
                  className="mt-1 text-2xl font-bold tracking-tight text-white sm:text-3xl"
                  style={{ textWrap: 'balance' }}
                >
                  SELAMAT DATANG DI BHOLANG RUPA
                </h1>
              </div>
            </div>

            {/* Form body */}
            <form onSubmit={handleSubmit} className="space-y-5 p-6 sm:p-8">
              <p className="text-sm leading-relaxed text-[#4A505E] dark:text-[#A3B1C6]">
                Pelajari <strong className="text-[#171923] dark:text-white">Unsur-Unsur dan Prinsip Seni Rupa</strong>{' '}
                melalui slide interaktif, e-book Kemendikdasmen, video pembelajaran, laboratorium simulasi warna,
                praktik menggambar berpendampingan AI, galeri apresiasi, kuis C1–C6, serta sinkronisasi penilaian ke E-mail dan Google Drive.
              </p>

              {/* Inputs */}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="sm:col-span-2">
                  <label
                    htmlFor="welcome-name"
                    className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]"
                  >
                    Nama Lengkap Siswa
                  </label>
                  <input
                    id="welcome-name"
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (error) setError('');
                    }}
                    placeholder="Contoh: Raka Pratama"
                    className="mt-1.5 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-2.5 text-sm text-[#171923] outline-none transition-colors focus:border-[#1D4ED8] focus:bg-white dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white dark:focus:border-[#60A5FA]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="welcome-class"
                    className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]"
                  >
                    Kelas
                  </label>
                  <input
                    id="welcome-class"
                    type="text"
                    value={className}
                    onChange={(e) => setClassName(e.target.value)}
                    placeholder="X-A"
                    className="mt-1.5 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-2.5 text-sm text-[#171923] outline-none transition-colors focus:border-[#1D4ED8] focus:bg-white dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white dark:focus:border-[#60A5FA]"
                  />
                </div>
              </div>

              {error && (
                <p className="text-xs font-medium text-[#DC2626] dark:text-[#F87171]">{error}</p>
              )}

              <div className="flex flex-col-reverse items-center justify-between gap-3 border-t border-[#E5E0D8] pt-4 sm:flex-row dark:border-[#272E3F]">
                <span className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  Audio klik interaktif &amp; mode gelap-terang siap digunakan
                </span>
                <button
                  type="submit"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-6 py-2.5 text-sm font-semibold text-white transition-all hover:bg-[#1E40AF] active:scale-[0.98] sm:w-auto whitespace-nowrap shrink-0 dark:bg-[#2563EB] dark:hover:bg-[#1D4ED8]"
                >
                  <span>Masuk ke Web</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
