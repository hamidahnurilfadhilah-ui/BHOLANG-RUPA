import React, { useState } from 'react';
import {
  Bell,
  CheckCheck,
  ExternalLink,
  LogOut,
  Menu,
  Moon,
  Sun,
  UserCheck,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { User } from 'firebase/auth';
import type { ActiveTab, TeacherNotification, UserProfile } from '../types';
import { playClickSound } from '../utils/sound';

interface HeaderNavProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  profile: UserProfile;
  onOpenProfileModal: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  soundOn: boolean;
  onToggleSound: () => void;
  googleUser: User | null;
  isLoggingInGoogle: boolean;
  onGoogleLogin: () => void;
  onGoogleLogout: () => void;
  notifications: TeacherNotification[];
  onMarkAllRead: () => void;
  wsConnected: boolean;
}

const NAV_ITEMS: { id: ActiveTab; label: string }[] = [
  { id: 'materi', label: 'Materi' },
  { id: 'demo-praktik', label: 'Demo & Praktik' },
  { id: 'galeri', label: 'Galeri Kelas' },
  { id: 'presentasi-diskusi', label: 'Presentasi & Diskusi' },
  { id: 'kuis', label: 'Kuis' },
  { id: 'analitik', label: 'Analitik' },
];

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeTab,
  onSelectTab,
  profile,
  onOpenProfileModal,
  isDark,
  onToggleTheme,
  soundOn,
  onToggleSound,
  googleUser,
  isLoggingInGoogle,
  onGoogleLogin,
  onGoogleLogout,
  notifications,
  onMarkAllRead,
  wsConnected,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="sticky top-0 z-40 border-b border-[#E5E0D8] bg-[#FFFFFF]/95 backdrop-blur-md dark:border-[#272E3F] dark:bg-[#151923]/95">
      {/* Strict 3-Zone Top Bar */}
      <header className="mx-auto flex max-w-[1360px] items-center justify-between gap-8 px-4 py-3 sm:px-6">
        {/* Zone 1: Single-line Brand Wordmark */}
        <button
          type="button"
          onClick={() => {
            playClickSound();
            onSelectTab('materi');
          }}
          className="font-display text-lg font-bold tracking-tight text-[#171923] whitespace-nowrap shrink-0 dark:text-white"
        >
          BHOLANG RUPA
        </button>

        {/* Zone 2: 5 concise single-line nav links */}
        <nav className="hidden items-center gap-6 md:flex" aria-label="Navigasi Utama">
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  onSelectTab(item.id);
                }}
                className={`relative py-1.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'text-[#1D4ED8] dark:text-[#60A5FA]'
                    : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute right-0 -bottom-[13px] left-0 h-0.5 bg-[#1D4ED8] dark:bg-[#60A5FA]" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Google Drive Sign-In Action (plus mobile menu trigger) */}
        <div className="flex items-center gap-2 shrink-0">
          {googleUser ? (
            <div className="flex items-center gap-2">
              <span className="hidden text-xs font-medium text-[#4A505E] sm:inline whitespace-nowrap dark:text-[#A3B1C6]">
                {googleUser.displayName || googleUser.email}
              </span>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  onGoogleLogout();
                }}
                title="Putuskan koneksi Google Drive"
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-1.5 text-xs font-semibold text-[#171923] transition-colors hover:bg-[#EFECE6] whitespace-nowrap shrink-0 dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white dark:hover:bg-[#1E2433]"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Keluar Google</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onGoogleLogin();
              }}
              disabled={isLoggingInGoogle}
              className="gsi-material-button shrink-0"
            >
              <div className="gsi-material-button-state" />
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    style={{ display: 'block' }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    />
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                  </svg>
                </div>
                <span className="gsi-material-button-contents">
                  {isLoggingInGoogle ? 'Menghubungkan...' : 'Sign in with Google'}
                </span>
              </div>
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              playClickSound();
              setMobileMenuOpen((v) => !v);
            }}
            aria-label="Menu navigasi"
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#E5E0D8] text-[#171923] md:hidden dark:border-[#272E3F] dark:text-white"
          >
            {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </header>

      {/* Mobile Nav Dropdown */}
      {mobileMenuOpen && (
        <div className="border-t border-[#E5E0D8] bg-[#FFFFFF] px-4 py-2 md:hidden dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap gap-2">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  onSelectTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap ${
                  activeTab === item.id
                    ? 'bg-[#1D4ED8] text-white'
                    : 'bg-[#FAF9F7] text-[#4A505E] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Workspace Utility Toolbar (below header, compact 1-line controls) */}
      <div className="border-t border-[#EEEAE2] bg-[#FAF9F7] dark:border-[#1E2433] dark:bg-[#0D1017]">
        <div className="mx-auto flex max-w-[1360px] flex-wrap items-center justify-between gap-3 px-4 py-1.5 text-xs sm:px-6">
          <div className="flex items-center gap-3 text-[#4A505E] dark:text-[#A3B1C6]">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onOpenProfileModal();
              }}
              className="inline-flex items-center gap-1.5 font-medium text-[#171923] hover:text-[#1D4ED8] whitespace-nowrap dark:text-[#E2E8F0] dark:hover:text-[#60A5FA]"
            >
              <UserCheck className="h-3.5 w-3.5 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <span>{profile.name}</span>
              <span aria-hidden="true">·</span>
              <span>Siswa ({profile.className})</span>
            </button>
            <span className="hidden items-center gap-1.5 sm:inline-flex">
              <span aria-hidden="true">·</span>
              <span
                className={`inline-block h-1.5 w-1.5 rounded-full ${
                  wsConnected ? 'bg-[#059669]' : 'bg-[#D97706]'
                }`}
              />
              <span>{wsConnected ? 'Sinkronisasi Real-Time Aktif' : 'Menghubungkan...'}</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Sound toggle */}
            <button
              type="button"
              onClick={() => {
                onToggleSound();
                if (!soundOn) setTimeout(() => playClickSound(), 10);
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-[#E5E0D8] bg-white px-2.5 py-1 font-medium text-[#4A505E] transition-colors hover:text-[#171923] whitespace-nowrap shrink-0 dark:border-[#272E3F] dark:bg-[#151923] dark:text-[#A3B1C6] dark:hover:text-white"
            >
              {soundOn ? <Volume2 className="h-3.5 w-3.5 text-[#1D4ED8]" /> : <VolumeX className="h-3.5 w-3.5" />}
              <span>{soundOn ? 'Audio Klik Aktif' : 'Audio Hening'}</span>
            </button>

            {/* Dark/Light toggle */}
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onToggleTheme();
              }}
              className="inline-flex items-center gap-1.5 rounded-md border border-[#E5E0D8] bg-white px-2.5 py-1 font-medium text-[#4A505E] transition-colors hover:text-[#171923] whitespace-nowrap shrink-0 dark:border-[#272E3F] dark:bg-[#151923] dark:text-[#A3B1C6] dark:hover:text-white"
            >
              {isDark ? <Sun className="h-3.5 w-3.5 text-amber-400" /> : <Moon className="h-3.5 w-3.5 text-slate-700" />}
              <span>{isDark ? 'Terang' : 'Gelap'}</span>
            </button>

            {/* Real-time Teacher Notification Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setNotifOpen((v) => !v);
                }}
                aria-label="Notifikasi kiriman siswa"
                className="relative inline-flex items-center gap-1.5 rounded-md border border-[#E5E0D8] bg-white px-2.5 py-1 font-medium text-[#171923] transition-colors hover:bg-[#F4F1EA] whitespace-nowrap shrink-0 dark:border-[#272E3F] dark:bg-[#151923] dark:text-white dark:hover:bg-[#1E2433]"
              >
                <Bell className="h-3.5 w-3.5 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <span>Notifikasi</span>
                {unreadCount > 0 && (
                  <span className="font-mono-num rounded bg-[#DC2626] px-1.5 py-0.5 text-[10px] font-bold leading-none text-white">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div className="absolute right-0 mt-2 w-80 overflow-hidden rounded-xl border border-[#E5E0D8] bg-white shadow-xl sm:w-96 dark:border-[#272E3F] dark:bg-[#151923]">
                  <div className="flex items-center justify-between border-b border-[#E5E0D8] px-4 py-2.5 dark:border-[#272E3F]">
                    <span className="text-xs font-bold text-[#171923] dark:text-white">
                      Notifikasi Kiriman Real-Time
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        onMarkAllRead();
                      }}
                      className="inline-flex items-center gap-1 text-[11px] font-medium text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                    >
                      <CheckCheck className="h-3.5 w-3.5" />
                      <span>Tandai terbaca</span>
                    </button>
                  </div>
                  <div className="max-h-72 divide-y divide-[#EEEAE2] overflow-y-auto dark:divide-[#272E3F]">
                    {notifications.length === 0 ? (
                      <div className="p-4 text-center text-xs text-[#646B7A] dark:text-[#94A3B8]">
                        Belum ada aktivitas kiriman terbaru.
                      </div>
                    ) : (
                      notifications.slice(0, 12).map((n) => (
                        <div
                          key={n.id}
                          className={`px-4 py-3 text-xs ${
                            n.read
                              ? 'opacity-75'
                              : 'bg-[#EFF6FF]/60 dark:bg-[#1E293B]/60'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-semibold text-[#171923] dark:text-white">
                              {n.studentName} · {n.className}
                            </span>
                            <span className="text-[10px] text-[#646B7A] dark:text-[#94A3B8]">
                              {new Date(n.createdAt).toLocaleTimeString('id-ID', {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                          <p className="mt-0.5 font-medium text-[#1D4ED8] dark:text-[#60A5FA]">
                            {n.title}
                          </p>
                          <p className="mt-0.5 text-[#4A505E] dark:text-[#A3B1C6]">{n.detail}</p>
                          {n.driveLink && (
                            <a
                              href={n.driveLink}
                              target="_blank"
                              rel="noreferrer"
                              className="mt-1 inline-flex items-center gap-1 font-medium text-[#059669] hover:underline dark:text-[#34D399]"
                            >
                              <span>Buka di Google Drive</span>
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
