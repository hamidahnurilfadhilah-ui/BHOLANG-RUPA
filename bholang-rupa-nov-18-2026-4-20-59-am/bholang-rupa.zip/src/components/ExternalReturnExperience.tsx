import React from 'react';
import { ArrowLeft, ExternalLink, Globe, RotateCcw, X } from 'lucide-react';
import type { ActiveTab } from '../types';
import { playClickSound } from '../utils/sound';

export interface FocusViewerResource {
  title: string;
  subtitle: string;
  embedUrl: string;
  externalUrl: string;
}

export interface ExternalReturnInfo {
  label: string;
  url: string;
  openedAt: number;
  returnedToTab: boolean;
}

interface ExternalFocusModalProps {
  resource: FocusViewerResource | null;
  onClose: () => void;
  onOpenExternal: (label: string, url: string) => void;
}

export const ExternalFocusModal: React.FC<ExternalFocusModalProps> = ({
  resource,
  onClose,
  onOpenExternal,
}) => {
  if (!resource) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex flex-col bg-[#0D1017]/95 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label={resource.title}
    >
      {/* Top Sticky Return Bar */}
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-[#272E3F] bg-[#151923] px-4 py-3 text-white sm:px-6">
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-bold text-white shadow-sm transition-colors hover:bg-[#2563EB]"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Kembali ke Web BHOLANG RUPA</span>
          </button>

          <div className="min-w-0">
            <div className="truncate text-sm font-bold text-white">{resource.title}</div>
            <div className="truncate text-[11px] text-[#94A3B8]">{resource.subtitle}</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href={resource.externalUrl}
            target="_blank"
            rel="noreferrer"
            data-resource-label={resource.title}
            onClick={() => {
              playClickSound();
              onOpenExternal(resource.title, resource.externalUrl);
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#334155] bg-[#0D1017] px-3 py-2 text-xs font-semibold text-[#E2E8F0] transition-colors hover:border-[#60A5FA] hover:text-white"
          >
            <span>Buka di Tab Luar</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onClose();
            }}
            aria-label="Tutup dan kembali ke web"
            className="rounded-lg border border-[#334155] p-2 text-[#94A3B8] hover:bg-[#1E293B] hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* Embedded Content Frame */}
      <div className="relative flex-1 bg-black">
        <iframe
          src={resource.embedUrl}
          title={resource.title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
          allowFullScreen
          className="h-full w-full border-0 bg-white"
        />
      </div>

      {/* Bottom Safety Return Bar */}
      <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-[#272E3F] bg-[#151923] px-4 py-2 text-[11px] text-[#94A3B8] sm:px-6">
        <span>
          Jika halaman eksternal tidak tampil di dalam bingkai karena kebijakan situs tujuan, silakan klik{' '}
          <strong className="text-white">Buka di Tab Luar</strong>.
        </span>
        <button
          type="button"
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="font-semibold text-[#60A5FA] hover:underline"
        >
          ← Kembali ke Web BHOLANG RUPA
        </button>
      </footer>
    </div>
  );
};

interface ExternalReturnBannerProps {
  info: ExternalReturnInfo | null;
  onReturnToWeb: () => void;
  onNavigateTab: (tab: ActiveTab) => void;
}

export const ExternalReturnBanner: React.FC<ExternalReturnBannerProps> = ({
  info,
  onReturnToWeb,
  onNavigateTab,
}) => {
  if (!info) return null;

  return (
    <div className="fixed bottom-4 left-1/2 z-[60] w-[calc(100%-2rem)] max-w-2xl -translate-x-1/2 rounded-2xl border border-[#1D4ED8]/40 bg-white p-4 shadow-2xl dark:border-[#3B82F6]/50 dark:bg-[#151923]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#EFF6FF] text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]">
            <Globe className="h-4 w-4" />
          </div>
          <div className="text-xs">
            <div className="font-bold text-[#171923] dark:text-white">
              {info.returnedToTab
                ? 'Selamat Datang Kembali di Web BHOLANG RUPA'
                : 'Anda Membuka Tautan di Luar Web'}
            </div>
            <p className="mt-0.5 text-[#4A505E] dark:text-[#A3B1C6]">
              Sumber eksternal: <strong className="text-[#171923] dark:text-white">{info.label}</strong>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onReturnToWeb();
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3.5 py-2 text-xs font-bold text-white shadow-sm transition-colors hover:bg-[#1E40AF]"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Kembali ke Web</span>
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onNavigateTab('materi');
              onReturnToWeb();
            }}
            className="rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-2.5 py-2 text-[11px] font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
          >
            Materi
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onNavigateTab('kuis');
              onReturnToWeb();
            }}
            className="rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-2.5 py-2 text-[11px] font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
          >
            Kuis
          </button>
          <a
            href={info.url}
            target="_blank"
            rel="noreferrer"
            onClick={() => playClickSound()}
            title="Buka ulang tautan eksternal"
            className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-2.5 py-2 text-[11px] font-semibold text-[#4A505E] hover:text-[#171923] dark:border-[#2D3548] dark:text-[#A3B1C6] dark:hover:text-white"
          >
            <RotateCcw className="h-3 w-3" />
            <span>Buka Lagi</span>
          </a>
        </div>
      </div>
    </div>
  );
};
