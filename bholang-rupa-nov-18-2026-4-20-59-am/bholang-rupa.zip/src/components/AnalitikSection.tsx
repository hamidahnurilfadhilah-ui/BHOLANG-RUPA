import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart3,
  Bell,
  Download,
  ExternalLink,
  FileDown,
  FileSpreadsheet,
  FolderOpen,
  Heart,
  Image as ImageIcon,
  Mail,
  Pin,
  RefreshCw,
  Search,
  TrendingUp,
} from 'lucide-react';
import {
  DEFAULT_SUBJECT_COMPARISONS,
  DRIVE_FOLDER_URL,
} from '../data/learningContent';
import type {
  ArtworkSubmission,
  PresentationSubmission,
  QuizSubmission,
  TeacherNotification,
  UserProfile,
} from '../types';
import {
  getCachedAccessToken,
  listDriveFolderFiles,
  type DriveFileItem,
} from '../utils/firebaseGoogle';
import { exportStudentReportPdf } from '../utils/pdfExport';
import { playClickSound } from '../utils/sound';

interface AnalitikSectionProps {
  profile: UserProfile;
  quizSubmissions: QuizSubmission[];
  artworks: ArtworkSubmission[];
  presentations: PresentationSubmission[];
  notifications: TeacherNotification[];
  onMarkAllRead: () => void;
  onQuizUpdated: (item: QuizSubmission) => void;
  onArtworkUpdated: (item: ArtworkSubmission) => void;
  onRequireGoogleLogin: () => Promise<boolean>;
  onRequestSendEmail?: (payload: {
    subject: string;
    summaryText: string;
    htmlBody: string;
  }) => void;
}

export const AnalitikSection: React.FC<AnalitikSectionProps> = ({
  profile,
  quizSubmissions,
  artworks,
  presentations,
  notifications,
  onMarkAllRead,
  onQuizUpdated,
  onArtworkUpdated,
  onRequireGoogleLogin,
  onRequestSendEmail,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<string>('ALL');
  const [hoveredBarIdx, setHoveredBarIdx] = useState<number | null>(null);
  const [driveFiles, setDriveFiles] = useState<DriveFileItem[]>([]);
  const [loadingDrive, setLoadingDrive] = useState(false);
  const [driveError, setDriveError] = useState('');
  const [reviewingQuizId, setReviewingQuizId] = useState<string | null>(null);
  const [essayGradeInput, setEssayGradeInput] = useState<number>(85);
  const [savingEssayGrade, setSavingEssayGrade] = useState(false);

  const studentNames = useMemo(() => {
    const names = Array.from(new Set(quizSubmissions.map((q) => q.studentName)));
    return names;
  }, [quizSubmissions]);

  const activeStudentName =
    selectedStudent === 'ALL'
      ? studentNames[0] || profile.name
      : selectedStudent;

  // Overall metrics
  const stats = useMemo(() => {
    const total = quizSubmissions.length;
    const avg =
      total > 0
        ? Math.round(quizSubmissions.reduce((a, b) => a + b.score, 0) / total)
        : 0;
    const passed = quizSubmissions.filter((q) => q.score >= 75).length;
    const passRate = total > 0 ? Math.round((passed / total) * 100) : 0;
    return {
      totalQuizzes: total,
      classAverage: avg,
      passRate,
      submissionsTotal: artworks.length + presentations.length,
    };
  }, [quizSubmissions, artworks.length, presentations.length]);

  // Subject bar chart data comparing selected student vs class average
  const subjectBarData = useMemo(() => {
    const targetSubs =
      selectedStudent === 'ALL'
        ? quizSubmissions
        : quizSubmissions.filter((q) => q.studentName === selectedStudent);

    const avgUnsurClass =
      quizSubmissions.length > 0
        ? Math.round(
            quizSubmissions.reduce((a, b) => a + b.unsurScore, 0) /
              quizSubmissions.length
          )
        : 82;
    const avgPrinsipClass =
      quizSubmissions.length > 0
        ? Math.round(
            quizSubmissions.reduce((a, b) => a + b.prinsipScore, 0) /
              quizSubmissions.length
          )
        : 79;

    const studentUnsur =
      targetSubs.length > 0
        ? Math.round(
            targetSubs.reduce((a, b) => a + b.unsurScore, 0) / targetSubs.length
          )
        : avgUnsurClass;
    const studentPrinsip =
      targetSubs.length > 0
        ? Math.round(
            targetSubs.reduce((a, b) => a + b.prinsipScore, 0) / targetSubs.length
          )
        : avgPrinsipClass;

    const studentArtBoost = Math.min(
      98,
      78 +
        artworks.filter((a) =>
          selectedStudent === 'ALL' ? true : a.studentName === selectedStudent
        ).length *
          6
    );
    const studentPresBoost = Math.min(
      96,
      76 +
        presentations.filter((p) =>
          selectedStudent === 'ALL' ? true : p.studentName === selectedStudent
        ).length *
          7
    );

    return DEFAULT_SUBJECT_COMPARISONS.map((row) => {
      if (row.subject === 'Unsur Seni Rupa') {
        return {
          ...row,
          classAverage: avgUnsurClass,
          studentScore: studentUnsur,
        };
      }
      if (row.subject === 'Prinsip Seni Rupa') {
        return {
          ...row,
          classAverage: avgPrinsipClass,
          studentScore: studentPrinsip,
        };
      }
      if (row.subject === 'Praktik Menggambar') {
        return {
          ...row,
          studentScore: studentArtBoost,
        };
      }
      if (row.subject === 'Presentasi & Apresiasi') {
        return {
          ...row,
          studentScore: studentPresBoost,
        };
      }
      return row;
    });
  }, [quizSubmissions, selectedStudent, artworks, presentations]);

  // Progression series sorted chronologically
  const progressionPoints = useMemo(() => {
    const list = [...quizSubmissions].reverse();
    return list.slice(-10);
  }, [quizSubmissions]);

  const filteredQuizzes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return quizSubmissions.filter((item) => {
      const matchesStudent =
        selectedStudent === 'ALL' || item.studentName === selectedStudent;
      const matchesSearch =
        !q ||
        item.studentName.toLowerCase().includes(q) ||
        item.className.toLowerCase().includes(q) ||
        item.predicate.toLowerCase().includes(q);
      return matchesStudent && matchesSearch;
    });
  }, [quizSubmissions, selectedStudent, searchQuery]);

  const loadDriveFiles = async () => {
    playClickSound();
    if (!getCachedAccessToken()) {
      const ok = await onRequireGoogleLogin();
      if (!ok) return;
    }
    setLoadingDrive(true);
    setDriveError('');
    try {
      const files = await listDriveFolderFiles();
      setDriveFiles(files);
    } catch (err) {
      setDriveError(
        err instanceof Error ? err.message : 'Gagal memuat berkas Google Drive.'
      );
    } finally {
      setLoadingDrive(false);
    }
  };

  useEffect(() => {
    if (getCachedAccessToken()) {
      listDriveFolderFiles()
        .then(setDriveFiles)
        .catch(() => {});
    }
  }, []);

  const handleExportStudentPdf = (student: string) => {
    playClickSound();
    const subs = quizSubmissions.filter((q) => q.studentName === student);
    const sampleClass = subs[0]?.className || profile.className;
    exportStudentReportPdf({
      studentName: student,
      className: sampleClass,
      submissions: subs,
      subjectComparisons: subjectBarData,
      artworkCount: artworks.filter((a) => a.studentName === student).length,
      presentationCount: presentations.filter((p) => p.studentName === student)
        .length,
    });
  };

  return (
    <div className="space-y-8">
      {/* Header & Student Filter */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#171923] dark:text-white">
            Dashboard Analitik &amp; Evaluasi Hasil Belajar
          </h2>
          <p className="mt-0.5 text-sm text-[#4A505E] dark:text-[#A3B1C6]">
            Pantau perkembangan nilai siswa secara menyeluruh, bandingkan performa per mata pelajaran, dan kirim rekap penilaian ke E-mail serta Google Drive.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedStudent}
            onChange={(e) => {
              playClickSound();
              setSelectedStudent(e.target.value);
            }}
            aria-label="Filter siswa"
            className="rounded-lg border border-[#D8D2C8] bg-white px-3 py-2 text-xs font-semibold text-[#171923] outline-none dark:border-[#272E3F] dark:bg-[#151923] dark:text-white"
          >
            <option value="ALL">Semua Siswa (Rata-rata Kelas)</option>
            {studentNames.map((name) => (
              <option key={name} value={name}>
                Siswa: {name}
              </option>
            ))}
          </select>

          {onRequestSendEmail && (
            <button
              type="button"
              onClick={() => {
                playClickSound();
                const rowsHtml = filteredQuizzes
                  .slice(0, 20)
                  .map(
                    (row) =>
                      `<tr><td style="padding:6px;border:1px solid #e5e7eb;">${row.studentName}</td><td style="padding:6px;border:1px solid #e5e7eb;">${row.className}</td><td style="padding:6px;border:1px solid #e5e7eb;text-align:right;">${row.score}</td><td style="padding:6px;border:1px solid #e5e7eb;text-align:right;">${typeof row.essayScore === 'number' ? row.essayScore : '-'}</td><td style="padding:6px;border:1px solid #e5e7eb;">${row.predicate}</td></tr>`
                  )
                  .join('');
                onRequestSendEmail({
                  subject: `[BHOLANG RUPA] Rekap Pemantauan & Penilaian (${selectedStudent === 'ALL' ? 'Semua Siswa' : selectedStudent})`,
                  summaryText: `Rata-rata kelas: ${stats.classAverage} | Ketuntasan KKM: ${stats.passRate}% | ${quizSubmissions.length} kuis, ${artworks.length} karya, ${presentations.length} presentasi.`,
                  htmlBody: `
                    <div style="font-family:sans-serif;max-width:680px;color:#171923;">
                      <h2 style="color:#1D4ED8;">Rekap Pemantauan & Evaluasi BHOLANG RUPA</h2>
                      <p><strong>Rata-rata Nilai:</strong> ${stats.classAverage} | <strong>Ketuntasan KKM (&ge;75):</strong> ${stats.passRate}%</p>
                      <p><strong>Total Kiriman:</strong> ${quizSubmissions.length} Kuis · ${artworks.length} Karya Gambar · ${presentations.length} Presentasi</p>
                      <table style="width:100%;border-collapse:collapse;font-size:12px;margin-top:12px;">
                        <thead><tr style="background:#f3f4f6;"><th style="padding:6px;border:1px solid #e5e7eb;text-align:left;">Siswa</th><th style="padding:6px;border:1px solid #e5e7eb;text-align:left;">Kelas</th><th style="padding:6px;border:1px solid #e5e7eb;text-align:right;">PG</th><th style="padding:6px;border:1px solid #e5e7eb;text-align:right;">Esai</th><th style="padding:6px;border:1px solid #e5e7eb;text-align:left;">Predikat</th></tr></thead>
                        <tbody>${rowsHtml}</tbody>
                      </table>
                      <p style="margin-top:16px;"><strong>Folder Google Drive Pemantauan:</strong> <a href="${DRIVE_FOLDER_URL}">${DRIVE_FOLDER_URL}</a></p>
                    </div>
                  `,
                });
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#059669] px-4 py-2 text-xs font-semibold text-white hover:bg-[#047857]"
            >
              <Mail className="h-4 w-4" />
              <span>Kirim Rekap ke E-mail</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleExportStudentPdf(activeStudentName)}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
          >
            <FileDown className="h-4 w-4" />
            <span>Ekspor Laporan PDF</span>
          </button>
        </div>
      </div>

      {/* 4 KPI Strip */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="text-xs font-medium text-[#646B7A] dark:text-[#94A3B8]">
            Rata-rata Nilai Kelas
          </div>
          <div className="font-mono-num mt-2 text-3xl font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
            {stats.classAverage}
          </div>
          <div className="mt-1 text-xs text-[#4A505E] dark:text-[#A3B1C6]">
            Skala 0 – 100
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="text-xs font-medium text-[#646B7A] dark:text-[#94A3B8]">
            Ketuntasan KKM (≥ 75)
          </div>
          <div className="font-mono-num mt-2 text-3xl font-bold text-[#059669] dark:text-[#34D399]">
            {stats.passRate}%
          </div>
          <div className="mt-1 text-xs text-[#4A505E] dark:text-[#A3B1C6]">
            Dari {stats.totalQuizzes} pengerjaan kuis
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="text-xs font-medium text-[#646B7A] dark:text-[#94A3B8]">
            Karya &amp; Presentasi
          </div>
          <div className="font-mono-num mt-2 text-3xl font-bold text-[#171923] dark:text-white">
            {stats.submissionsTotal}
          </div>
          <div className="mt-1 text-xs text-[#4A505E] dark:text-[#A3B1C6]">
            {artworks.length} gambar · {presentations.length} presentasi
          </div>
        </div>

        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="text-xs font-medium text-[#646B7A] dark:text-[#94A3B8]">
            Notifikasi Kiriman Baru
          </div>
          <div className="font-mono-num mt-2 text-3xl font-bold text-[#DC2626] dark:text-[#F87171]">
            {notifications.filter((n) => !n.read).length}
          </div>
          <div className="mt-1 text-xs text-[#4A505E] dark:text-[#A3B1C6]">
            Pembaruan real-time aktif
          </div>
        </div>
      </div>

      {/* Charts Row: Bar Chart Per Mata Pelajaran + Overall Score Progression */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Grafik Batang Perbandingan Performa Siswa per Mata Pelajaran */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-7 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Grafik Batang Performa Siswa per Mata Pelajaran
              </h3>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="inline-flex items-center gap-1.5 text-[#171923] dark:text-[#E2E8F0]">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-[#1D4ED8]" />
                <span>
                  {selectedStudent === 'ALL' ? 'Capaian Siswa' : selectedStudent}
                </span>
              </span>
              <span className="inline-flex items-center gap-1.5 text-[#4A505E] dark:text-[#A3B1C6]">
                <span className="inline-block h-2.5 w-2.5 rounded-sm bg-[#94A3B8]" />
                <span>Rata-rata Kelas</span>
              </span>
            </div>
          </div>

          <div className="mt-5 overflow-x-auto">
            <svg viewBox="0 0 640 270" className="min-w-[540px] w-full">
              {/* Horizontal Grid Lines */}
              {[0, 25, 50, 75, 100].map((val) => {
                const y = 210 - (val / 100) * 175;
                return (
                  <g key={val}>
                    <line
                      x1="42"
                      y1={y}
                      x2="620"
                      y2={y}
                      stroke="currentColor"
                      className="text-[#E5E0D8] dark:text-[#272E3F]"
                      strokeDasharray={val === 75 ? '4 4' : undefined}
                    />
                    <text
                      x="34"
                      y={y + 4}
                      textAnchor="end"
                      fontSize="10"
                      className="font-mono-num fill-[#646B7A] dark:fill-[#94A3B8]"
                    >
                      {val}
                    </text>
                  </g>
                );
              })}

              {/* Grouped Bars */}
              {subjectBarData.map((item, idx) => {
                const groupX = 56 + idx * 94;
                const studentH = (item.studentScore / 100) * 175;
                const classH = (item.classAverage / 100) * 175;
                const isHovered = hoveredBarIdx === idx;

                return (
                  <g
                    key={item.subject}
                    onMouseEnter={() => setHoveredBarIdx(idx)}
                    onMouseLeave={() => setHoveredBarIdx(null)}
                    className="cursor-pointer"
                  >
                    {/* Student Bar */}
                    <rect
                      x={groupX}
                      y={210 - studentH}
                      width="24"
                      height={studentH}
                      rx="4"
                      fill={isHovered ? '#2563EB' : '#1D4ED8'}
                    />
                    <text
                      x={groupX + 12}
                      y={210 - studentH - 6}
                      textAnchor="middle"
                      fontSize="10"
                      fontWeight="700"
                      className="font-mono-num fill-[#1D4ED8] dark:fill-[#60A5FA]"
                    >
                      {item.studentScore}
                    </text>

                    {/* Class Average Bar */}
                    <rect
                      x={groupX + 28}
                      y={210 - classH}
                      width="24"
                      height={classH}
                      rx="4"
                      fill="#94A3B8"
                      opacity={isHovered ? 0.95 : 0.72}
                    />
                    <text
                      x={groupX + 40}
                      y={210 - classH - 6}
                      textAnchor="middle"
                      fontSize="10"
                      className="font-mono-num fill-[#646B7A] dark:fill-[#94A3B8]"
                    >
                      {item.classAverage}
                    </text>

                    {/* X-axis Subject Label */}
                    <text
                      x={groupX + 26}
                      y="230"
                      textAnchor="middle"
                      fontSize="10"
                      className="fill-[#171923] font-medium dark:fill-[#CBD5E1]"
                    >
                      {item.subject.split(' ').slice(0, 2).join(' ')}
                    </text>
                    <text
                      x={groupX + 26}
                      y="244"
                      textAnchor="middle"
                      fontSize="9.5"
                      className="fill-[#646B7A] dark:fill-[#94A3B8]"
                    >
                      {item.subject.split(' ').slice(2).join(' ')}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {hoveredBarIdx !== null && subjectBarData[hoveredBarIdx] && (
            <div className="mt-2 rounded-lg bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] dark:bg-[#0D1017] dark:text-[#E2E8F0]">
              <strong>{subjectBarData[hoveredBarIdx].subject}</strong>: Skor{' '}
              <span className="font-mono-num font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                {subjectBarData[hoveredBarIdx].studentScore}
              </span>{' '}
              vs Rata-rata Kelas{' '}
              <span className="font-mono-num font-bold">
                {subjectBarData[hoveredBarIdx].classAverage}
              </span>
            </div>
          )}
        </div>

        {/* Perkembangan Nilai Siswa Secara Menyeluruh (Trend Chart) */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-[#059669]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Tren Perkembangan Nilai Kuis
              </h3>
            </div>
            <span className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
              {progressionPoints.length} Rekaman
            </span>
          </div>

          {progressionPoints.length === 0 ? (
            <div className="flex h-60 items-center justify-center text-xs text-[#646B7A] dark:text-[#94A3B8]">
              Belum ada data kuis untuk ditampilkan.
            </div>
          ) : (
            <div className="mt-5">
              <svg viewBox="0 0 420 220" className="w-full">
                {[50, 75, 100].map((v) => {
                  const y = 185 - ((v - 40) / 60) * 150;
                  return (
                    <g key={v}>
                      <line
                        x1="34"
                        y1={y}
                        x2="402"
                        y2={y}
                        stroke="currentColor"
                        className="text-[#E5E0D8] dark:text-[#272E3F]"
                        strokeDasharray={v === 75 ? '4 4' : undefined}
                      />
                      <text
                        x="28"
                        y={y + 3}
                        textAnchor="end"
                        fontSize="10"
                        className="font-mono-num fill-[#646B7A] dark:fill-[#94A3B8]"
                      >
                        {v}
                      </text>
                    </g>
                  );
                })}

                {progressionPoints.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="#059669"
                    strokeWidth="2.5"
                    points={progressionPoints
                      .map((p, idx) => {
                        const x =
                          46 +
                          (idx * 340) / Math.max(1, progressionPoints.length - 1);
                        const clamped = Math.max(40, Math.min(100, p.score));
                        const y = 185 - ((clamped - 40) / 60) * 150;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                )}

                {progressionPoints.map((p, idx) => {
                  const x =
                    progressionPoints.length === 1
                      ? 210
                      : 46 + (idx * 340) / (progressionPoints.length - 1);
                  const clamped = Math.max(40, Math.min(100, p.score));
                  const y = 185 - ((clamped - 40) / 60) * 150;
                  return (
                    <g key={p.id}>
                      <circle
                        cx={x}
                        cy={y}
                        r="5"
                        fill="#059669"
                        stroke="#FFFFFF"
                        strokeWidth="2"
                      />
                      <text
                        x={x}
                        y={y - 10}
                        textAnchor="middle"
                        fontSize="10"
                        fontWeight="700"
                        className="font-mono-num fill-[#171923] dark:fill-white"
                      >
                        {p.score}
                      </text>
                      <text
                        x={x}
                        y="204"
                        textAnchor="middle"
                        fontSize="9"
                        className="fill-[#646B7A] dark:fill-[#94A3B8]"
                      >
                        {p.studentName.split(' ')[0].slice(0, 7)}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          )}
        </div>
      </div>

      {/* Table Evaluasi Nilai + Real-Time Notifications Feed */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Quiz Evaluation Table */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-8 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-5 w-5 text-[#059669]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Rekap Evaluasi Kuis Siswa
              </h3>
            </div>
            <div className="relative">
              <Search className="pointer-events-none absolute top-2.5 left-3 h-3.5 w-3.5 text-[#646B7A]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari nama atau kelas..."
                className="rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] py-1.5 pr-3 pl-8 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              />
            </div>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#EEEAE2] text-[#646B7A] dark:border-[#272E3F] dark:text-[#94A3B8]">
                  <th className="py-2.5 pr-3 font-semibold">Siswa</th>
                  <th className="py-2.5 px-3 font-semibold">Kelas</th>
                  <th className="py-2.5 px-3 text-right font-semibold">PG</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Esai C1–C6</th>
                  <th className="py-2.5 px-3 font-semibold">Predikat</th>
                  <th className="py-2.5 pl-3 text-right font-semibold">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEEAE2] dark:divide-[#272E3F]">
                {filteredQuizzes.map((row) => {
                  const hasEssays = Boolean(
                    row.essayAnswers && row.essayAnswers.some((e) => e.answer.trim())
                  );
                  return (
                    <tr
                      key={row.id}
                      className="hover:bg-[#FAF9F7] dark:hover:bg-[#0D1017]/60"
                    >
                      <td className="py-3 pr-3 font-semibold text-[#171923] dark:text-white">
                        {row.studentName}
                      </td>
                      <td className="py-3 px-3 text-[#4A505E] dark:text-[#A3B1C6]">
                        {row.className}
                      </td>
                      <td className="font-mono-num py-3 px-3 text-right font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                        {row.score}
                      </td>
                      <td className="font-mono-num py-3 px-3 text-right">
                        {typeof row.essayScore === 'number' ? (
                          <span className="font-bold text-[#059669] dark:text-[#34D399]">
                            {row.essayScore}
                          </span>
                        ) : hasEssays ? (
                          <button
                            type="button"
                            onClick={() => {
                              playClickSound();
                              setReviewingQuizId(row.id);
                              setEssayGradeInput(row.essayScore ?? 85);
                            }}
                            className="font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                          >
                            Nilai Esai
                          </button>
                        ) : (
                          <span className="text-[#94A3B8]">-</span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`font-semibold ${
                            row.score >= 75
                              ? 'text-[#059669] dark:text-[#34D399]'
                              : 'text-[#D97706] dark:text-[#FBBF24]'
                          }`}
                        >
                          {row.predicate}
                        </span>
                      </td>
                      <td className="py-3 pl-3 text-right">
                        <div className="inline-flex items-center gap-2.5">
                          {hasEssays && (
                            <button
                              type="button"
                              onClick={() => {
                                playClickSound();
                                setReviewingQuizId(
                                  reviewingQuizId === row.id ? null : row.id
                                );
                                setEssayGradeInput(row.essayScore ?? 85);
                              }}
                              className="font-semibold text-[#059669] hover:underline dark:text-[#34D399]"
                            >
                              Esai
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleExportStudentPdf(row.studentName)}
                            className="inline-flex items-center gap-1 font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                          >
                            <FileDown className="h-3.5 w-3.5" />
                            <span>PDF</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Inline Teacher Essay Review & Grading Panel */}
          {reviewingQuizId &&
            (() => {
              const target = quizSubmissions.find((q) => q.id === reviewingQuizId);
              if (!target || !target.essayAnswers) return null;
              return (
                <div className="mt-5 rounded-xl border border-[#1D4ED8]/30 bg-[#FAF9F7] p-4 text-xs dark:border-[#3B82F6]/40 dark:bg-[#0D1017]">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E5E0D8] pb-2.5 dark:border-[#232A3B]">
                    <div>
                      <span className="font-bold text-[#171923] dark:text-white">
                        Jawaban Esai C1–C6: {target.studentName} ({target.className})
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setReviewingQuizId(null)}
                      className="font-semibold text-[#646B7A] hover:text-[#171923] dark:hover:text-white"
                    >
                      Tutup
                    </button>
                  </div>
                  <div className="mt-3 max-h-64 space-y-2.5 overflow-y-auto pr-1">
                    {target.essayAnswers.map((ea, i) => (
                      <div
                        key={ea.questionId}
                        className="rounded-lg border border-[#E5E0D8] bg-white p-3 dark:border-[#272E3F] dark:bg-[#151923]"
                      >
                        <div className="font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                          Esai {i + 1} · {ea.bloomLevel}
                        </div>
                        <p className="mt-0.5 font-semibold text-[#171923] dark:text-white">
                          {ea.question}
                        </p>
                        <p className="mt-1.5 text-[#4A505E] dark:text-[#CBD5E1]">
                          {ea.answer || '(Tidak dijawab)'}
                        </p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E0D8] pt-3 dark:border-[#232A3B]">
                    <label className="flex items-center gap-2 font-semibold text-[#171923] dark:text-white">
                      <span>Beri Skor Esai (0–100):</span>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={essayGradeInput}
                        onChange={(e) => setEssayGradeInput(Number(e.target.value))}
                        className="font-mono-num w-20 rounded-lg border border-[#D8D2C8] bg-white px-2.5 py-1 text-xs dark:border-[#2D3548] dark:bg-[#151923]"
                      />
                    </label>
                    <button
                      type="button"
                      disabled={savingEssayGrade}
                      onClick={async () => {
                        playClickSound();
                        setSavingEssayGrade(true);
                        try {
                          const res = await fetch(`/api/quiz/${target.id}/grade-essay`, {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ essayScore: essayGradeInput }),
                          });
                          const data = (await res.json()) as { item?: QuizSubmission };
                          if (res.ok && data.item) {
                            onQuizUpdated(data.item);
                            setReviewingQuizId(null);
                          }
                        } finally {
                          setSavingEssayGrade(false);
                        }
                      }}
                      className="rounded-lg bg-[#059669] px-4 py-1.5 font-semibold text-white hover:bg-[#047857] disabled:opacity-50"
                    >
                      {savingEssayGrade ? 'Menyimpan...' : 'Simpan Nilai Esai'}
                    </button>
                  </div>
                </div>
              );
            })()}
        </div>

        {/* Live Notifications Log */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-4 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Log Aktivitas Real-Time
              </h3>
            </div>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onMarkAllRead();
              }}
              className="text-xs font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
            >
              Tandai Dibaca
            </button>
          </div>

          <div className="mt-3 max-h-72 space-y-2.5 overflow-y-auto pr-1">
            {notifications.length === 0 ? (
              <p className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
                Belum ada kiriman masuk.
              </p>
            ) : (
              notifications.map((n) => (
                <div
                  key={n.id}
                  className={`rounded-xl border p-3 text-xs ${
                    n.read
                      ? 'border-[#EEEAE2] bg-[#FAF9F7] dark:border-[#232A3B] dark:bg-[#0D1017]'
                      : 'border-[#1D4ED8]/30 bg-[#EFF6FF] dark:border-[#3B82F6]/40 dark:bg-[#1E293B]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-bold text-[#171923] dark:text-white">
                      {n.studentName}
                    </span>
                    <span className="text-[10px] text-[#646B7A] dark:text-[#94A3B8]">
                      {new Date(n.createdAt).toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div className="mt-0.5 font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                    {n.title}
                  </div>
                  <p className="mt-0.5 text-[#4A505E] dark:text-[#CBD5E1]">{n.detail}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Gallery of Student Drawings & Live Google Drive Folder Browser */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Submitted Artworks */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-7 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Galeri Karya Praktik Siswa ({artworks.length})
              </h3>
            </div>
          </div>

          {artworks.length === 0 ? (
            <p className="mt-4 text-xs text-[#646B7A] dark:text-[#94A3B8]">
              Belum ada karya gambar yang dikirim siswa dari Studio Praktik.
            </p>
          ) : (
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {artworks.map((art) => (
                <div
                  key={art.id}
                  className={`overflow-hidden rounded-xl border bg-[#FAF9F7] dark:bg-[#0D1017] ${
                    art.pinned
                      ? 'border-[#D97706]/50 dark:border-[#FBBF24]/45'
                      : 'border-[#EEEAE2] dark:border-[#232A3B]'
                  }`}
                >
                  <div className="relative bg-white">
                    <img
                      src={art.imageDataUrl}
                      alt={art.title}
                      className="h-40 w-full bg-white object-contain"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        playClickSound();
                        const nextPinned = !art.pinned;
                        const res = await fetch(`/api/artworks/${art.id}/pin`, {
                          method: 'PATCH',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                            pinned: nextPinned,
                            actorName: profile.name,
                            actorRole: profile.role,
                          }),
                        });
                        const data = (await res.json()) as { item?: ArtworkSubmission };
                        if (res.ok && data.item) {
                          onArtworkUpdated(data.item);
                        }
                      }}
                      className={`absolute top-2 right-2 inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] font-semibold shadow-sm ${
                        art.pinned
                          ? 'border-[#D97706] bg-[#FEF3C7] text-[#92400E]'
                          : 'border-[#D8D2C8] bg-white/95 text-[#171923]'
                      }`}
                    >
                      <Pin className="h-3 w-3" />
                      <span>{art.pinned ? 'Dipin Pilihan' : 'Pin Terbaik'}</span>
                    </button>
                  </div>
                  <div className="p-3.5 text-xs">
                    <div className="font-bold text-[#171923] dark:text-white">{art.title}</div>
                    <div className="mt-0.5 flex items-center justify-between text-[#646B7A] dark:text-[#94A3B8]">
                      <span>
                        {art.studentName} · {art.className}
                      </span>
                      <span className="inline-flex items-center gap-1 font-mono-num text-[#DC2626] dark:text-[#F87171]">
                        <Heart className="h-3 w-3 fill-current" />
                        <span>{art.likedBy?.length ?? 0}</span>
                      </span>
                    </div>
                    {art.aiCritique && (
                      <p className="mt-2 line-clamp-3 text-[#4A505E] dark:text-[#CBD5E1]">
                        {art.aiCritique}
                      </p>
                    )}
                    <div className="mt-3 flex items-center justify-between gap-2 border-t border-[#EEEAE2] pt-2 dark:border-[#272E3F]">
                      <a
                        href={art.imageDataUrl}
                        download={`${art.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`}
                        onClick={() => playClickSound()}
                        className="inline-flex items-center gap-1 font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Unduh PNG</span>
                      </a>
                      {art.driveWebViewLink && (
                        <a
                          href={art.driveWebViewLink}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 font-semibold text-[#059669] hover:underline dark:text-[#34D399]"
                        >
                          <span>Lihat Drive</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Google Drive Folder Browser */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <FolderOpen className="h-5 w-5 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Berkas di Folder Google Drive
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={loadDriveFiles}
                disabled={loadingDrive}
                className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-2.5 py-1 text-xs font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <RefreshCw className={`h-3 w-3 ${loadingDrive ? 'animate-spin' : ''}`} />
                <span>Muat Berkas</span>
              </button>
              <a
                href={DRIVE_FOLDER_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-xs font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
              >
                <span>Buka Drive</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          </div>

          {driveError && (
            <p className="mt-3 text-xs text-[#DC2626] dark:text-red-300">{driveError}</p>
          )}

          {driveFiles.length === 0 ? (
            <div className="mt-4 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 text-xs text-[#4A505E] dark:border-[#232A3B] dark:bg-[#0D1017] dark:text-[#A3B1C6]">
              Klik &ldquo;Muat Berkas&rdquo; setelah masuk dengan akun Google untuk melihat gambar siswa, presentasi, dan spreadsheet evaluasi langsung dari folder Google Drive kelas.
            </div>
          ) : (
            <div className="mt-3 max-h-80 divide-y divide-[#EEEAE2] overflow-y-auto dark:divide-[#272E3F]">
              {driveFiles.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between gap-2 py-2.5 text-xs"
                >
                  <div className="min-w-0">
                    <div className="truncate font-semibold text-[#171923] dark:text-white">
                      {file.name}
                    </div>
                    <div className="text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                      {file.mimeType.includes('spreadsheet')
                        ? 'Google Sheets Evaluasi'
                        : file.mimeType.includes('image')
                          ? 'Gambar Praktik'
                          : 'Dokumen / Presentasi'}
                    </div>
                  </div>
                  {file.webViewLink && (
                    <a
                      href={file.webViewLink}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-semibold text-[#1D4ED8] hover:underline shrink-0 dark:text-[#60A5FA]"
                    >
                      <span>Buka</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
