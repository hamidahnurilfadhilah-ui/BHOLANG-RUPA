import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Bot,
  CheckCircle2,
  Circle,
  Download,
  Eraser,
  ExternalLink,
  FlipHorizontal2,
  Grid,
  Minus,
  Paintbrush,
  PenTool,
  Pencil,
  Radio,
  RotateCcw,
  Sparkles,
  Square,
  Undo2,
  UploadCloud,
  Users,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { DRIVE_FOLDER_URL } from '../data/learningContent';
import type {
  ArtworkSubmission,
  CollabBlendOp,
  CollabCursor,
  CollabMirrorMode,
  CollabParticipant,
  CollabStroke,
  CollabToolType,
  UserProfile,
} from '../types';
import {
  dataUrlToBlob,
  getCachedAccessToken,
  uploadBlobToDriveFolder,
} from '../utils/firebaseGoogle';
import { playClickSound } from '../utils/sound';

interface CollabCanvasStudioProps {
  profile: UserProfile;
  wsConnected: boolean;
  sendWs: (event: string, payload: unknown) => void;
  subscribeWs: (listener: (event: string, payload: unknown) => void) => () => void;
  onArtworkSubmitted: (item: ArtworkSubmission) => void;
  onRequireGoogleLogin: () => void;
  onRequestSendEmail?: (payload: {
    subject: string;
    summaryText: string;
    htmlBody: string;
  }) => void;
}

interface CritiqueResult {
  ringkasan?: string;
  unsurMenonjol?: string[];
  prinsipTerlihat?: string[];
  saranPengembangan?: string;
}

const CANVAS_W = 880;
const CANVAS_H = 500;

const PRESET_ROOMS = [
  { id: 'ruang-utama', label: 'Ruang Utama' },
  { id: 'kelompok-1', label: 'Kelompok 1' },
  { id: 'kelompok-2', label: 'Kelompok 2' },
  { id: 'kelompok-3', label: 'Kelompok 3' },
] as const;

const PALETTE_SWATCHES = [
  '#171923',
  '#1D4ED8',
  '#DC2626',
  '#EAB308',
  '#059669',
  '#7C3AED',
  '#EA580C',
  '#EC4899',
  '#0EA5E9',
  '#FFFFFF',
];

const COLLABORATOR_BADGE_COLORS = [
  '#1D4ED8',
  '#DC2626',
  '#059669',
  '#7C3AED',
  '#EA580C',
  '#0891B2',
  '#DB2777',
];

function hashString(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number): () => number {
  let t = seed >>> 0;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function getSessionUserId(): string {
  try {
    const existing = sessionStorage.getItem('bholang_collab_uid');
    if (existing) return existing;
    const created = `u-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    sessionStorage.setItem('bholang_collab_uid', created);
    return created;
  } catch {
    return `u-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  }
}

function getMirroredPointsForMode(
  x: number,
  y: number,
  mode: CollabMirrorMode
): { x: number; y: number }[] {
  const pts = [{ x, y }];
  if (mode === 'horizontal' || mode === 'quad') {
    pts.push({ x: CANVAS_W - x, y });
  }
  if (mode === 'vertical' || mode === 'quad') {
    pts.push({ x, y: CANVAS_H - y });
  }
  if (mode === 'quad') {
    pts.push({ x: CANVAS_W - x, y: CANVAS_H - y });
  }
  return pts;
}

function drawCollabStroke(ctx: CanvasRenderingContext2D, stroke: CollabStroke) {
  if (!stroke.points || stroke.points.length === 0) return;

  ctx.save();
  ctx.globalCompositeOperation = stroke.tool === 'eraser' ? 'destination-out' : stroke.blendMode;
  ctx.globalAlpha = stroke.tool === 'eraser' ? 1 : Math.max(0.05, Math.min(1, stroke.opacity / 100));
  ctx.strokeStyle = stroke.color;
  ctx.fillStyle = stroke.color;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const pts = stroke.points;
  const first = pts[0];
  const last = pts[pts.length - 1];

  if (stroke.tool === 'line' || stroke.tool === 'rect' || stroke.tool === 'circle') {
    const mStarts = getMirroredPointsForMode(first.x, first.y, stroke.mirrorMode);
    const mEnds = getMirroredPointsForMode(last.x, last.y, stroke.mirrorMode);
    ctx.lineWidth = stroke.size;
    mStarts.forEach((ms, idx) => {
      const me = mEnds[idx];
      ctx.beginPath();
      if (stroke.tool === 'line') {
        ctx.moveTo(ms.x, ms.y);
        ctx.lineTo(me.x, me.y);
      } else if (stroke.tool === 'rect') {
        ctx.rect(ms.x, ms.y, me.x - ms.x, me.y - ms.y);
      } else if (stroke.tool === 'circle') {
        const r = Math.hypot(me.x - ms.x, me.y - ms.y);
        ctx.arc(ms.x, ms.y, r, 0, Math.PI * 2);
      }
      ctx.stroke();
    });
    ctx.restore();
    return;
  }

  const mirrorBranches = getMirroredPointsForMode(first.x, first.y, stroke.mirrorMode).length;
  const mirroredSequences: { x: number; y: number }[][] = Array.from(
    { length: mirrorBranches },
    () => []
  );

  for (const p of pts) {
    const mPts = getMirroredPointsForMode(p.x, p.y, stroke.mirrorMode);
    mPts.forEach((mp, idx) => {
      mirroredSequences[idx]?.push(mp);
    });
  }

  const rng = mulberry32(hashString(stroke.id));

  for (const seq of mirroredSequences) {
    if (seq.length === 0) continue;

    if (stroke.tool === 'brush' || stroke.tool === 'eraser' || stroke.tool === 'pencil') {
      if (stroke.tool === 'pencil') {
        ctx.lineWidth = Math.max(1.2, stroke.size * 0.35);
        ctx.globalAlpha = Math.min(0.85, (stroke.opacity / 100) * 0.85);
      } else {
        ctx.lineWidth = stroke.size;
      }

      if (seq.length === 1) {
        ctx.beginPath();
        ctx.arc(seq[0].x, seq[0].y, ctx.lineWidth / 2, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(seq[0].x, seq[0].y);
        for (let i = 1; i < seq.length - 1; i += 1) {
          const midX = (seq[i].x + seq[i + 1].x) / 2;
          const midY = (seq[i].y + seq[i + 1].y) / 2;
          ctx.quadraticCurveTo(seq[i].x, seq[i].y, midX, midY);
        }
        ctx.lineTo(seq[seq.length - 1].x, seq[seq.length - 1].y);
        ctx.stroke();
      }
    } else if (stroke.tool === 'calligraphy') {
      for (let i = 0; i < seq.length; i += 1) {
        const from = i === 0 ? seq[0] : seq[i - 1];
        const to = seq[i];
        const dist = Math.hypot(to.x - from.x, to.y - from.y);
        const steps = Math.max(1, Math.ceil(dist / 2));
        for (let s = 0; s <= steps; s += 1) {
          const t = s / steps;
          const x = from.x + (to.x - from.x) * t;
          const y = from.y + (to.y - from.y) * t;
          ctx.save();
          ctx.translate(x, y);
          ctx.rotate(-Math.PI / 5);
          ctx.fillRect(-stroke.size * 0.65, -stroke.size * 0.16, stroke.size * 1.3, stroke.size * 0.32);
          ctx.restore();
        }
      }
    } else if (stroke.tool === 'stipple') {
      const dotCount = Math.max(6, Math.round(stroke.size * 1.1));
      const radius = stroke.size * 1.35;
      for (let i = 0; i < seq.length; i += 1) {
        const pt = seq[i];
        for (let d = 0; d < dotCount; d += 1) {
          const angle = rng() * Math.PI * 2;
          const r = Math.sqrt(rng()) * radius;
          const dx = pt.x + Math.cos(angle) * r;
          const dy = pt.y + Math.sin(angle) * r;
          const dotR = Math.max(0.7, rng() * (stroke.size * 0.22));
          ctx.beginPath();
          ctx.arc(dx, dy, dotR, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    } else if (stroke.tool === 'crayon') {
      for (let i = 0; i < seq.length; i += 1) {
        const from = i === 0 ? seq[0] : seq[i - 1];
        const to = seq[i];
        const dist = Math.hypot(to.x - from.x, to.y - from.y);
        const steps = Math.max(1, Math.ceil(dist / 3));
        for (let s = 0; s <= steps; s += 1) {
          const t = s / steps;
          const cx = from.x + (to.x - from.x) * t;
          const cy = from.y + (to.y - from.y) * t;
          for (let g = 0; g < 12; g += 1) {
            const gx = cx + (rng() - 0.5) * stroke.size;
            const gy = cy + (rng() - 0.5) * stroke.size;
            ctx.fillRect(gx, gy, 1.6, 1.6);
          }
        }
      }
    }
  }

  ctx.restore();
}

export const CollabCanvasStudio: React.FC<CollabCanvasStudioProps> = ({
  profile,
  wsConnected,
  sendWs,
  subscribeWs,
  onArtworkSubmitted,
  onRequireGoogleLogin,
  onRequestSendEmail,
}) => {
  const userIdRef = useRef<string>(getSessionUserId());
  const myPresenceColor = useMemo(() => {
    const idx = hashString(userIdRef.current) % COLLABORATOR_BADGE_COLORS.length;
    return COLLABORATOR_BADGE_COLORS[idx];
  }, []);

  const [roomId, setRoomId] = useState<string>('ruang-utama');
  const [customRoomInput, setCustomRoomInput] = useState<string>('');
  const [participants, setParticipants] = useState<CollabParticipant[]>([]);
  const [strokes, setStrokes] = useState<CollabStroke[]>([]);
  const [cursors, setCursors] = useState<Record<string, CollabCursor>>({});
  const [roomNotice, setRoomNotice] = useState<string>('');
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  // Brush / Drawing Controls
  const [tool, setTool] = useState<CollabToolType>('brush');
  const [color, setColor] = useState('#1D4ED8');
  const [brushSize, setBrushSize] = useState(10);
  const [brushOpacity, setBrushOpacity] = useState(100);
  const [strokeBlend, setStrokeBlend] = useState<CollabBlendOp>('source-over');
  const [mirrorMode, setMirrorMode] = useState<CollabMirrorMode>('none');
  const [showGrid, setShowGrid] = useState(true);

  // Artwork submission metadata
  const [artTitle, setArtTitle] = useState('Karya Kolaborasi Kanvas Bersama');
  const [artDesc, setArtDesc] = useState('');
  const [critiqueLoading, setCritiqueLoading] = useState(false);
  const [critique, setCritique] = useState<CritiqueResult | null>(null);
  const [critiqueError, setCritiqueError] = useState('');
  const [submittingArt, setSubmittingArt] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{
    ok: boolean;
    message: string;
    driveLink?: string;
  } | null>(null);

  // Canvas & Live Streaming Refs
  const baseCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const overlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const strokesSurfaceRef = useRef<HTMLCanvasElement | null>(null);

  const isDrawingRef = useRef(false);
  const myActiveStrokeRef = useRef<CollabStroke | null>(null);
  const peerLiveStrokesRef = useRef<Map<string, CollabStroke>>(new Map());
  const lastCursorEmitRef = useRef<number>(0);
  const lastLiveStrokeEmitRef = useRef<number>(0);

  // Render committed strokes onto baseCanvas (using offscreen transparent surface so eraser/blend works cleanly over white paper)
  const renderCommittedBase = useCallback(() => {
    const base = baseCanvasRef.current;
    if (!base) return;
    const baseCtx = base.getContext('2d');
    if (!baseCtx) return;

    if (!strokesSurfaceRef.current) {
      const off = document.createElement('canvas');
      off.width = CANVAS_W;
      off.height = CANVAS_H;
      strokesSurfaceRef.current = off;
    }
    const surface = strokesSurfaceRef.current;
    const sCtx = surface.getContext('2d');
    if (!sCtx) return;

    sCtx.clearRect(0, 0, CANVAS_W, CANVAS_H);
    for (const s of strokes) {
      drawCollabStroke(sCtx, s);
    }

    baseCtx.clearRect(0, 0, CANVAS_W, CANVAS_H);
    baseCtx.fillStyle = '#FFFFFF';
    baseCtx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    baseCtx.drawImage(surface, 0, 0);
  }, [strokes]);

  const renderLiveOverlay = useCallback(() => {
    const overlay = overlayCanvasRef.current;
    if (!overlay) return;
    const ctx = overlay.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
    peerLiveStrokesRef.current.forEach((peerStroke) => {
      if (peerStroke.tool !== 'eraser') {
        drawCollabStroke(ctx, peerStroke);
      }
    });
    if (myActiveStrokeRef.current) {
      if (myActiveStrokeRef.current.tool === 'eraser') {
        drawCollabStroke(ctx, { ...myActiveStrokeRef.current, tool: 'brush', color: '#FFFFFF', blendMode: 'source-over' });
      } else {
        drawCollabStroke(ctx, myActiveStrokeRef.current);
      }
    }
  }, []);

  useEffect(() => {
    renderCommittedBase();
  }, [renderCommittedBase]);

  // Prune stale peer cursors after 5 seconds of inactivity
  useEffect(() => {
    const timer = window.setInterval(() => {
      const now = Date.now();
      setCursors((prev) => {
        let changed = false;
        const next: Record<string, CollabCursor> = {};
        for (const [uid, cur] of Object.entries(prev)) {
          if (now - cur.lastSeen < 5000) {
            next[uid] = cur;
          } else {
            changed = true;
          }
        }
        return changed ? next : prev;
      });
    }, 1500);
    return () => window.clearInterval(timer);
  }, []);

  // Join collaborative room whenever wsConnected is ready or room/profile changes
  useEffect(() => {
    if (!wsConnected) return;
    sendWs('collab:join', {
      roomId,
      userId: userIdRef.current,
      userName: profile.name,
      className: profile.className,
      color: myPresenceColor,
    });

    return () => {
      sendWs('collab:leave', { roomId });
    };
  }, [wsConnected, roomId, profile.name, profile.className, myPresenceColor, sendWs]);

  // Subscribe to WebSocket collaborative events
  useEffect(() => {
    const unsub = subscribeWs((event, payload) => {
      if (!payload || typeof payload !== 'object') return;
      const data = payload as Record<string, unknown>;
      if (data.roomId !== roomId) return;

      if (event === 'collab:init') {
        const initStrokes = Array.isArray(data.strokes) ? (data.strokes as CollabStroke[]) : [];
        const initParts = Array.isArray(data.participants)
          ? (data.participants as CollabParticipant[])
          : [];
        peerLiveStrokesRef.current.clear();
        setStrokes(initStrokes);
        setParticipants(initParts);
        setCursors({});
        renderLiveOverlay();
      } else if (event === 'collab:sync') {
        const nextStrokes = Array.isArray(data.strokes) ? (data.strokes as CollabStroke[]) : [];
        setStrokes(nextStrokes);
      } else if (event === 'collab:presence') {
        const nextParts = Array.isArray(data.participants)
          ? (data.participants as CollabParticipant[])
          : [];
        setParticipants(nextParts);
      } else if (event === 'collab:stroke') {
        const stroke = data.stroke as CollabStroke | undefined;
        if (!stroke || !stroke.id) return;
        peerLiveStrokesRef.current.delete(stroke.userId);
        renderLiveOverlay();
        setStrokes((prev) => (prev.some((s) => s.id === stroke.id) ? prev : [...prev, stroke]));
      } else if (event === 'collab:stroke:live') {
        const stroke = data.stroke as CollabStroke | undefined;
        if (!stroke || stroke.userId === userIdRef.current) return;
        peerLiveStrokesRef.current.set(stroke.userId, stroke);
        renderLiveOverlay();
      } else if (event === 'collab:cursor') {
        const uid = String(data.userId || '');
        if (!uid || uid === userIdRef.current) return;
        setCursors((prev) => ({
          ...prev,
          [uid]: {
            userId: uid,
            userName: String(data.userName || 'Siswa'),
            color: String(data.color || '#1D4ED8'),
            x: Number(data.x ?? 0),
            y: Number(data.y ?? 0),
            lastSeen: Date.now(),
          },
        }));
      } else if (event === 'collab:cleared') {
        peerLiveStrokesRef.current.clear();
        myActiveStrokeRef.current = null;
        setStrokes([]);
        renderLiveOverlay();
        setRoomNotice(
          `Kanvas ruang "${roomId}" dibersihkan oleh ${String(data.actorName || 'kolaborator')}.`
        );
        window.setTimeout(() => setRoomNotice(''), 4000);
      }
    });

    return unsub;
  }, [roomId, subscribeWs, renderLiveOverlay]);

  const getCanvasCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = overlayCanvasRef.current ?? baseCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(CANVAS_W, ((e.clientX - rect.left) / rect.width) * CANVAS_W)),
      y: Math.max(0, Math.min(CANVAS_H, ((e.clientY - rect.top) / rect.height) * CANVAS_H)),
    };
  };

  const emitCursorThrottled = (pt: { x: number; y: number }) => {
    const now = Date.now();
    if (now - lastCursorEmitRef.current < 60) return;
    lastCursorEmitRef.current = now;
    sendWs('collab:cursor', {
      roomId,
      userId: userIdRef.current,
      userName: profile.name,
      color: myPresenceColor,
      x: Math.round(pt.x),
      y: Math.round(pt.y),
    });
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = overlayCanvasRef.current ?? baseCanvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);

    const pt = getCanvasCoords(e);
    isDrawingRef.current = true;
    emitCursorThrottled(pt);

    const newStroke: CollabStroke = {
      id: `st-${userIdRef.current}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      roomId,
      userId: userIdRef.current,
      userName: profile.name,
      color,
      tool,
      size: brushSize,
      opacity: brushOpacity,
      blendMode: strokeBlend,
      mirrorMode,
      points: [{ x: Math.round(pt.x * 10) / 10, y: Math.round(pt.y * 10) / 10 }],
      createdAt: new Date().toISOString(),
    };
    myActiveStrokeRef.current = newStroke;
    renderLiveOverlay();
    sendWs('collab:stroke:live', { stroke: newStroke });
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const pt = getCanvasCoords(e);
    emitCursorThrottled(pt);

    if (!isDrawingRef.current || !myActiveStrokeRef.current) return;

    const roundedPt = {
      x: Math.round(pt.x * 10) / 10,
      y: Math.round(pt.y * 10) / 10,
    };

    const active = myActiveStrokeRef.current;
    if (active.tool === 'line' || active.tool === 'rect' || active.tool === 'circle') {
      active.points = [active.points[0], roundedPt];
    } else {
      const prevPt = active.points[active.points.length - 1];
      if (!prevPt || Math.hypot(roundedPt.x - prevPt.x, roundedPt.y - prevPt.y) >= 1.5) {
        active.points.push(roundedPt);
      }
    }

    renderLiveOverlay();

    const now = Date.now();
    if (now - lastLiveStrokeEmitRef.current >= 55) {
      lastLiveStrokeEmitRef.current = now;
      sendWs('collab:stroke:live', { stroke: active });
    }
  };

  const finishStroke = () => {
    if (!isDrawingRef.current || !myActiveStrokeRef.current) return;
    isDrawingRef.current = false;
    const finished = myActiveStrokeRef.current;
    myActiveStrokeRef.current = null;
    renderLiveOverlay();

    // Optimistic append; server idempotently stores & broadcasts to room
    setStrokes((prev) => (prev.some((s) => s.id === finished.id) ? prev : [...prev, finished]));
    sendWs('collab:stroke', { stroke: finished });
  };

  const handleUndoMine = () => {
    playClickSound();
    sendWs('collab:undo', { roomId, userId: userIdRef.current });
  };

  const handleConfirmClearRoom = () => {
    playClickSound();
    setConfirmClearOpen(false);
    sendWs('collab:clear', { roomId, actorName: profile.name });
  };

  const getFlattenedDataUrl = (): string => {
    const flat = document.createElement('canvas');
    flat.width = CANVAS_W;
    flat.height = CANVAS_H;
    const ctx = flat.getContext('2d');
    if (!ctx) return '';
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    if (baseCanvasRef.current) {
      ctx.drawImage(baseCanvasRef.current, 0, 0);
    }
    return flat.toDataURL('image/png');
  };

  const downloadArtwork = () => {
    playClickSound();
    const dataUrl = getFlattenedDataUrl();
    if (!dataUrl) return;
    const link = document.createElement('a');
    const safeTitle = (artTitle || 'kanvas-bersama-bholang-rupa')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-');
    link.download = `${safeTitle}.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleRequestAiCritique = async () => {
    playClickSound();
    setCritiqueLoading(true);
    setCritiqueError('');
    try {
      const imageDataUrl = getFlattenedDataUrl();
      const res = await fetch('/api/ai/critique-artwork', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageDataUrl, title: artTitle }),
      });
      const data = (await res.json()) as { critique?: CritiqueResult; error?: string };
      if (!res.ok) throw new Error(data.error || 'Gagal menganalisis karya.');
      setCritique(data.critique ?? null);
    } catch (err) {
      setCritiqueError(err instanceof Error ? err.message : 'Gagal terhubung ke AI.');
    } finally {
      setCritiqueLoading(false);
    }
  };

  const handleSubmitArtwork = async () => {
    playClickSound();
    setSubmittingArt(true);
    setSubmitStatus(null);
    try {
      const imageDataUrl = getFlattenedDataUrl();
      let driveFileId: string | undefined;
      let driveWebViewLink: string | undefined;

      const token = getCachedAccessToken();
      if (token) {
        const blob = await dataUrlToBlob(imageDataUrl);
        const fileName = `Kolaborasi_${roomId}_${profile.name.replace(/\s+/g, '_')}_${Date.now()}.png`;
        const driveRes = await uploadBlobToDriveFolder(blob, fileName, 'image/png');
        driveFileId = driveRes.id;
        driveWebViewLink = driveRes.webViewLink;
      }

      const collaboratorNames = Array.from(
        new Set([profile.name, ...participants.map((p) => p.userName)])
      ).join(', ');
      const critiqueSummary = critique?.ringkasan
        ? `${critique.ringkasan} Saran: ${critique.saranPengembangan || ''}`
        : undefined;

      const res = await fetch('/api/submissions/artwork', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: collaboratorNames,
          className: profile.className,
          title: artTitle || `Karya Kanvas Bersama (${roomId})`,
          description:
            artDesc.trim() ||
            `Karya kolaborasi real-time di ruang "${roomId}" dengan ${strokes.length} goresan bersama.`,
          imageDataUrl,
          aiCritique: critiqueSummary,
          driveFileId,
          driveWebViewLink,
        }),
      });
      const data = (await res.json()) as { item?: ArtworkSubmission; error?: string };
      if (!res.ok || !data.item) throw new Error(data.error || 'Gagal mengirim karya.');

      onArtworkSubmitted(data.item);
      setSubmitStatus({
        ok: true,
        message: driveWebViewLink
          ? 'Karya Kanvas Bersama berhasil diunggah ke Google Drive dan tampil di Galeri Kelas secara real-time!'
          : 'Karya Kanvas Bersama berhasil dikirim ke Galeri Kelas secara real-time. Hubungkan Google jika ingin menyimpan salinan ke Drive.',
        driveLink: driveWebViewLink,
      });
    } catch (err) {
      setSubmitStatus({
        ok: false,
        message: err instanceof Error ? err.message : 'Gagal mengirim karya.',
      });
    } finally {
      setSubmittingArt(false);
    }
  };

  const myStrokeCount = useMemo(
    () => strokes.filter((s) => s.userId === userIdRef.current).length,
    [strokes]
  );

  const handleJoinCustomRoom = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = customRoomInput
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9-_]+/g, '-');
    if (!cleaned) return;
    playClickSound();
    setRoomId(cleaned);
    setCustomRoomInput('');
  };

  return (
    <div className="space-y-5">
      {/* Room & Live Collaborator Presence Bar */}
      <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#EEEAE2] pb-4 dark:border-[#272E3F]">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Kanvas Bersama Real-Time (WebSocket Kolaborasi Siswa)
              </h3>
              <span
                className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-semibold ${
                  wsConnected
                    ? 'bg-emerald-50 text-[#059669] dark:bg-emerald-950/40 dark:text-[#34D399]'
                    : 'bg-amber-50 text-[#D97706] dark:bg-amber-950/40 dark:text-amber-300'
                }`}
              >
                {wsConnected ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
                <span>{wsConnected ? 'WebSocket Aktif' : 'Menghubungkan...'}</span>
              </span>
            </div>
            <p className="text-xs text-[#4A505E] dark:text-[#A3B1C6]">
              Pilih ruang kelompok yang sama (atau buat kode ruang bersama temanmu) untuk menggambar serempak di satu kanvas dengan kursor &amp; goresan langsung.
            </p>
          </div>

          <form onSubmit={handleJoinCustomRoom} className="flex items-center gap-2">
            <input
              type="text"
              value={customRoomInput}
              onChange={(e) => setCustomRoomInput(e.target.value)}
              placeholder="Kode ruang kustom..."
              className="w-40 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-1.5 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
            />
            <button
              type="submit"
              className="rounded-lg bg-[#171923] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#1D4ED8] dark:bg-[#2563EB]"
            >
              Masuk Ruang
            </button>
          </form>
        </div>

        <div className="mt-3.5 flex flex-wrap items-center justify-between gap-3">
          {/* Room Preset Selector */}
          <div className="flex flex-wrap items-center gap-1.5">
            {PRESET_ROOMS.map((room) => (
              <button
                key={room.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  setRoomId(room.id);
                }}
                className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                  roomId === room.id
                    ? 'border-[#1D4ED8] bg-[#EFF6FF] text-[#1D4ED8] dark:border-[#60A5FA] dark:bg-[#1E293B] dark:text-[#60A5FA]'
                    : 'border-[#E5E0D8] bg-[#FAF9F7] text-[#4A505E] hover:bg-[#EFECE6] dark:border-[#272E3F] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                }`}
              >
                {room.label}
              </button>
            ))}
            {!PRESET_ROOMS.some((r) => r.id === roomId) && (
              <span className="rounded-lg border border-[#1D4ED8] bg-[#EFF6FF] px-3 py-1.5 text-xs font-semibold text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]">
                Ruang: {roomId}
              </span>
            )}
          </div>

          {/* Active Collaborators List */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="flex items-center gap-1 font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
              <Radio className="h-3.5 w-3.5 text-[#059669]" />
              <span>Aktif di Ruang ({participants.length}):</span>
            </span>
            {participants.length === 0 ? (
              <span className="text-[#646B7A] dark:text-[#94A3B8]">Menunggu sinkronisasi...</span>
            ) : (
              participants.map((p) => {
                const isMe = p.userId === userIdRef.current;
                return (
                  <span
                    key={p.userId}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#E5E0D8] bg-[#FAF9F7] px-2.5 py-1 text-[11px] font-semibold text-[#171923] dark:border-[#272E3F] dark:bg-[#0D1017] dark:text-white"
                  >
                    <span
                      style={{ backgroundColor: p.color }}
                      className="h-2.5 w-2.5 rounded-full"
                    />
                    <span>
                      {p.userName} ({p.className}){isMe ? ' • Kamu' : ''}
                    </span>
                  </span>
                );
              })
            )}
          </div>
        </div>

        {roomNotice && (
          <div className="mt-3 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-3 py-2 text-xs font-medium text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]">
            {roomNotice}
          </div>
        )}
      </div>

      {/* Collaborative Workspace Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left/Center: Shared Canvas & Brushes */}
        <div className="space-y-4 rounded-2xl border border-[#E5E0D8] bg-white p-5 lg:col-span-8 dark:border-[#272E3F] dark:bg-[#151923]">
          {/* Tool Row & Collaborative Actions */}
          <div className="space-y-2.5 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-bold text-[#171923] dark:text-white">
                Alat Gambar Kolaborasi ({strokes.length} goresan tercatat)
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  disabled={myStrokeCount === 0}
                  onClick={handleUndoMine}
                  className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-2.5 py-1.5 text-xs font-semibold text-[#171923] disabled:opacity-40 dark:border-[#2D3548] dark:text-white"
                >
                  <Undo2 className="h-3.5 w-3.5" />
                  <span>Undo Goresanku ({myStrokeCount})</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setShowGrid((v) => !v);
                  }}
                  className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-medium ${
                    showGrid
                      ? 'border-[#1D4ED8] bg-[#EFF6FF] text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]'
                      : 'border-[#D8D2C8] text-[#4A505E] dark:border-[#2D3548] dark:text-[#A3B1C6]'
                  }`}
                >
                  <Grid className="h-3.5 w-3.5" />
                  <span>Kisi</span>
                </button>
                {!confirmClearOpen ? (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setConfirmClearOpen(true);
                    }}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-2.5 py-1.5 text-xs font-medium text-[#DC2626] hover:bg-red-50 dark:border-[#2D3548] dark:hover:bg-red-950/30"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Bersihkan Ruang</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-1 rounded-lg border border-[#DC2626]/40 bg-red-50 px-2 py-1 text-[11px] dark:bg-red-950/30">
                    <span className="font-semibold text-[#991B1B] dark:text-red-200">
                      Hapus semua goresan ruang?
                    </span>
                    <button
                      type="button"
                      onClick={handleConfirmClearRoom}
                      className="rounded bg-[#DC2626] px-2 py-0.5 font-bold text-white"
                    >
                      Ya
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setConfirmClearOpen(false);
                      }}
                      className="rounded border border-[#D8D2C8] bg-white px-2 py-0.5 font-semibold text-[#171923] dark:bg-[#151923] dark:text-white"
                    >
                      Batal
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Tool Buttons */}
            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  { id: 'brush', label: 'Kuas Halus', Icon: Paintbrush },
                  { id: 'pencil', label: 'Pensil', Icon: Pencil },
                  { id: 'calligraphy', label: 'Kaligrafi', Icon: PenTool },
                  { id: 'stipple', label: 'Kuas Bintik', Icon: Sparkles },
                  { id: 'crayon', label: 'Krayon', Icon: Pencil },
                  { id: 'line', label: 'Garis', Icon: Minus },
                  { id: 'rect', label: 'Bidang', Icon: Square },
                  { id: 'circle', label: 'Lingkaran', Icon: Circle },
                  { id: 'eraser', label: 'Penghapus', Icon: Eraser },
                ] as const
              ).map(({ id, label, Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setTool(id);
                  }}
                  className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    tool === id
                      ? 'bg-[#1D4ED8] text-white'
                      : 'bg-[#FAF9F7] text-[#4A505E] hover:bg-[#EFECE6] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Color, Size, Opacity, Blend */}
          <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              {PALETTE_SWATCHES.map((swatch) => (
                <button
                  key={swatch}
                  type="button"
                  aria-label={`Pilih warna ${swatch}`}
                  onClick={() => {
                    playClickSound();
                    setColor(swatch);
                    if (tool === 'eraser') setTool('brush');
                  }}
                  style={{ backgroundColor: swatch }}
                  className={`h-6 w-6 rounded-full border transition-transform ${
                    color === swatch && tool !== 'eraser'
                      ? 'scale-110 ring-2 ring-[#1D4ED8] ring-offset-1'
                      : 'border-[#CBD5E1]'
                  }`}
                />
              ))}
              <input
                type="color"
                value={color}
                onChange={(e) => {
                  setColor(e.target.value);
                  if (tool === 'eraser') setTool('brush');
                }}
                aria-label="Pilih warna bebas"
                className="h-6 w-8 cursor-pointer rounded border border-[#D8D2C8] bg-transparent p-0"
              />
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <label className="flex items-center gap-1.5 font-medium text-[#4A505E] dark:text-[#A3B1C6]">
                <span>Ukuran:</span>
                <input
                  type="range"
                  min={1}
                  max={48}
                  value={brushSize}
                  onChange={(e) => setBrushSize(Number(e.target.value))}
                  className="w-16 accent-[#1D4ED8]"
                />
                <span className="font-mono-num w-8">{brushSize}px</span>
              </label>

              <label className="flex items-center gap-1.5 font-medium text-[#4A505E] dark:text-[#A3B1C6]">
                <span>Opasitas:</span>
                <input
                  type="range"
                  min={10}
                  max={100}
                  value={brushOpacity}
                  onChange={(e) => setBrushOpacity(Number(e.target.value))}
                  className="w-16 accent-[#1D4ED8]"
                />
                <span className="font-mono-num w-8">{brushOpacity}%</span>
              </label>

              <label className="flex items-center gap-1.5 font-medium text-[#4A505E] dark:text-[#A3B1C6]">
                <span>Blend:</span>
                <select
                  value={strokeBlend}
                  onChange={(e) => setStrokeBlend(e.target.value as CollabBlendOp)}
                  className="rounded border border-[#D8D2C8] bg-[#FAF9F7] px-2 py-1 text-xs font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  <option value="source-over">Normal</option>
                  <option value="multiply">Multiply</option>
                  <option value="screen">Screen</option>
                  <option value="overlay">Overlay</option>
                  <option value="darken">Darken</option>
                  <option value="lighten">Lighten</option>
                </select>
              </label>
            </div>
          </div>

          {/* Mirror Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] px-3.5 py-2 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
            <div className="flex items-center gap-2 font-semibold text-[#171923] dark:text-white">
              <FlipHorizontal2 className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <span>Simetri Mirror:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(
                [
                  { id: 'none', label: 'Mati' },
                  { id: 'horizontal', label: 'Horizontal' },
                  { id: 'vertical', label: 'Vertikal' },
                  { id: 'quad', label: '4-Arah' },
                ] as const
              ).map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setMirrorMode(m.id);
                  }}
                  className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                    mirrorMode === m.id
                      ? 'bg-[#1D4ED8] text-white'
                      : 'bg-white text-[#4A505E] hover:bg-[#EFECE6] dark:bg-[#151923] dark:text-[#A3B1C6]'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Dual Canvas Viewport + Live Peer Cursors Overlay */}
          <div className="relative overflow-hidden rounded-xl border border-[#D8D2C8] bg-white dark:border-[#2D3548]">
            <canvas
              ref={baseCanvasRef}
              width={CANVAS_W}
              height={CANVAS_H}
              className="block aspect-[880/500] w-full bg-white"
            />
            <canvas
              ref={overlayCanvasRef}
              width={CANVAS_W}
              height={CANVAS_H}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={finishStroke}
              onPointerCancel={finishStroke}
              className="absolute inset-0 h-full w-full cursor-crosshair touch-none"
            />

            {showGrid && (
              <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3">
                {Array.from({ length: 9 }).map((_, idx) => (
                  <div key={idx} className="border border-blue-500/15" />
                ))}
              </div>
            )}
            {(mirrorMode === 'horizontal' || mirrorMode === 'quad') && (
              <div className="pointer-events-none absolute top-0 bottom-0 left-1/2 w-px border-l border-dashed border-[#DC2626]/65" />
            )}
            {(mirrorMode === 'vertical' || mirrorMode === 'quad') && (
              <div className="pointer-events-none absolute right-0 left-0 top-1/2 h-px border-t border-dashed border-[#DC2626]/65" />
            )}

            {/* Live Peer Cursors */}
            {Object.values(cursors).map((cur) => (
              <div
                key={cur.userId}
                style={{
                  left: `${(cur.x / CANVAS_W) * 100}%`,
                  top: `${(cur.y / CANVAS_H) * 100}%`,
                }}
                className="pointer-events-none absolute z-10 -translate-x-1 -translate-y-1 transition-all duration-75"
              >
                <div
                  style={{ backgroundColor: cur.color }}
                  className="h-3 w-3 rounded-full border-2 border-white shadow"
                />
                <div
                  style={{ backgroundColor: cur.color }}
                  className="mt-0.5 rounded px-1.5 py-0.5 text-[10px] font-bold whitespace-nowrap text-white shadow"
                >
                  {cur.userName}
                </div>
              </div>
            ))}
          </div>

          {/* Export, AI Critique & Submit Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={downloadArtwork}
                className="inline-flex items-center gap-2 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] transition-colors hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <Download className="h-4 w-4" />
                <span>Unduh Karya Bersama (PNG)</span>
              </button>
              <button
                type="button"
                onClick={handleRequestAiCritique}
                disabled={critiqueLoading}
                className="inline-flex items-center gap-2 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-4 py-2 text-xs font-semibold text-[#1D4ED8] transition-colors hover:bg-[#DBEAFE] disabled:opacity-50 dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
              >
                <Bot className="h-4 w-4" />
                <span>{critiqueLoading ? 'Menganalisis...' : 'Minta Kritik Kurator AI'}</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleSubmitArtwork}
                disabled={submittingArt}
                className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1E40AF] disabled:opacity-50"
              >
                <UploadCloud className="h-4 w-4" />
                <span>{submittingArt ? 'Mengirim...' : 'Kirim ke Galeri & Google Drive'}</span>
              </button>
              {onRequestSendEmail && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    const collabNames = Array.from(
                      new Set([profile.name, ...participants.map((p) => p.userName)])
                    ).join(', ');
                    onRequestSendEmail({
                      subject: `[BHOLANG RUPA] Karya Kanvas Bersama (${roomId}) - ${profile.className}`,
                      summaryText: `Karya kolaborasi "${artTitle}" di ruang ${roomId} oleh ${collabNames} siap dipantau & dinilai.`,
                      htmlBody: `
                        <div style="font-family:sans-serif;max-width:600px;color:#171923;">
                          <h2 style="color:#1D4ED8;margin-bottom:8px;">Laporan Karya Kolaborasi Kanvas Bersama</h2>
                          <p><strong>Ruang Kolaborasi:</strong> ${roomId}</p>
                          <p><strong>Kolaborator Siswa:</strong> ${collabNames} (${profile.className})</p>
                          <p><strong>Judul Karya:</strong> ${artTitle || 'Karya Kolaborasi Kanvas Bersama'}</p>
                          <p><strong>Deskripsi:</strong> ${artDesc || '-'}</p>
                          ${critique ? `<p><strong>Ringkasan Kurator AI:</strong> ${critique.ringkasan || ''}</p>` : ''}
                          ${submitStatus?.driveLink ? `<p><strong>Tautan Google Drive Karya:</strong> <a href="${submitStatus.driveLink}">${submitStatus.driveLink}</a></p>` : ''}
                          <p><strong>Folder Pemantauan Drive:</strong> <a href="${DRIVE_FOLDER_URL}">${DRIVE_FOLDER_URL}</a></p>
                        </div>
                      `,
                    });
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#059669]/40 bg-emerald-50 px-3.5 py-2 text-xs font-semibold text-[#065F46] hover:bg-emerald-100 dark:bg-emerald-950/30 dark:text-emerald-300"
                >
                  <span>Kirim Info ke E-mail</span>
                </button>
              )}
            </div>
          </div>

          {submitStatus && (
            <div
              className={`rounded-xl border p-3.5 text-xs ${
                submitStatus.ok
                  ? 'border-[#059669]/30 bg-emerald-50 text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-200'
                  : 'border-[#DC2626]/30 bg-red-50 text-[#991B1B] dark:bg-red-950/30 dark:text-red-200'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-medium">{submitStatus.message}</span>
                {submitStatus.driveLink && (
                  <a
                    href={submitStatus.driveLink}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-semibold underline"
                  >
                    <span>Lihat di Google Drive</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar: Collaboration Guide, Metadata, Drive, AI Critique */}
        <div className="space-y-5 lg:col-span-4">
          {/* Tips Kolaborasi */}
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
            <h3 className="text-base font-bold text-[#171923] dark:text-white">
              Panduan Kanvas Bersama
            </h3>
            <ul className="mt-2.5 list-disc space-y-1.5 pl-4 text-xs leading-relaxed text-[#4A505E] dark:text-[#A3B1C6]">
              <li>
                Setiap siswa yang berada pada ruang yang sama dapat menggambar secara bersamaan dan melihat kursor teman secara real-time.
              </li>
              <li>
                Tombol <strong>Undo Goresanku</strong> hanya membatalkan goresan terakhirmu tanpa mengganggu gambar teman kelompokmu.
              </li>
              <li>
                Gunakan kuas bintik, krayon, mode blending, dan simetri mirror untuk memadukan unsur seni rupa bersama.
              </li>
            </ul>
          </div>

          {/* Metadata & Google Drive */}
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
            <h3 className="text-base font-bold text-[#171923] dark:text-white">
              Identitas Karya Bersama
            </h3>
            <div className="mt-3 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                  Judul Karya Kolaborasi
                </label>
                <input
                  type="text"
                  value={artTitle}
                  onChange={(e) => setArtTitle(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                  Catatan Unsur &amp; Pembagian Peran
                </label>
                <textarea
                  rows={2}
                  value={artDesc}
                  onChange={(e) => setArtDesc(e.target.value)}
                  placeholder="Contoh: Siswa A membuat sketsa garis irama, Siswa B mengisi tekstur bintik..."
                  className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>
            </div>

            <div className="mt-4 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-[#171923] dark:text-white">
                  Folder Google Drive Kelas
                </span>
                <a
                  href={DRIVE_FOLDER_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                >
                  <span>Buka Folder</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
              {!getCachedAccessToken() ? (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onRequireGoogleLogin();
                  }}
                  className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#1D4ED8] px-3 py-1.5 text-xs font-semibold text-[#1D4ED8] hover:bg-[#EFF6FF] dark:border-[#60A5FA] dark:text-[#60A5FA]"
                >
                  <span>Hubungkan Akun Google untuk Upload Drive</span>
                </button>
              ) : (
                <p className="mt-1.5 flex items-center gap-1.5 text-[#059669] dark:text-[#34D399]">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Siap mengunggah langsung ke folder Google Drive pemantauan.</span>
                </p>
              )}
            </div>
          </div>

          {/* AI Critique Card */}
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
            <div className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Ulasan Kurator AI
              </h3>
            </div>
            {critiqueError && (
              <p className="mt-2 text-xs text-[#DC2626] dark:text-red-300">{critiqueError}</p>
            )}
            {critique ? (
              <div className="mt-3 space-y-3 text-xs leading-relaxed">
                <p className="text-[#171923] dark:text-[#E2E8F0]">{critique.ringkasan}</p>
                {critique.unsurMenonjol && critique.unsurMenonjol.length > 0 && (
                  <div>
                    <div className="font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                      Unsur Terlihat:
                    </div>
                    <ul className="mt-1 list-disc pl-4 text-[#4A505E] dark:text-[#A3B1C6]">
                      {critique.unsurMenonjol.map((u) => (
                        <li key={u}>{u}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {critique.prinsipTerlihat && critique.prinsipTerlihat.length > 0 && (
                  <div>
                    <div className="font-semibold text-[#059669] dark:text-[#34D399]">
                      Prinsip Terlihat:
                    </div>
                    <ul className="mt-1 list-disc pl-4 text-[#4A505E] dark:text-[#A3B1C6]">
                      {critique.prinsipTerlihat.map((p) => (
                        <li key={p}>{p}</li>
                      ))}
                    </ul>
                  </div>
                )}
                {critique.saranPengembangan && (
                  <div className="rounded-lg bg-[#FAF9F7] p-2.5 text-[#4A505E] dark:bg-[#0D1017] dark:text-[#CBD5E1]">
                    <strong>Saran:</strong> {critique.saranPengembangan}
                  </div>
                )}
              </div>
            ) : (
              <p className="mt-2 text-xs leading-relaxed text-[#646B7A] dark:text-[#94A3B8]">
                Berkolaborasilah di Kanvas Bersama, lalu klik &ldquo;Minta Kritik Kurator AI&rdquo; untuk mendapatkan evaluasi otomatis unsur &amp; prinsip seni rupa karya kelompok kalian.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
