import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Bot,
  CheckCircle2,
  Circle,
  Download,
  Droplets,
  Eraser,
  ExternalLink,
  Eye,
  EyeOff,
  FlipHorizontal2,
  Gamepad2,
  Grid,
  Layers,
  Maximize2,
  Minus,
  Paintbrush,
  PenTool,
  Pencil,
  Plus,
  Radio,
  Redo2,
  RotateCcw,
  Sparkles,
  Square,
  Trash2,
  Undo2,
  UploadCloud,
  Users,
} from 'lucide-react';
import { ARTVENTURE_URL, DRIVE_FOLDER_URL } from '../data/learningContent';
import type { ArtworkSubmission, DemoState, UserProfile } from '../types';
import {
  dataUrlToBlob,
  getCachedAccessToken,
  uploadBlobToDriveFolder,
} from '../utils/firebaseGoogle';
import { playClickSound } from '../utils/sound';
import { CollabCanvasStudio } from './CollabCanvasStudio';
import type { FocusViewerResource } from './ExternalReturnExperience';

interface DemoPraktikSectionProps {
  profile: UserProfile;
  demoState: DemoState;
  onUpdateDemoState: (patch: Partial<DemoState>) => void;
  artworks: ArtworkSubmission[];
  onArtworkSubmitted: (item: ArtworkSubmission) => void;
  onRequireGoogleLogin: () => void;
  onRequestSendEmail?: (payload: {
    subject: string;
    summaryText: string;
    htmlBody: string;
  }) => void;
  wsConnected?: boolean;
  sendWs?: (event: string, payload: unknown) => void;
  subscribeWs?: (listener: (event: string, payload: unknown) => void) => () => void;
  onOpenFocusViewer?: (resource: FocusViewerResource) => void;
}

type ToolType =
  | 'brush'
  | 'pencil'
  | 'calligraphy'
  | 'blend'
  | 'stipple'
  | 'canvas-tex'
  | 'crosshatch'
  | 'crayon'
  | 'line'
  | 'rect'
  | 'circle'
  | 'eraser';

type MirrorMode = 'none' | 'horizontal' | 'vertical' | 'quad';

type BlendOp = 'source-over' | 'multiply' | 'screen' | 'overlay' | 'darken' | 'lighten';

interface CanvasLayer {
  id: string;
  name: string;
  visible: boolean;
  opacity: number;
  blendMode: BlendOp;
  canvas: HTMLCanvasElement;
}

interface CritiqueResult {
  ringkasan?: string;
  unsurMenonjol?: string[];
  prinsipTerlihat?: string[];
  saranPengembangan?: string;
}

const CANVAS_W = 880;
const CANVAS_H = 500;

const PALETTE_SWATCHES = [
  '#171923',
  '#1D4ED8',
  '#DC2626',
  '#EAB308',
  '#059669',
  '#7C3AED',
  '#EA580C',
  '#EC4899',
  '#0EA5E9',
  '#FFFFFF',
];

const DEMO_COLOR_PRESETS = [
  '#DC2626',
  '#EA580C',
  '#EAB308',
  '#16A34A',
  '#0EA5E9',
  '#1D4ED8',
  '#7C3AED',
  '#DB2777',
];

const PRIMARY_COLORS = [
  { id: 'merah', label: 'Merah', hex: '#DC2626' },
  { id: 'kuning', label: 'Kuning', hex: '#EAB308' },
  { id: 'biru', label: 'Biru', hex: '#1D4ED8' },
] as const;

const SECONDARY_COLORS = [
  {
    id: 'oranye',
    label: 'Oranye',
    hex: '#EA580C',
    mix: ['merah', 'kuning'] as string[],
    formula: 'Merah + Kuning',
  },
  {
    id: 'hijau',
    label: 'Hijau',
    hex: '#16A34A',
    mix: ['kuning', 'biru'] as string[],
    formula: 'Kuning + Biru',
  },
  {
    id: 'ungu',
    label: 'Ungu',
    hex: '#7C3AED',
    mix: ['biru', 'merah'] as string[],
    formula: 'Biru + Merah',
  },
] as const;

function hslToHex(h: number, s: number, l: number): string {
  const sNorm = s / 100;
  const lNorm = l / 100;
  const a = sNorm * Math.min(lNorm, 1 - lNorm);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = lNorm - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color)
      .toString(16)
      .padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`.toUpperCase();
}

function getSecondaryFromPrimaries(primaries: string[]) {
  if (primaries.length < 2) return null;
  const set = new Set(primaries.slice(0, 2));
  return (
    SECONDARY_COLORS.find(
      (sec) => sec.mix.every((m) => set.has(m))
    ) ?? null
  );
}

function hexToHsl(hex: string): { h: number; s: number; l: number } {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16) / 255;
  const g = parseInt(clean.slice(2, 4), 16) / 255;
  const b = parseInt(clean.slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = (g - b) / d + (g < b ? 6 : 0);
        break;
      case g:
        h = (b - r) / d + 2;
        break;
      case b:
        h = (r - g) / d + 4;
        break;
    }
    h /= 6;
  }
  return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
}

function createOffscreenLayerCanvas(fillWhite = false): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = CANVAS_W;
  c.height = CANVAS_H;
  if (fillWhite) {
    const ctx = c.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    }
  }
  return c;
}

export const DemoPraktikSection: React.FC<DemoPraktikSectionProps> = ({
  profile,
  demoState,
  onUpdateDemoState,
  artworks,
  onArtworkSubmitted,
  onRequireGoogleLogin,
  onRequestSendEmail,
  wsConnected = false,
  sendWs = () => {},
  subscribeWs = () => () => {},
  onOpenFocusViewer,
}) => {
  const [subMode, setSubMode] = useState<'demo' | 'praktik' | 'collab' | 'petualang'>('demo');

  // --- Multi-Layer Canvas State ---
  const displayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [layers, setLayers] = useState<CanvasLayer[]>([]);
  const [activeLayerId, setActiveLayerId] = useState<string>('');

  const [tool, setTool] = useState<ToolType>('brush');
  const [color, setColor] = useState('#1D4ED8');
  const [brushSize, setBrushSize] = useState(10);
  const [brushOpacity, setBrushOpacity] = useState(100);
  const [strokeBlend, setStrokeBlend] = useState<BlendOp>('source-over');
  const [mirrorMode, setMirrorMode] = useState<MirrorMode>('none');
  const [showGrid, setShowGrid] = useState(true);
  const [artTitle, setArtTitle] = useState('Komposisi Garis, Tekstur & Warna Harmonis');
  const [artDesc, setArtDesc] = useState('');

  // History per active layer snapshot
  const [history, setHistory] = useState<{ layerId: string; dataUrl: string }[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);

  const isDrawingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const startPointRef = useRef<{ x: number; y: number } | null>(null);
  const shapeSnapshotRef = useRef<ImageData | null>(null);

  const [critiqueLoading, setCritiqueLoading] = useState(false);
  const [critique, setCritique] = useState<CritiqueResult | null>(null);
  const [critiqueError, setCritiqueError] = useState('');

  const [submittingArt, setSubmittingArt] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<{
    ok: boolean;
    message: string;
    driveLink?: string;
  } | null>(null);

  // Initialize base layers once
  useEffect(() => {
    if (layers.length > 0) return;
    const baseCanvas = createOffscreenLayerCanvas(true);
    const sketchCanvas = createOffscreenLayerCanvas(false);
    const initLayers: CanvasLayer[] = [
      {
        id: 'layer-bg',
        name: 'Kanvas Dasar',
        visible: true,
        opacity: 100,
        blendMode: 'source-over',
        canvas: baseCanvas,
      },
      {
        id: 'layer-1',
        name: 'Lapisan Lukis 1',
        visible: true,
        opacity: 100,
        blendMode: 'source-over',
        canvas: sketchCanvas,
      },
    ];
    setLayers(initLayers);
    setActiveLayerId('layer-1');
    setHistory([{ layerId: 'layer-1', dataUrl: sketchCanvas.toDataURL('image/png') }]);
    setHistoryIdx(0);
  }, [layers.length]);

  const renderComposite = useCallback(
    (targetCanvas?: HTMLCanvasElement | null) => {
      const display = targetCanvas ?? displayCanvasRef.current;
      if (!display) return;
      const ctx = display.getContext('2d');
      if (!ctx) return;

      ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      for (const layer of layers) {
        if (!layer.visible) continue;
        ctx.save();
        ctx.globalAlpha = layer.opacity / 100;
        ctx.globalCompositeOperation = layer.blendMode;
        ctx.drawImage(layer.canvas, 0, 0);
        ctx.restore();
      }
    },
    [layers]
  );

  useEffect(() => {
    if (subMode === 'praktik') {
      renderComposite();
    }
  }, [subMode, layers, renderComposite]);

  const getActiveLayer = () => layers.find((l) => l.id === activeLayerId) ?? layers[layers.length - 1];

  const pushLayerHistory = (layer: CanvasLayer) => {
    const dataUrl = layer.canvas.toDataURL('image/png');
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIdx + 1);
      const next = [...sliced, { layerId: layer.id, dataUrl }].slice(-30);
      setHistoryIdx(next.length - 1);
      return next;
    });
  };

  const restoreHistoryAt = (idx: number) => {
    const entry = history[idx];
    if (!entry) return;
    const layer = layers.find((l) => l.id === entry.layerId);
    const ctx = layer?.canvas.getContext('2d');
    if (!layer || !ctx) return;
    const img = new Image();
    img.onload = () => {
      ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
      ctx.drawImage(img, 0, 0);
      renderComposite();
    };
    img.src = entry.dataUrl;
    setHistoryIdx(idx);
  };

  const addNewLayer = () => {
    playClickSound();
    const newId = `layer-${Date.now()}`;
    const newCanvas = createOffscreenLayerCanvas(false);
    const newLayer: CanvasLayer = {
      id: newId,
      name: `Lapisan ${layers.length}`,
      visible: true,
      opacity: 100,
      blendMode: 'source-over',
      canvas: newCanvas,
    };
    setLayers((prev) => [...prev, newLayer]);
    setActiveLayerId(newId);
  };

  const updateLayerProp = (id: string, patch: Partial<CanvasLayer>) => {
    setLayers((prev) => prev.map((l) => (l.id === id ? { ...l, ...patch } : l)));
  };

  const moveLayer = (id: string, dir: -1 | 1) => {
    playClickSound();
    setLayers((prev) => {
      const idx = prev.findIndex((l) => l.id === id);
      const target = idx + dir;
      if (idx === -1 || target < 0 || target >= prev.length) return prev;
      const copy = [...prev];
      const [item] = copy.splice(idx, 1);
      copy.splice(target, 0, item);
      return copy;
    });
  };

  const deleteLayer = (id: string) => {
    playClickSound();
    if (layers.length <= 1) return;
    setLayers((prev) => {
      const filtered = prev.filter((l) => l.id !== id);
      if (activeLayerId === id && filtered.length > 0) {
        setActiveLayerId(filtered[filtered.length - 1].id);
      }
      return filtered;
    });
  };

  const getMirroredPoints = (x: number, y: number): { x: number; y: number }[] => {
    const pts = [{ x, y }];
    if (mirrorMode === 'horizontal' || mirrorMode === 'quad') {
      pts.push({ x: CANVAS_W - x, y });
    }
    if (mirrorMode === 'vertical' || mirrorMode === 'quad') {
      pts.push({ x, y: CANVAS_H - y });
    }
    if (mirrorMode === 'quad') {
      pts.push({ x: CANVAS_W - x, y: CANVAS_H - y });
    }
    return pts;
  };

  const getCanvasCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = displayCanvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * CANVAS_W,
      y: ((e.clientY - rect.top) / rect.height) * CANVAS_H,
    };
  };

  const drawBrushStamp = (
    ctx: CanvasRenderingContext2D,
    from: { x: number; y: number },
    to: { x: number; y: number }
  ) => {
    const dist = Math.hypot(to.x - from.x, to.y - from.y);
    const steps = Math.max(1, Math.ceil(dist / 2));

    ctx.save();
    ctx.globalCompositeOperation = tool === 'eraser' ? 'destination-out' : strokeBlend;
    ctx.globalAlpha = tool === 'eraser' ? 1 : brushOpacity / 100;
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'brush' || tool === 'eraser') {
      ctx.lineWidth = brushSize;
      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
    } else if (tool === 'pencil') {
      ctx.lineWidth = Math.max(1.2, brushSize * 0.35);
      ctx.globalAlpha = Math.min(0.85, (brushOpacity / 100) * 0.85);
      ctx.beginPath();
      ctx.moveTo(from.x, from.y);
      ctx.lineTo(to.x, to.y);
      ctx.stroke();
    } else if (tool === 'calligraphy') {
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const x = from.x + (to.x - from.x) * t;
        const y = from.y + (to.y - from.y) * t;
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(-Math.PI / 5);
        ctx.fillRect(-brushSize * 0.65, -brushSize * 0.16, brushSize * 1.3, brushSize * 0.32);
        ctx.restore();
      }
    } else if (tool === 'stipple') {
      // Kuas Bintik (Pointillism / Spray)
      const dotCount = Math.max(6, Math.round(brushSize * 1.2));
      const radius = brushSize * 1.4;
      for (let i = 0; i < dotCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const r = Math.sqrt(Math.random()) * radius;
        const dx = to.x + Math.cos(angle) * r;
        const dy = to.y + Math.sin(angle) * r;
        const dotR = Math.max(0.7, Math.random() * (brushSize * 0.22));
        ctx.beginPath();
        ctx.arc(dx, dy, dotR, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (tool === 'canvas-tex') {
      // Tekstur Kanvas / Cat Minyak (Multi-bristle impasto)
      const bristles = 7;
      for (let b = 0; b < bristles; b++) {
        const offset = ((b - (bristles - 1) / 2) / bristles) * brushSize;
        ctx.lineWidth = Math.max(1, brushSize * 0.18);
        ctx.globalAlpha = ((brushOpacity / 100) * (0.45 + (b % 3) * 0.2));
        ctx.beginPath();
        ctx.moveTo(from.x + offset, from.y + offset * 0.6);
        ctx.lineTo(to.x + offset, to.y + offset * 0.6);
        ctx.stroke();
      }
    } else if (tool === 'crosshatch') {
      // Tekstur Arsir Silang
      ctx.lineWidth = 1;
      for (let i = 0; i <= steps; i += 3) {
        const t = i / steps;
        const x = from.x + (to.x - from.x) * t;
        const y = from.y + (to.y - from.y) * t;
        const s = brushSize * 0.7;
        ctx.beginPath();
        ctx.moveTo(x - s, y - s);
        ctx.lineTo(x + s, y + s);
        ctx.moveTo(x + s, y - s);
        ctx.lineTo(x - s, y + s);
        ctx.stroke();
      }
    } else if (tool === 'crayon') {
      // Tekstur Krayon / Pastel
      for (let i = 0; i <= steps; i++) {
        const t = i / steps;
        const cx = from.x + (to.x - from.x) * t;
        const cy = from.y + (to.y - from.y) * t;
        for (let g = 0; g < 14; g++) {
          const gx = cx + (Math.random() - 0.5) * brushSize;
          const gy = cy + (Math.random() - 0.5) * brushSize;
          ctx.fillRect(gx, gy, 1.6, 1.6);
        }
      }
    } else if (tool === 'blend') {
      // Kuas Blending: sample pixels from slightly behind and paint soft translucent blend
      const sampleR = Math.max(4, Math.round(brushSize));
      const sx = Math.max(0, Math.min(CANVAS_W - sampleR * 2, Math.round(from.x - sampleR)));
      const sy = Math.max(0, Math.min(CANVAS_H - sampleR * 2, Math.round(from.y - sampleR)));
      try {
        const sample = ctx.getImageData(sx, sy, sampleR * 2, sampleR * 2);
        let rSum = 0;
        let gSum = 0;
        let bSum = 0;
        let aCount = 0;
        for (let p = 0; p < sample.data.length; p += 16) {
          if (sample.data[p + 3] > 20) {
            rSum += sample.data[p];
            gSum += sample.data[p + 1];
            bSum += sample.data[p + 2];
            aCount += 1;
          }
        }
        if (aCount > 0) {
          const avgR = Math.round(rSum / aCount);
          const avgG = Math.round(gSum / aCount);
          const avgB = Math.round(bSum / aCount);
          const grad = ctx.createRadialGradient(to.x, to.y, 0, to.x, to.y, brushSize * 1.1);
          grad.addColorStop(0, `rgba(${avgR}, ${avgG}, ${avgB}, 0.38)`);
          grad.addColorStop(1, `rgba(${avgR}, ${avgG}, ${avgB}, 0)`);
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(to.x, to.y, brushSize * 1.1, 0, Math.PI * 2);
          ctx.fill();
        }
      } catch {
        // Ignore edge bounds
      }
    }

    ctx.restore();
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const activeLayer = getActiveLayer();
    const display = displayCanvasRef.current;
    const layerCtx = activeLayer?.canvas.getContext('2d');
    if (!activeLayer || !layerCtx || !display) return;

    display.setPointerCapture(e.pointerId);
    const pt = getCanvasCoords(e);
    isDrawingRef.current = true;
    lastPointRef.current = pt;
    startPointRef.current = pt;

    if (tool === 'line' || tool === 'rect' || tool === 'circle') {
      shapeSnapshotRef.current = layerCtx.getImageData(0, 0, CANVAS_W, CANVAS_H);
    } else {
      const mFrom = getMirroredPoints(pt.x, pt.y);
      mFrom.forEach((m) => drawBrushStamp(layerCtx, m, { x: m.x + 0.1, y: m.y + 0.1 }));
      renderComposite();
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    const activeLayer = getActiveLayer();
    const layerCtx = activeLayer?.canvas.getContext('2d');
    const last = lastPointRef.current;
    const start = startPointRef.current;
    if (!activeLayer || !layerCtx || !last || !start) return;

    const pt = getCanvasCoords(e);

    if (tool === 'line' || tool === 'rect' || tool === 'circle') {
      if (shapeSnapshotRef.current) {
        layerCtx.putImageData(shapeSnapshotRef.current, 0, 0);
      }
      const mStarts = getMirroredPoints(start.x, start.y);
      const mEnds = getMirroredPoints(pt.x, pt.y);
      layerCtx.save();
      layerCtx.globalCompositeOperation = strokeBlend;
      layerCtx.globalAlpha = brushOpacity / 100;
      layerCtx.strokeStyle = color;
      layerCtx.lineWidth = brushSize;
      layerCtx.lineCap = 'round';
      layerCtx.lineJoin = 'round';

      mStarts.forEach((ms, idx) => {
        const me = mEnds[idx];
        layerCtx.beginPath();
        if (tool === 'line') {
          layerCtx.moveTo(ms.x, ms.y);
          layerCtx.lineTo(me.x, me.y);
        } else if (tool === 'rect') {
          layerCtx.rect(ms.x, ms.y, me.x - ms.x, me.y - ms.y);
        } else if (tool === 'circle') {
          const r = Math.hypot(me.x - ms.x, me.y - ms.y);
          layerCtx.arc(ms.x, ms.y, r, 0, Math.PI * 2);
        }
        layerCtx.stroke();
      });
      layerCtx.restore();
    } else {
      const mFrom = getMirroredPoints(last.x, last.y);
      const mTo = getMirroredPoints(pt.x, pt.y);
      mFrom.forEach((mf, idx) => drawBrushStamp(layerCtx, mf, mTo[idx]));
      lastPointRef.current = pt;
    }

    renderComposite();
  };

  const handlePointerUp = () => {
    if (!isDrawingRef.current) return;
    isDrawingRef.current = false;
    shapeSnapshotRef.current = null;
    lastPointRef.current = null;
    const activeLayer = getActiveLayer();
    if (activeLayer) {
      pushLayerHistory(activeLayer);
    }
  };

  const clearActiveLayer = () => {
    playClickSound();
    const activeLayer = getActiveLayer();
    const ctx = activeLayer?.canvas.getContext('2d');
    if (!activeLayer || !ctx) return;
    if (activeLayer.id === 'layer-bg') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    } else {
      ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
    }
    renderComposite();
    pushLayerHistory(activeLayer);
  };

  const getFlattenedDataUrl = (): string => {
    const flat = createOffscreenLayerCanvas(true);
    renderComposite(flat);
    return flat.toDataURL('image/png');
  };

  const downloadArtwork = () => {
    playClickSound();
    const dataUrl = getFlattenedDataUrl();
    const link = document.createElement('a');
    const safeTitle = (artTitle || 'karya-bholang-rupa')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-');
    link.download = `${safeTitle}.png`;
    link.href = dataUrl;
    link.click();
  };

  const handleRequestAiCritique = async () => {
    playClickSound();
    setCritiqueLoading(true);
    setCritiqueError('');
    try {
      const imageDataUrl = getFlattenedDataUrl();
      const res = await fetch('/api/ai/critique-artwork', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageDataUrl, title: artTitle }),
      });
      const data = (await res.json()) as { critique?: CritiqueResult; error?: string };
      if (!res.ok) throw new Error(data.error || 'Gagal menganalisis karya.');
      setCritique(data.critique ?? null);
    } catch (err) {
      setCritiqueError(err instanceof Error ? err.message : 'Gagal terhubung ke AI.');
    } finally {
      setCritiqueLoading(false);
    }
  };

  const handleSubmitArtwork = async () => {
    playClickSound();
    setSubmittingArt(true);
    setSubmitStatus(null);
    try {
      const imageDataUrl = getFlattenedDataUrl();
      let driveFileId: string | undefined;
      let driveWebViewLink: string | undefined;

      const token = getCachedAccessToken();
      if (token) {
        const blob = await dataUrlToBlob(imageDataUrl);
        const fileName = `${profile.name.replace(/\s+/g, '_')}_${artTitle.replace(/\s+/g, '_')}_${Date.now()}.png`;
        const driveRes = await uploadBlobToDriveFolder(blob, fileName, 'image/png');
        driveFileId = driveRes.id;
        driveWebViewLink = driveRes.webViewLink;
      }

      const critiqueSummary = critique?.ringkasan
        ? `${critique.ringkasan} Saran: ${critique.saranPengembangan || ''}`
        : undefined;

      const res = await fetch('/api/submissions/artwork', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: profile.name,
          className: profile.className,
          title: artTitle || 'Karya Praktik Seni Rupa',
          description: artDesc,
          imageDataUrl,
          aiCritique: critiqueSummary,
          driveFileId,
          driveWebViewLink,
        }),
      });
      const data = (await res.json()) as { item?: ArtworkSubmission; error?: string };
      if (!res.ok || !data.item) throw new Error(data.error || 'Gagal mengirim karya.');

      onArtworkSubmitted(data.item);
      setSubmitStatus({
        ok: true,
        message: driveWebViewLink
          ? 'Karya multi-layer berhasil dikirim ke Google Drive folder pemantauan dan tercatat secara real-time!'
          : 'Karya berhasil dikirim ke Galeri Kelas secara real-time. Hubungkan Google untuk menyimpan salinan otomatis ke Google Drive & mengirim ke E-mail.',
        driveLink: driveWebViewLink,
      });
    } catch (err) {
      setSubmitStatus({
        ok: false,
        message: err instanceof Error ? err.message : 'Gagal mengirim karya.',
      });
    } finally {
      setSubmittingArt(false);
    }
  };

  const activeHexColor = demoState.customColor || hslToHex(demoState.primaryHue, 76, 48);
  const studentHexColor = demoState.studentColor || '#1D4ED8';
  const teacherHexColor = demoState.teacherColor || '#DC2626';
  const selectedPrimaries = demoState.selectedPrimaries ?? ['merah', 'kuning'];
  const mixedSecondary = getSecondaryFromPrimaries(selectedPrimaries);

  const applyInteractiveColor = (hex: string, targetSlot: 'slot1' | 'slot2' = 'slot1') => {
    const { h } = hexToHsl(hex);
    onUpdateDemoState({
      customColor: hex,
      primaryHue: h,
      ...(targetSlot === 'slot2' ? { teacherColor: hex } : { studentColor: hex }),
      updatedBy: `${profile.name} (${profile.className})`,
    });
  };

  const handleTogglePrimaryMix = (primaryId: string, hex: string) => {
    playClickSound();
    let next: string[];
    if (selectedPrimaries.includes(primaryId)) {
      next = selectedPrimaries.filter((id) => id !== primaryId);
      if (next.length === 0) next = [primaryId];
    } else if (selectedPrimaries.length >= 2) {
      next = [selectedPrimaries[1], primaryId];
    } else {
      next = [...selectedPrimaries, primaryId];
    }
    const sec = getSecondaryFromPrimaries(next);
    const resultHex = sec ? sec.hex : hex;
    const { h } = hexToHsl(resultHex);
    onUpdateDemoState({
      selectedPrimaries: next,
      customColor: resultHex,
      primaryHue: h,
      studentColor: resultHex,
      updatedBy: `${profile.name} (${profile.className})`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Segmented Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#171923] dark:text-white">
            Laboratorium Tata Cara Siswa &amp; Studio Praktik Pro
          </h2>
          <p className="mt-0.5 text-sm text-[#4A505E] dark:text-[#A3B1C6]">
            Panduan tata cara simulasi untuk siswa, spektrum warna bebas &amp; primer-sekunder interaktif dua panel warna, serta studio lukis multi-layer.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-[#E5E0D8] bg-[#F2EFE9] p-1 dark:border-[#272E3F] dark:bg-[#151923]">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSubMode('demo');
            }}
            className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subMode === 'demo'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            Demo Tata Cara Siswa
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSubMode('praktik');
            }}
            className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subMode === 'praktik'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            Praktik Studio Menggambar
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSubMode('collab');
            }}
            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subMode === 'collab'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            <Users className="h-3.5 w-3.5" />
            <span>Kanvas Bersama</span>
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSubMode('petualang');
            }}
            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subMode === 'petualang'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            <Gamepad2 className="h-3.5 w-3.5" />
            <span>Mari Berpetualang</span>
          </button>
        </div>
      </div>

      {/* MODE A: Laboratorium Demo Tata Cara Siswa & Spektrum Warna Interaktif */}
      {subMode === 'demo' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-7 dark:border-[#272E3F] dark:bg-[#151923]">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
              <div className="flex items-center gap-2">
                <Radio className="h-4 w-4 text-[#059669]" />
                <span className="text-sm font-bold text-[#171923] dark:text-white">
                  Panggung Simulasi Laboratorium Interaktif
                </span>
              </div>
              <span className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
                Diperbarui oleh: {demoState.updatedBy}
              </span>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {(
                [
                  { id: 'titik-garis', label: 'Titik & Garis', mode: 'unsur' },
                  { id: 'warna', label: 'Spektrum Warna Bebas', mode: 'unsur' },
                  { id: 'gelap-terang', label: 'Gelap-Terang', mode: 'unsur' },
                  { id: 'keseimbangan', label: 'Keseimbangan', mode: 'prinsip' },
                  { id: 'irama', label: 'Irama Visual', mode: 'prinsip' },
                  { id: 'penekanan', label: 'Penekanan Fokus', mode: 'prinsip' },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onUpdateDemoState({
                      mode: item.mode,
                      activeConcept: item.id,
                      updatedBy: `${profile.name} (${profile.className})`,
                    });
                  }}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    demoState.activeConcept === item.id
                      ? 'border-[#1D4ED8] bg-[#EFF6FF] text-[#1D4ED8] dark:border-[#60A5FA] dark:bg-[#1E293B] dark:text-[#60A5FA]'
                      : 'border-[#E5E0D8] bg-[#FAF9F7] text-[#4A505E] hover:bg-[#EFECE6] dark:border-[#272E3F] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="mt-5 flex min-h-[21rem] items-center justify-center rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
              <LiveDemoStage state={demoState} />
            </div>

            <div className="mt-4 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
              <div className="text-xs font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                Tata Cara &amp; Catatan Pengamatan Siswa
              </div>
              <ol className="mt-1.5 list-decimal space-y-1 pl-4 text-xs text-[#4A505E] dark:text-[#CBD5E1]">
                <li>Pilih unsur atau prinsip seni rupa yang ingin dipelajari siswa di atas.</li>
                <li>Ubah parameter simulasi atau uji coba spektrum warna bebas serta pencampuran warna primer–sekunder.</li>
                <li>Amati perubahan komposisi secara langsung, lalu praktikkan hasilnya pada Studio Menggambar.</li>
              </ol>
              <p className="mt-2.5 border-t border-[#E5E0D8] pt-2 text-xs font-medium text-[#171923] dark:border-[#232A3B] dark:text-[#E2E8F0]">
                Catatan Siswa: {demoState.teacherNote}
              </p>
            </div>
          </div>

          {/* Right Control Deck */}
          <div className="space-y-5 rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-5 dark:border-[#272E3F] dark:bg-[#151923]">
            <div>
              <h3 className="text-lg font-bold text-[#171923] dark:text-white">
                Kontrol Laboratorium &amp; Tata Cara Siswa
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-[#4A505E] dark:text-[#A3B1C6]">
                Bagian tata cara ini disiapkan khusus untuk siswa bereksperimen mandiri. Pada tab Spektrum Warna Bebas, tersedia dua kotak pemilih warna yang keduanya dapat diklik dan dipilih warnanya sendiri secara interaktif.
              </p>
            </div>

            <div className="space-y-4">
              {demoState.activeConcept === 'titik-garis' && (
                <div>
                  <div className="flex justify-between text-xs font-semibold text-[#171923] dark:text-white">
                    <span>Kepadatan Garis &amp; Titik</span>
                    <span className="font-mono-num">{demoState.density}%</span>
                  </div>
                  <input
                    type="range"
                    min={15}
                    max={100}
                    value={demoState.density}
                    onChange={(e) =>
                      onUpdateDemoState({
                        density: Number(e.target.value),
                        updatedBy: profile.name,
                      })
                    }
                    className="mt-2 w-full accent-[#1D4ED8]"
                  />
                </div>
              )}

              {demoState.activeConcept === 'warna' && (
                <div className="space-y-4">
                  {/* Clickable Free Color Spectrum (Dual Pickers) */}
                  <div className="space-y-3 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-bold text-[#171923] dark:text-white">
                        Spektrum Warna Bebas (Dua Warna Interaktif)
                      </span>
                      <span className="font-mono-num text-xs font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                        {activeHexColor.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                      Klik titik mana saja pada batang spektrum di bawah atau pilih warna bebas sendiri pada kedua kotak warna interaktif:
                    </p>

                    {/* Clickable Rainbow Spectrum Strip */}
                    <button
                      type="button"
                      aria-label="Klik spektrum warna bebas"
                      onClick={(e) => {
                        playClickSound();
                        const rect = e.currentTarget.getBoundingClientRect();
                        const ratio = Math.max(
                          0,
                          Math.min(1, (e.clientX - rect.left) / rect.width)
                        );
                        const hue = Math.round(ratio * 360);
                        const hex = hslToHex(hue, 82, 48);
                        applyInteractiveColor(hex, 'slot1');
                      }}
                      style={{
                        background:
                          'linear-gradient(to right, #DC2626, #EAB308, #16A34A, #0EA5E9, #1D4ED8, #7C3AED, #DB2777, #DC2626)',
                      }}
                      className="relative h-8 w-full cursor-crosshair rounded-lg border border-[#D8D2C8] shadow-inner dark:border-[#2D3548]"
                    >
                      <span
                        style={{
                          left: `${Math.min(97, Math.max(3, (demoState.primaryHue / 360) * 100))}%`,
                        }}
                        className="pointer-events-none absolute top-0.5 bottom-0.5 w-1.5 -translate-x-1/2 rounded-sm border border-[#171923] bg-white shadow"
                      />
                    </button>

                    {/* Dual Clickable Color Pickers */}
                    <div className="grid grid-cols-2 gap-2.5">
                      <label className="flex cursor-pointer items-center justify-between gap-2 rounded-lg border border-[#D8D2C8] bg-white p-2.5 text-xs transition-colors hover:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#151923]">
                        <div>
                          <div className="font-bold text-[#171923] dark:text-white">
                            Warna Pilihan 1
                          </div>
                          <div className="font-mono-num text-[10px] text-[#646B7A] dark:text-[#94A3B8]">
                            {studentHexColor.toUpperCase()}
                          </div>
                        </div>
                        <input
                          type="color"
                          value={studentHexColor}
                          onChange={(e) => applyInteractiveColor(e.target.value, 'slot1')}
                          aria-label="Pilih warna bebas pilihan 1"
                          className="h-8 w-10 cursor-pointer rounded border border-[#D8D2C8] bg-transparent p-0"
                        />
                      </label>

                      <label className="flex cursor-pointer items-center justify-between gap-2 rounded-lg border border-[#D8D2C8] bg-white p-2.5 text-xs transition-colors hover:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#151923]">
                        <div>
                          <div className="font-bold text-[#171923] dark:text-white">
                            Warna Pilihan 2
                          </div>
                          <div className="font-mono-num text-[10px] text-[#646B7A] dark:text-[#94A3B8]">
                            {teacherHexColor.toUpperCase()}
                          </div>
                        </div>
                        <input
                          type="color"
                          value={teacherHexColor}
                          onChange={(e) => applyInteractiveColor(e.target.value, 'slot2')}
                          aria-label="Pilih warna bebas pilihan 2"
                          className="h-8 w-10 cursor-pointer rounded border border-[#D8D2C8] bg-transparent p-0"
                        />
                      </label>
                    </div>

                    {/* Quick Swatches */}
                    <div className="flex flex-wrap gap-1.5">
                      {DEMO_COLOR_PRESETS.map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => {
                            playClickSound();
                            applyInteractiveColor(preset, 'slot1');
                          }}
                          style={{ backgroundColor: preset }}
                          aria-label={`Pilih warna ${preset}`}
                          className={`h-7 w-7 rounded-lg border transition-transform ${
                            activeHexColor.toLowerCase() === preset.toLowerCase()
                              ? 'scale-110 ring-2 ring-[#1D4ED8] ring-offset-1'
                              : 'border-white/50'
                          }`}
                        />
                      ))}
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                        <span>Geser Spektrum Hue</span>
                        <span className="font-mono-num">{demoState.primaryHue}°</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={360}
                        value={demoState.primaryHue}
                        onChange={(e) => {
                          const h = Number(e.target.value);
                          const hex = hslToHex(h, 76, 48);
                          onUpdateDemoState({
                            primaryHue: h,
                            customColor: hex,
                            studentColor: hex,
                            updatedBy: profile.name,
                          });
                        }}
                        className="mt-1.5 w-full accent-[#1D4ED8]"
                      />
                    </div>
                  </div>

                  {/* Interactive Primary & Secondary Color Selector + Mixer */}
                  <div className="space-y-3 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#171923] dark:text-white">
                        Pemilihan Warna Primer &amp; Sekunder Interaktif
                      </span>
                      <span className="text-[10px] font-semibold text-[#059669] dark:text-[#34D399]">
                        Klik 2 Primer untuk Mencampur
                      </span>
                    </div>

                    <div>
                      <span className="block text-[11px] font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                        1. Warna Primer (Dasar):
                      </span>
                      <div className="mt-1.5 grid grid-cols-3 gap-2">
                        {PRIMARY_COLORS.map((prim) => {
                          const isSelected = selectedPrimaries.includes(prim.id);
                          return (
                            <button
                              key={prim.id}
                              type="button"
                              onClick={() => handleTogglePrimaryMix(prim.id, prim.hex)}
                              className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 text-xs font-semibold transition-all ${
                                isSelected
                                  ? 'border-[#1D4ED8] bg-white shadow-sm ring-1 ring-[#1D4ED8] dark:border-[#60A5FA] dark:bg-[#151923]'
                                  : 'border-[#D8D2C8] bg-white/70 hover:bg-white dark:border-[#2D3548] dark:bg-[#151923]/60'
                              }`}
                            >
                              <span
                                style={{ backgroundColor: prim.hex }}
                                className="h-4 w-4 shrink-0 rounded border border-black/15"
                              />
                              <span className="text-[#171923] dark:text-white">{prim.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div>
                      <span className="block text-[11px] font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                        2. Warna Sekunder (Hasil Campuran):
                      </span>
                      <div className="mt-1.5 grid grid-cols-3 gap-2">
                        {SECONDARY_COLORS.map((sec) => {
                          const isResult = mixedSecondary?.id === sec.id;
                          return (
                            <button
                              key={sec.id}
                              type="button"
                              onClick={() => {
                                playClickSound();
                                const { h } = hexToHsl(sec.hex);
                                onUpdateDemoState({
                                  selectedPrimaries: [...sec.mix],
                                  customColor: sec.hex,
                                  primaryHue: h,
                                  studentColor: sec.hex,
                                  updatedBy: `${profile.name} (${profile.className})`,
                                });
                              }}
                              className={`flex flex-col items-start rounded-lg border p-2 text-left text-xs transition-all ${
                                isResult
                                  ? 'border-[#059669] bg-emerald-50/70 ring-1 ring-[#059669] dark:bg-emerald-950/30'
                                  : 'border-[#D8D2C8] bg-white/70 hover:bg-white dark:border-[#2D3548] dark:bg-[#151923]/60'
                              }`}
                            >
                              <div className="flex items-center gap-1.5">
                                <span
                                  style={{ backgroundColor: sec.hex }}
                                  className="h-3.5 w-3.5 shrink-0 rounded border border-black/15"
                                />
                                <span className="font-bold text-[#171923] dark:text-white">
                                  {sec.label}
                                </span>
                              </div>
                              <span className="mt-0.5 text-[10px] text-[#646B7A] dark:text-[#94A3B8]">
                                {sec.formula}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {demoState.activeConcept === 'gelap-terang' && (
                <div>
                  <div className="flex justify-between text-xs font-semibold text-[#171923] dark:text-white">
                    <span>Arah Datang Cahaya</span>
                    <span className="font-mono-num">{demoState.lightAngle}°</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={180}
                    value={demoState.lightAngle}
                    onChange={(e) =>
                      onUpdateDemoState({
                        lightAngle: Number(e.target.value),
                        updatedBy: profile.name,
                      })
                    }
                    className="mt-2 w-full accent-[#1D4ED8]"
                  />
                </div>
              )}

              {demoState.activeConcept === 'keseimbangan' && (
                <div>
                  <span className="block text-xs font-semibold text-[#171923] dark:text-white">
                    Jenis Keseimbangan Komposisi
                  </span>
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    {(['simetris', 'asimetris', 'radial'] as const).map((bMode) => (
                      <button
                        key={bMode}
                        type="button"
                        onClick={() => {
                          playClickSound();
                          onUpdateDemoState({
                            balanceMode: bMode,
                            updatedBy: profile.name,
                          });
                        }}
                        className={`rounded-lg border px-2 py-2 text-xs font-semibold capitalize ${
                          demoState.balanceMode === bMode
                            ? 'border-[#1D4ED8] bg-[#1D4ED8] text-white'
                            : 'border-[#D8D2C8] bg-[#FAF9F7] text-[#4A505E] dark:border-[#272E3F] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                        }`}
                      >
                        {bMode}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {demoState.activeConcept === 'irama' && (
                <div>
                  <div className="flex justify-between text-xs font-semibold text-[#171923] dark:text-white">
                    <span>Frekuensi Pengulangan Irama</span>
                    <span className="font-mono-num">{demoState.rhythmCount}×</span>
                  </div>
                  <input
                    type="range"
                    min={3}
                    max={12}
                    value={demoState.rhythmCount}
                    onChange={(e) =>
                      onUpdateDemoState({
                        rhythmCount: Number(e.target.value),
                        updatedBy: profile.name,
                      })
                    }
                    className="mt-2 w-full accent-[#1D4ED8]"
                  />
                </div>
              )}

              {demoState.activeConcept === 'penekanan' && (
                <div>
                  <div className="flex justify-between text-xs font-semibold text-[#171923] dark:text-white">
                    <span>Intensitas Kontras Pusat Perhatian</span>
                    <span className="font-mono-num">{demoState.emphasisStrength}%</span>
                  </div>
                  <input
                    type="range"
                    min={20}
                    max={100}
                    value={demoState.emphasisStrength}
                    onChange={(e) =>
                      onUpdateDemoState({
                        emphasisStrength: Number(e.target.value),
                        updatedBy: profile.name,
                      })
                    }
                    className="mt-2 w-full accent-[#1D4ED8]"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-[#171923] dark:text-white">
                  Catatan Pengamatan Siswa
                </label>
                <input
                  type="text"
                  value={demoState.teacherNote}
                  onChange={(e) => onUpdateDemoState({ teacherNote: e.target.value })}
                  placeholder="Tulis catatan pengamatan tata cara siswa di sini..."
                  className="mt-1.5 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODE B: Practical Drawing Studio Pro (Multi-Layer, Blending, Mirror, Brushes & Textures) */}
      {subMode === 'praktik' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#E5E0D8] bg-white px-4 py-3 text-xs dark:border-[#272E3F] dark:bg-[#151923]">
            <div>
              <span className="font-bold text-[#171923] dark:text-white">
                Mode Kanvas Individu (Multi-Layer Pro)
              </span>
              <span className="mx-2 text-[#94A3B8]">·</span>
              <span className="text-[#4A505E] dark:text-[#A3B1C6]">
                Ingin melukis bersama teman kelompok secara real-time?
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setSubMode('collab');
              }}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-[#1E40AF]"
            >
              <Users className="h-3.5 w-3.5" />
              <span>Buka Kanvas Bersama (Live)</span>
            </button>
          </div>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Canvas & Brushes */}
          <div className="space-y-4 rounded-2xl border border-[#E5E0D8] bg-white p-5 lg:col-span-8 dark:border-[#272E3F] dark:bg-[#151923]">
            {/* Brush & Shape Palette */}
            <div className="space-y-2.5 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-[#171923] dark:text-white">
                  Pilihan Kuas, Bintik, Tekstur &amp; Bentuk
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    disabled={historyIdx <= 0}
                    onClick={() => {
                      playClickSound();
                      restoreHistoryAt(historyIdx - 1);
                    }}
                    aria-label="Urungkan"
                    className="rounded-lg border border-[#D8D2C8] p-1.5 text-[#171923] disabled:opacity-40 dark:border-[#2D3548] dark:text-white"
                  >
                    <Undo2 className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    disabled={historyIdx >= history.length - 1}
                    onClick={() => {
                      playClickSound();
                      restoreHistoryAt(historyIdx + 1);
                    }}
                    aria-label="Ulangi"
                    className="rounded-lg border border-[#D8D2C8] p-1.5 text-[#171923] disabled:opacity-40 dark:border-[#2D3548] dark:text-white"
                  >
                    <Redo2 className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setShowGrid((v) => !v);
                    }}
                    className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1.5 text-xs font-medium ${
                      showGrid
                        ? 'border-[#1D4ED8] bg-[#EFF6FF] text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]'
                        : 'border-[#D8D2C8] text-[#4A505E] dark:border-[#2D3548] dark:text-[#A3B1C6]'
                    }`}
                  >
                    <Grid className="h-3.5 w-3.5" />
                    <span>Kisi</span>
                  </button>
                  <button
                    type="button"
                    onClick={clearActiveLayer}
                    className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-2.5 py-1.5 text-xs font-medium text-[#DC2626] hover:bg-red-50 dark:border-[#2D3548] dark:hover:bg-red-950/30"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Bersihkan Layer</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    { id: 'brush', label: 'Kuas Halus', Icon: Paintbrush },
                    { id: 'pencil', label: 'Pensil Sketsa', Icon: Pencil },
                    { id: 'calligraphy', label: 'Kaligrafi', Icon: PenTool },
                    { id: 'blend', label: 'Blending Campur', Icon: Droplets },
                    { id: 'stipple', label: 'Kuas Bintik', Icon: Sparkles },
                    { id: 'canvas-tex', label: 'Tekstur Kanvas', Icon: Paintbrush },
                    { id: 'crosshatch', label: 'Tekstur Arsir', Icon: Grid },
                    { id: 'crayon', label: 'Tekstur Krayon', Icon: Pencil },
                    { id: 'line', label: 'Garis', Icon: Minus },
                    { id: 'rect', label: 'Bidang', Icon: Square },
                    { id: 'circle', label: 'Lingkaran', Icon: Circle },
                    { id: 'eraser', label: 'Penghapus', Icon: Eraser },
                  ] as const
                ).map(({ id, label, Icon }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setTool(id);
                    }}
                    className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                      tool === id
                        ? 'bg-[#1D4ED8] text-white'
                        : 'bg-[#FAF9F7] text-[#4A505E] hover:bg-[#EFECE6] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                    }`}
                  >
                    <Icon className="h-3.5 w-3.5" />
                    <span>{label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Color, Size, Opacity, Stroke Blend, Mirror */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-1.5">
                {PALETTE_SWATCHES.map((swatch) => (
                  <button
                    key={swatch}
                    type="button"
                    aria-label={`Pilih warna ${swatch}`}
                    onClick={() => {
                      playClickSound();
                      setColor(swatch);
                      if (tool === 'eraser') setTool('brush');
                    }}
                    style={{ backgroundColor: swatch }}
                    className={`h-6 w-6 rounded-full border transition-transform ${
                      color === swatch && tool !== 'eraser'
                        ? 'scale-110 ring-2 ring-[#1D4ED8] ring-offset-1'
                        : 'border-[#CBD5E1]'
                    }`}
                  />
                ))}
                <input
                  type="color"
                  value={color}
                  onChange={(e) => {
                    setColor(e.target.value);
                    if (tool === 'eraser') setTool('brush');
                  }}
                  aria-label="Pilih warna bebas"
                  className="h-6 w-8 cursor-pointer rounded border border-[#D8D2C8] bg-transparent p-0"
                />
              </div>

              <div className="flex flex-wrap items-center gap-3">
                <label className="flex items-center gap-1.5 font-medium text-[#4A505E] dark:text-[#A3B1C6]">
                  <span>Ukuran:</span>
                  <input
                    type="range"
                    min={1}
                    max={48}
                    value={brushSize}
                    onChange={(e) => setBrushSize(Number(e.target.value))}
                    className="w-16 accent-[#1D4ED8]"
                  />
                  <span className="font-mono-num w-8">{brushSize}px</span>
                </label>

                <label className="flex items-center gap-1.5 font-medium text-[#4A505E] dark:text-[#A3B1C6]">
                  <span>Opasitas:</span>
                  <input
                    type="range"
                    min={10}
                    max={100}
                    value={brushOpacity}
                    onChange={(e) => setBrushOpacity(Number(e.target.value))}
                    className="w-16 accent-[#1D4ED8]"
                  />
                  <span className="font-mono-num w-8">{brushOpacity}%</span>
                </label>

                <label className="flex items-center gap-1.5 font-medium text-[#4A505E] dark:text-[#A3B1C6]">
                  <span>Blend Kuas:</span>
                  <select
                    value={strokeBlend}
                    onChange={(e) => setStrokeBlend(e.target.value as BlendOp)}
                    className="rounded border border-[#D8D2C8] bg-[#FAF9F7] px-2 py-1 text-xs font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  >
                    <option value="source-over">Normal</option>
                    <option value="multiply">Multiply</option>
                    <option value="screen">Screen</option>
                    <option value="overlay">Overlay</option>
                    <option value="darken">Darken</option>
                    <option value="lighten">Lighten</option>
                  </select>
                </label>
              </div>
            </div>

            {/* Mirror Controls Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] px-3.5 py-2 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
              <div className="flex items-center gap-2 font-semibold text-[#171923] dark:text-white">
                <FlipHorizontal2 className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <span>Mode Mirror (Simetri):</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    { id: 'none', label: 'Mati' },
                    { id: 'horizontal', label: 'Horizontal (Kiri-Kanan)' },
                    { id: 'vertical', label: 'Vertikal (Atas-Bawah)' },
                    { id: 'quad', label: '4-Arah (Mandala)' },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setMirrorMode(m.id);
                    }}
                    className={`rounded-md px-2.5 py-1 text-xs font-semibold transition-colors ${
                      mirrorMode === m.id
                        ? 'bg-[#1D4ED8] text-white'
                        : 'bg-white text-[#4A505E] hover:bg-[#EFECE6] dark:bg-[#151923] dark:text-[#A3B1C6]'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Canvas Viewport */}
            <div className="relative overflow-hidden rounded-xl border border-[#D8D2C8] bg-white dark:border-[#2D3548]">
              <canvas
                ref={displayCanvasRef}
                width={CANVAS_W}
                height={CANVAS_H}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
                className="block aspect-[880/500] w-full cursor-crosshair touch-none bg-white"
              />
              {showGrid && (
                <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3">
                  {Array.from({ length: 9 }).map((_, idx) => (
                    <div key={idx} className="border border-blue-500/15" />
                  ))}
                </div>
              )}
              {(mirrorMode === 'horizontal' || mirrorMode === 'quad') && (
                <div className="pointer-events-none absolute top-0 bottom-0 left-1/2 w-px border-l border-dashed border-[#DC2626]/65" />
              )}
              {(mirrorMode === 'vertical' || mirrorMode === 'quad') && (
                <div className="pointer-events-none absolute right-0 left-0 top-1/2 h-px border-t border-dashed border-[#DC2626]/65" />
              )}
            </div>

            {/* Download & Submit Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={downloadArtwork}
                  className="inline-flex items-center gap-2 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] transition-colors hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  <Download className="h-4 w-4" />
                  <span>Unduh Gambar (PNG)</span>
                </button>
                <button
                  type="button"
                  onClick={handleRequestAiCritique}
                  disabled={critiqueLoading}
                  className="inline-flex items-center gap-2 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-4 py-2 text-xs font-semibold text-[#1D4ED8] transition-colors hover:bg-[#DBEAFE] disabled:opacity-50 dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
                >
                  <Bot className="h-4 w-4" />
                  <span>{critiqueLoading ? 'Menganalisis Karya...' : 'Minta Kritik Kurator AI'}</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSubmitArtwork}
                  disabled={submittingArt}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1E40AF] disabled:opacity-50"
                >
                  <UploadCloud className="h-4 w-4" />
                  <span>{submittingArt ? 'Mengirim...' : 'Kirim ke Galeri & Google Drive'}</span>
                </button>
                {onRequestSendEmail && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onRequestSendEmail({
                        subject: `[BHOLANG RUPA] Kiriman Karya Praktik - ${profile.name} (${profile.className})`,
                        summaryText: `Karya "${artTitle || 'Karya Praktik Seni Rupa'}" oleh ${profile.name} (${profile.className}) dikirim untuk pemantauan & penilaian.`,
                        htmlBody: `
                          <div style="font-family:sans-serif;max-width:600px;color:#171923;">
                            <h2 style="color:#1D4ED8;margin-bottom:8px;">Laporan Kiriman Karya Praktik Siswa</h2>
                            <p><strong>Nama Siswa:</strong> ${profile.name} (${profile.className})</p>
                            <p><strong>Judul Karya:</strong> ${artTitle || 'Karya Praktik Seni Rupa'}</p>
                            <p><strong>Deskripsi Teknik:</strong> ${artDesc || '-'}</p>
                            ${critique ? `<p><strong>Ringkasan Kurator AI:</strong> ${critique.ringkasan || ''}</p>` : ''}
                            ${submitStatus?.driveLink ? `<p><strong>Tautan Google Drive Karya:</strong> <a href="${submitStatus.driveLink}">${submitStatus.driveLink}</a></p>` : ''}
                            <p><strong>Folder Pemantauan Drive:</strong> <a href="${DRIVE_FOLDER_URL}">${DRIVE_FOLDER_URL}</a></p>
                          </div>
                        `,
                      });
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#059669]/40 bg-emerald-50 px-3.5 py-2 text-xs font-semibold text-[#065F46] hover:bg-emerald-100 dark:bg-emerald-950/30 dark:text-emerald-300"
                  >
                    <span>Kirim Info ke E-mail</span>
                  </button>
                )}
              </div>
            </div>

            {submitStatus && (
              <div
                className={`rounded-xl border p-3.5 text-xs ${
                  submitStatus.ok
                    ? 'border-[#059669]/30 bg-emerald-50 text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-200'
                    : 'border-[#DC2626]/30 bg-red-50 text-[#991B1B] dark:bg-red-950/30 dark:text-red-200'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-medium">{submitStatus.message}</span>
                  {submitStatus.driveLink && (
                    <a
                      href={submitStatus.driveLink}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-semibold underline"
                    >
                      <span>Lihat di Google Drive</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right Panel: Layers Manager, Metadata, AI Critique */}
          <div className="space-y-5 lg:col-span-4">
            {/* Multi-Layer & Blending Panel */}
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
              <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
                <div className="flex items-center gap-2">
                  <Layers className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                  <h3 className="text-base font-bold text-[#171923] dark:text-white">
                    Layer &amp; Blending ({layers.length})
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={addNewLayer}
                  className="inline-flex items-center gap-1 rounded-lg bg-[#1D4ED8] px-2.5 py-1 text-xs font-semibold text-white hover:bg-[#1E40AF]"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Tambah Layer</span>
                </button>
              </div>

              <div className="mt-3 space-y-2.5 max-h-64 overflow-y-auto pr-1">
                {[...layers].reverse().map((layer) => {
                  const isActive = layer.id === activeLayerId;
                  return (
                    <div
                      key={layer.id}
                      onClick={() => {
                        playClickSound();
                        setActiveLayerId(layer.id);
                      }}
                      className={`cursor-pointer rounded-xl border p-3 text-xs transition-colors ${
                        isActive
                          ? 'border-[#1D4ED8] bg-[#EFF6FF] dark:border-[#60A5FA] dark:bg-[#1E293B]'
                          : 'border-[#EEEAE2] bg-[#FAF9F7] dark:border-[#232A3B] dark:bg-[#0D1017]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              playClickSound();
                              updateLayerProp(layer.id, { visible: !layer.visible });
                            }}
                            aria-label="Tampilkan atau sembunyikan layer"
                            className="text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white"
                          >
                            {layer.visible ? (
                              <Eye className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                            ) : (
                              <EyeOff className="h-4 w-4 opacity-50" />
                            )}
                          </button>
                          <span className="font-bold text-[#171923] dark:text-white">
                            {layer.name}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              moveLayer(layer.id, 1);
                            }}
                            title="Naikkan layer"
                            className="rounded p-1 hover:bg-black/5 dark:hover:bg-white/10"
                          >
                            <ArrowUp className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              moveLayer(layer.id, -1);
                            }}
                            title="Turunkan layer"
                            className="rounded p-1 hover:bg-black/5 dark:hover:bg-white/10"
                          >
                            <ArrowDown className="h-3.5 w-3.5" />
                          </button>
                          {layers.length > 1 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteLayer(layer.id);
                              }}
                              title="Hapus layer"
                              className="rounded p-1 text-[#DC2626] hover:bg-red-50 dark:hover:bg-red-950/30"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div
                        className="mt-2 grid grid-cols-2 gap-2"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <select
                          value={layer.blendMode}
                          onChange={(e) =>
                            updateLayerProp(layer.id, { blendMode: e.target.value as BlendOp })
                          }
                          aria-label="Mode blending layer"
                          className="rounded border border-[#D8D2C8] bg-white px-2 py-1 text-[11px] font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#151923] dark:text-white"
                        >
                          <option value="source-over">Blend: Normal</option>
                          <option value="multiply">Blend: Multiply</option>
                          <option value="screen">Blend: Screen</option>
                          <option value="overlay">Blend: Overlay</option>
                          <option value="darken">Blend: Darken</option>
                          <option value="lighten">Blend: Lighten</option>
                        </select>

                        <div className="flex items-center gap-1.5">
                          <input
                            type="range"
                            min={10}
                            max={100}
                            value={layer.opacity}
                            onChange={(e) =>
                              updateLayerProp(layer.id, { opacity: Number(e.target.value) })
                            }
                            className="w-full accent-[#1D4ED8]"
                          />
                          <span className="font-mono-num text-[10px] w-7 text-right">
                            {layer.opacity}%
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Metadata & Drive Card */}
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Identitas &amp; Tujuan Kiriman
              </h3>
              <div className="mt-3 space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                    Judul Karya
                  </label>
                  <input
                    type="text"
                    value={artTitle}
                    onChange={(e) => setArtTitle(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                    Deskripsi Teknik &amp; Prinsip
                  </label>
                  <textarea
                    rows={2}
                    value={artDesc}
                    onChange={(e) => setArtDesc(e.target.value)}
                    placeholder="Contoh: Layer kedua memakai blend multiply dan kuas bintik..."
                    className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  />
                </div>
              </div>

              <div className="mt-4 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-[#171923] dark:text-white">
                    Folder Google Drive Kelas
                  </span>
                  <a
                    href={DRIVE_FOLDER_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                  >
                    <span>Buka Folder</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
                {!getCachedAccessToken() ? (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onRequireGoogleLogin();
                    }}
                    className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-[#1D4ED8] px-3 py-1.5 text-xs font-semibold text-[#1D4ED8] hover:bg-[#EFF6FF] dark:border-[#60A5FA] dark:text-[#60A5FA]"
                  >
                    <span>Hubungkan Akun Google untuk Upload Drive</span>
                  </button>
                ) : (
                  <p className="mt-1.5 flex items-center gap-1.5 text-[#059669] dark:text-[#34D399]">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Siap mengunggah langsung ke folder Google Drive pemantauan.</span>
                  </p>
                )}
              </div>
            </div>

            {/* AI Critique Card */}
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
              <div className="flex items-center gap-2">
                <Bot className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <h3 className="text-base font-bold text-[#171923] dark:text-white">
                  Ulasan Kurator AI
                </h3>
              </div>
              {critiqueError && (
                <p className="mt-2 text-xs text-[#DC2626] dark:text-red-300">{critiqueError}</p>
              )}
              {critique ? (
                <div className="mt-3 space-y-3 text-xs leading-relaxed">
                  <p className="text-[#171923] dark:text-[#E2E8F0]">{critique.ringkasan}</p>
                  {critique.unsurMenonjol && critique.unsurMenonjol.length > 0 && (
                    <div>
                      <div className="font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                        Unsur Terlihat:
                      </div>
                      <ul className="mt-1 list-disc pl-4 text-[#4A505E] dark:text-[#A3B1C6]">
                        {critique.unsurMenonjol.map((u) => (
                          <li key={u}>{u}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {critique.prinsipTerlihat && critique.prinsipTerlihat.length > 0 && (
                    <div>
                      <div className="font-semibold text-[#059669] dark:text-[#34D399]">
                        Prinsip Terlihat:
                      </div>
                      <ul className="mt-1 list-disc pl-4 text-[#4A505E] dark:text-[#A3B1C6]">
                        {critique.prinsipTerlihat.map((p) => (
                          <li key={p}>{p}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {critique.saranPengembangan && (
                    <div className="rounded-lg bg-[#FAF9F7] p-2.5 text-[#4A505E] dark:bg-[#0D1017] dark:text-[#CBD5E1]">
                      <strong>Saran:</strong> {critique.saranPengembangan}
                    </div>
                  )}
                </div>
              ) : (
                <p className="mt-2 text-xs leading-relaxed text-[#646B7A] dark:text-[#94A3B8]">
                  Eksplorasi kuas tekstur, blending, dan mirror di kanvas, lalu klik &ldquo;Minta Kritik Kurator AI&rdquo; untuk evaluasi otomatis.
                </p>
              )}
            </div>
          </div>
        </div>
        </div>
      )}

      {/* MODE C: Collaborative Canvas Studio (Real-Time WebSocket) */}
      {subMode === 'collab' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#E5E0D8] bg-white px-4 py-3 text-xs dark:border-[#272E3F] dark:bg-[#151923]">
            <div>
              <span className="font-bold text-[#171923] dark:text-white">
                Mode Kanvas Bersama (Kolaborasi WebSocket Real-Time)
              </span>
              <span className="mx-2 text-[#94A3B8]">·</span>
              <span className="text-[#4A505E] dark:text-[#A3B1C6]">
                Butuh kanvas pribadi dengan banyak layer &amp; blending mandiri?
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setSubMode('praktik');
              }}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-1.5 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
            >
              <Layers className="h-3.5 w-3.5" />
              <span>Kembali ke Kanvas Individu</span>
            </button>
          </div>
          <CollabCanvasStudio
            profile={profile}
            wsConnected={wsConnected}
            sendWs={sendWs}
            subscribeWs={subscribeWs}
            onArtworkSubmitted={onArtworkSubmitted}
            onRequireGoogleLogin={onRequireGoogleLogin}
            onRequestSendEmail={onRequestSendEmail}
          />
        </div>
      )}

      {/* MODE D: Mari Berpetualang — Gim Edukasi Kemendikdasmen Artventure */}
      {subMode === 'petualang' && (
        <div className="space-y-4 rounded-2xl border border-[#E5E0D8] bg-white p-6 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EEEAE2] pb-4 dark:border-[#272E3F]">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#EFF6FF] text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]">
                <Gamepad2 className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#171923] dark:text-white">
                  Mari Berpetualang — Gim Edukasi Artventure
                </h3>
                <p className="mt-0.5 text-xs text-[#4A505E] dark:text-[#A3B1C6]">
                  Sumber belajar interaktif Kemendikdasmen tentang Unsur Rupa &amp; Prinsip Desain. Mainkan petualangan visual dan gunakan tombol{' '}
                  <strong>Kembali ke Web</strong> kapan saja.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setSubMode('demo');
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-[#1E40AF]"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Kembali ke Web (Demo)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setSubMode('praktik');
                }}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <Paintbrush className="h-3.5 w-3.5" />
                <span>Ke Studio Menggambar</span>
              </button>
              {onOpenFocusViewer && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onOpenFocusViewer({
                      title: 'Mari Berpetualang — Gim Edukasi Artventure',
                      subtitle: 'Sumber Belajar Kemendikdasmen · Unsur Rupa & Prinsip Desain',
                      embedUrl: ARTVENTURE_URL,
                      externalUrl: ARTVENTURE_URL,
                    });
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-3.5 py-2 text-xs font-semibold text-[#1D4ED8] hover:bg-[#DBEAFE] dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
                >
                  <Maximize2 className="h-3.5 w-3.5" />
                  <span>Layar Penuh</span>
                </button>
              )}
              <a
                href={ARTVENTURE_URL}
                target="_blank"
                rel="noreferrer"
                data-resource-label="Mari Berpetualang (Artventure Kemendikdasmen)"
                onClick={() => playClickSound()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#059669] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#047857]"
              >
                <span>Buka di Tab Baru</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-[#E5E0D8] bg-[#FAF9F7] dark:border-[#272E3F] dark:bg-[#0D1017]">
            <iframe
              src={ARTVENTURE_URL}
              title="Mari Berpetualang — Artventure Unsur Rupa dan Prinsip Desain"
              allow="fullscreen; clipboard-write"
              allowFullScreen
              className="h-[620px] w-full border-0 bg-white"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] px-4 py-3 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
            <span className="text-[#4A505E] dark:text-[#A3B1C6]">
              Jika gim Artventure belum tampil di bingkai di atas karena kebijakan situs sumber, klik{' '}
              <strong>Buka di Tab Baru</strong>, lalu gunakan bilah <strong>Kembali ke Web</strong> setelah bermain.
            </span>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setSubMode('demo');
              }}
              className="inline-flex items-center gap-1.5 font-bold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Kembali ke Web BHOLANG RUPA</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const LiveDemoStage: React.FC<{ state: DemoState }> = ({ state }) => {
  if (state.activeConcept === 'titik-garis') {
    const count = Math.round(state.density / 6);
    return (
      <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
        {Array.from({ length: count }).map((_, i) => {
          const y = 24 + (i * 170) / Math.max(1, count - 1);
          return (
            <g key={i}>
              <path
                d={`M 25 ${y} Q 140 ${y - 25 + (i % 3) * 14}, 250 ${y} T 375 ${y}`}
                fill="none"
                stroke="#1D4ED8"
                strokeWidth={1.2 + (i % 4) * 0.7}
                opacity={0.4 + (i / count) * 0.55}
              />
              <circle cx={35 + i * 22} cy={y} r={2.8} fill="#DC2626" />
            </g>
          );
        })}
      </svg>
    );
  }

  if (state.activeConcept === 'warna') {
    const main = state.customColor || hslToHex(state.primaryHue, 76, 48);
    const studentCol = state.studentColor || '#1D4ED8';
    const teacherCol = state.teacherColor || '#DC2626';
    const hue = state.customColor ? hexToHsl(state.customColor).h : state.primaryHue;
    const comp = `hsl(${(hue + 180) % 360}, 76%, 48%)`;
    const analog1 = `hsl(${(hue + 35) % 360}, 74%, 52%)`;
    const analog2 = `hsl(${(hue + 325) % 360}, 74%, 52%)`;

    const selectedPrim = state.selectedPrimaries ?? ['merah', 'kuning'];
    const p1 = PRIMARY_COLORS.find((p) => p.id === selectedPrim[0]) ?? PRIMARY_COLORS[0];
    const p2 = PRIMARY_COLORS.find((p) => p.id === selectedPrim[1]);
    const secResult = p2 ? getSecondaryFromPrimaries([p1.id, p2.id]) : null;

    return (
      <svg viewBox="0 0 460 250" className="h-full w-full max-w-lg">
        {/* Top Left: Dual Pilihan Warna Interaktif */}
        <circle cx="88" cy="64" r="42" fill={studentCol} />
        <circle cx="152" cy="64" r="42" fill={teacherCol} opacity="0.92" />
        <text x="52" y="122" fontSize="10" fontWeight="700" className="fill-[#171923] dark:fill-white">
          Pilihan 1 ({studentCol.toUpperCase()})
        </text>
        <text x="132" y="122" fontSize="10" fontWeight="700" className="fill-[#171923] dark:fill-white">
          Pilihan 2 ({teacherCol.toUpperCase()})
        </text>

        {/* Top Right: Harmoni Warna Utama */}
        <rect x="260" y="20" width="84" height="24" rx="6" fill={analog1} />
        <rect x="260" y="50" width="84" height="24" rx="6" fill={main} />
        <rect x="260" y="80" width="84" height="24" rx="6" fill={analog2} />
        <rect x="354" y="20" width="84" height="84" rx="10" fill={comp} />
        <text x="260" y="122" fontSize="10" className="fill-[#4A505E] dark:fill-[#CBD5E1]">
          Harmoni Analogus
        </text>
        <text x="358" y="122" fontSize="10" className="fill-[#4A505E] dark:fill-[#CBD5E1]">
          Komplementer
        </text>

        {/* Divider */}
        <line x1="20" y1="138" x2="440" y2="138" stroke="#CBD5E1" strokeDasharray="4 4" />

        {/* Bottom: Lab Pencampuran Warna Primer -> Sekunder */}
        <text x="24" y="158" fontSize="10" fontWeight="700" className="fill-[#1D4ED8] dark:fill-[#60A5FA]">
          Simulasi Campuran Warna Primer &amp; Sekunder:
        </text>

        <circle cx="82" cy="198" r="24" fill={p1.hex} />
        <text x="64" y="238" fontSize="10" fontWeight="600" className="fill-[#171923] dark:fill-white">
          {p1.label}
        </text>

        <text x="132" y="204" fontSize="18" fontWeight="700" className="fill-[#4A505E] dark:fill-[#CBD5E1]">
          +
        </text>

        <circle cx="192" cy="198" r="24" fill={p2 ? p2.hex : '#E2E8F0'} />
        <text x="172" y="238" fontSize="10" fontWeight="600" className="fill-[#171923] dark:fill-white">
          {p2 ? p2.label : 'Pilih ke-2'}
        </text>

        <text x="245" y="204" fontSize="18" fontWeight="700" className="fill-[#4A505E] dark:fill-[#CBD5E1]">
          =
        </text>

        <circle cx="316" cy="198" r="30" fill={secResult ? secResult.hex : p1.hex} />
        <text x="282" y="240" fontSize="10" fontWeight="700" className="fill-[#171923] dark:fill-white">
          {secResult ? `Sekunder: ${secResult.label}` : `Primer: ${p1.label}`}
        </text>
      </svg>
    );
  }

  if (state.activeConcept === 'gelap-terang') {
    const rad = (state.lightAngle * Math.PI) / 180;
    const cxOffset = 50 - Math.cos(rad) * 28;
    const cyOffset = 50 - Math.sin(rad) * 28;
    const shadowX = 200 + Math.cos(rad) * 45;
    return (
      <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
        <defs>
          <radialGradient id="demoSphere" cx={`${cxOffset}%`} cy={`${cyOffset}%`} r="68%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="45%" stopColor="#94A3B8" />
            <stop offset="100%" stopColor="#0F172A" />
          </radialGradient>
        </defs>
        <ellipse cx={shadowX} cy="176" rx="68" ry="14" fill="#0F172A" opacity="0.28" />
        <circle cx="200" cy="108" r="66" fill="url(#demoSphere)" />
      </svg>
    );
  }

  if (state.activeConcept === 'keseimbangan') {
    if (state.balanceMode === 'simetris') {
      return (
        <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
          <line x1="200" y1="16" x2="200" y2="204" stroke="#94A3B8" strokeDasharray="4 4" />
          <rect x="75" y="50" width="90" height="120" rx="10" fill="#1D4ED8" />
          <rect x="235" y="50" width="90" height="120" rx="10" fill="#1D4ED8" />
          <circle cx="120" cy="110" r="24" fill="#FFFFFF" />
          <circle cx="280" cy="110" r="24" fill="#FFFFFF" />
        </svg>
      );
    }
    if (state.balanceMode === 'radial') {
      return (
        <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
          {Array.from({ length: 8 }).map((_, i) => {
            const angle = (i * 45 * Math.PI) / 180;
            const x = 200 + Math.cos(angle) * 64;
            const y = 110 + Math.sin(angle) * 64;
            return <circle key={i} cx={x} cy={y} r="18" fill="#1D4ED8" opacity="0.82" />;
          })}
          <circle cx="200" cy="110" r="26" fill="#DC2626" />
        </svg>
      );
    }
    return (
      <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
        <line x1="200" y1="16" x2="200" y2="204" stroke="#94A3B8" strokeDasharray="4 4" />
        <rect x="52" y="48" width="118" height="124" rx="12" fill="#334155" />
        <circle cx="268" cy="78" r="26" fill="#DC2626" />
        <circle cx="318" cy="138" r="18" fill="#EAB308" />
        <rect x="238" y="128" width="44" height="44" rx="8" fill="#1D4ED8" />
      </svg>
    );
  }

  if (state.activeConcept === 'irama') {
    const n = state.rhythmCount;
    return (
      <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
        {Array.from({ length: n }).map((_, i) => {
          const x = 24 + (i * 340) / n;
          const h = 48 + ((i * 22) % 110);
          return (
            <rect
              key={i}
              x={x}
              y={180 - h}
              width={Math.max(12, 260 / n)}
              height={h}
              rx="6"
              fill={i % 2 === 0 ? '#1D4ED8' : '#0EA5E9'}
              opacity={0.45 + (i / n) * 0.55}
            />
          );
        })}
      </svg>
    );
  }

  const emphasisOpacity = state.emphasisStrength / 100;
  return (
    <svg viewBox="0 0 400 220" className="h-full w-full max-w-md">
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <rect
          key={i}
          x={32 + i * 58}
          y={46 + (i % 2) * 32}
          width="42"
          height="90"
          rx="8"
          fill="#94A3B8"
          opacity={0.55 - emphasisOpacity * 0.25}
        />
      ))}
      <circle
        cx="228"
        cy="108"
        r={28 + emphasisOpacity * 16}
        fill="#DC2626"
        opacity={0.4 + emphasisOpacity * 0.6}
      />
    </svg>
  );
};
