import React, { useMemo, useState } from 'react';
import {
  Bot,
  CheckCircle2,
  Download,
  ExternalLink,
  Heart,
  Image as ImageIcon,
  Mail,
  MessageSquareHeart,
  Paintbrush,
  Pin,
  PinOff,
  Plus,
  Search,
  Send,
  Sparkles,
  UploadCloud,
  X,
} from 'lucide-react';
import { DRIVE_FOLDER_URL } from '../data/learningContent';
import type {
  ActiveTab,
  ArtworkAppreciation,
  ArtworkSubmission,
  UserProfile,
} from '../types';
import {
  dataUrlToBlob,
  getCachedAccessToken,
  uploadBlobToDriveFolder,
} from '../utils/firebaseGoogle';
import { playClickSound } from '../utils/sound';

interface GaleriKelasSectionProps {
  profile: UserProfile;
  artworks: ArtworkSubmission[];
  onArtworkSubmitted: (item: ArtworkSubmission) => void;
  onArtworkUpdated: (item: ArtworkSubmission) => void;
  onAppreciationAdded: (artworkId: string, appreciation: ArtworkAppreciation) => void;
  onNavigateTab: (tab: ActiveTab) => void;
  onRequireGoogleLogin: () => Promise<boolean>;
  onRequestSendEmail?: (payload: {
    subject: string;
    summaryText: string;
    htmlBody: string;
  }) => void;
}

const APPRECIATION_BADGES = [
  'Komposisi Indah',
  'Warna Harmonis',
  'Teknik Kreatif',
  'Keseimbangan Tepat',
  'Sangat Inspiratif',
] as const;

type GalleryFilter = 'all' | 'pinned' | 'popular';

export const GaleriKelasSection: React.FC<GaleriKelasSectionProps> = ({
  profile,
  artworks,
  onArtworkSubmitted,
  onArtworkUpdated,
  onAppreciationAdded,
  onNavigateTab,
  onRequireGoogleLogin,
  onRequestSendEmail,
}) => {
  const [filterMode, setFilterMode] = useState<GalleryFilter>('all');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArtworkId, setSelectedArtworkId] = useState<string | null>(null);

  // Add & Submit Student Artwork Modal State
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [newStudentName, setNewStudentName] = useState(profile.name);
  const [newClassName, setNewClassName] = useState(profile.className || 'X-A');
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newImageDataUrl, setNewImageDataUrl] = useState('');
  const [newFileName, setNewFileName] = useState('');
  const [processingImage, setProcessingImage] = useState(false);
  const [aiCritiqueText, setAiCritiqueText] = useState('');
  const [critiqueBusy, setCritiqueBusy] = useState(false);
  const [submittingArtwork, setSubmittingArtwork] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState<{
    item: ArtworkSubmission;
    message: string;
  } | null>(null);

  const [selectedBadge, setSelectedBadge] = useState<string>(APPRECIATION_BADGES[0]);
  const [appreciationMsg, setAppreciationMsg] = useState('');
  const [submittingAppreciation, setSubmittingAppreciation] = useState(false);
  const [actionError, setActionError] = useState('');
  const [busyLikeId, setBusyLikeId] = useState<string | null>(null);
  const [busyPinId, setBusyPinId] = useState<string | null>(null);

  React.useEffect(() => {
    setNewStudentName(profile.name);
    setNewClassName(profile.className || 'X-A');
  }, [profile.name, profile.className]);

  const handleOpenUploadModal = () => {
    playClickSound();
    setActionError('');
    setUploadSuccess(null);
    setNewStudentName(profile.name);
    setNewClassName(profile.className || 'X-A');
    setUploadModalOpen(true);
  };

  const handlePickArtworkFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setActionError('');
    setProcessingImage(true);
    setNewFileName(file.name);
    if (!newTitle.trim()) {
      setNewTitle(file.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' '));
    }

    try {
      const rawDataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Gagal membaca berkas gambar.'));
        reader.readAsDataURL(file);
      });

      // Resize cleanly if larger than 1400px so JSON & WebSocket sync stay fast
      if (file.type === 'image/svg+xml') {
        setNewImageDataUrl(rawDataUrl);
      } else {
        const resizedDataUrl = await new Promise<string>((resolve) => {
          const img = new Image();
          img.onload = () => {
            const maxDim = 1400;
            let { width, height } = img;
            if (width <= maxDim && height <= maxDim) {
              resolve(rawDataUrl);
              return;
            }
            const scale = Math.min(maxDim / width, maxDim / height);
            width = Math.round(width * scale);
            height = Math.round(height * scale);
            const canvas = document.createElement('canvas');
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            if (!ctx) {
              resolve(rawDataUrl);
              return;
            }
            ctx.fillStyle = '#FFFFFF';
            ctx.fillRect(0, 0, width, height);
            ctx.drawImage(img, 0, 0, width, height);
            resolve(canvas.toDataURL('image/jpeg', 0.88));
          };
          img.onerror = () => resolve(rawDataUrl);
          img.src = rawDataUrl;
        });
        setNewImageDataUrl(resizedDataUrl);
      }
      setAiCritiqueText('');
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Gagal memproses gambar.');
    } finally {
      setProcessingImage(false);
    }
  };

  const handleRequestAiCritiqueForUpload = async () => {
    if (!newImageDataUrl || critiqueBusy) return;
    playClickSound();
    setCritiqueBusy(true);
    setActionError('');
    try {
      const res = await fetch('/api/ai/critique-artwork', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageDataUrl: newImageDataUrl,
          title: newTitle.trim() || 'Karya Siswa',
          description: newDescription.trim(),
        }),
      });
      const data = (await res.json()) as {
        critique?: {
          ringkasan?: string;
          saranPengembangan?: string;
        };
        error?: string;
      };
      if (!res.ok) {
        throw new Error(data.error || 'Gagal meminta ulasan AI.');
      }
      const summary = [data.critique?.ringkasan, data.critique?.saranPengembangan]
        .filter(Boolean)
        .join(' — ');
      setAiCritiqueText(summary);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Kurator AI belum tersedia.');
    } finally {
      setCritiqueBusy(false);
    }
  };

  const handleSubmitNewArtwork = async (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound();
    setActionError('');
    if (!newStudentName.trim() || !newTitle.trim() || !newImageDataUrl) {
      setActionError('Nama siswa, judul karya, dan gambar karya wajib diisi.');
      return;
    }

    setSubmittingArtwork(true);
    try {
      let driveFileId: string | undefined;
      let driveWebViewLink: string | undefined;

      if (getCachedAccessToken()) {
        const blob = await dataUrlToBlob(newImageDataUrl);
        const safeName = `${newStudentName.trim().replace(/\s+/g, '_')}_${newTitle
          .trim()
          .replace(/\s+/g, '_')}.png`;
        const driveFile = await uploadBlobToDriveFolder(
          blob,
          safeName,
          blob.type || 'image/png'
        );
        driveFileId = driveFile.id;
        driveWebViewLink = driveFile.webViewLink;
      }

      const res = await fetch('/api/submissions/artwork', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: newStudentName.trim(),
          className: newClassName.trim() || 'X-A',
          title: newTitle.trim(),
          description: newDescription.trim(),
          imageDataUrl: newImageDataUrl,
          aiCritique: aiCritiqueText.trim() || undefined,
          driveFileId,
          driveWebViewLink,
        }),
      });
      const data = (await res.json()) as { item?: ArtworkSubmission; error?: string };
      if (!res.ok || !data.item) {
        throw new Error(data.error || 'Gagal mengirim karya ke Galeri Kelas.');
      }

      onArtworkSubmitted(data.item);
      setUploadSuccess({
        item: data.item,
        message: driveWebViewLink
          ? 'Karya berhasil ditambahkan ke Galeri Kelas secara real-time & tersimpan ke Google Drive!'
          : 'Karya berhasil dikirim & langsung tampil di Galeri Kelas secara real-time!',
      });
      setSelectedArtworkId(data.item.id);
      setNewTitle('');
      setNewDescription('');
      setNewImageDataUrl('');
      setNewFileName('');
      setAiCritiqueText('');
      setUploadModalOpen(false);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Gagal mengirim karya.');
    } finally {
      setSubmittingArtwork(false);
    }
  };

  const selectedArtwork = useMemo(
    () => artworks.find((a) => a.id === selectedArtworkId) ?? null,
    [artworks, selectedArtworkId]
  );

  const pinnedArtworks = useMemo(
    () => artworks.filter((a) => Boolean(a.pinned)),
    [artworks]
  );

  const totalLikes = useMemo(
    () => artworks.reduce((acc, a) => acc + (a.likedBy?.length ?? 0), 0),
    [artworks]
  );

  const totalAppreciations = useMemo(
    () => artworks.reduce((acc, a) => acc + (a.appreciations?.length ?? 0), 0),
    [artworks]
  );

  const filteredArtworks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = artworks.filter((art) => {
      if (filterMode === 'pinned' && !art.pinned) return false;
      if (classFilter !== 'ALL' && art.className !== classFilter) return false;
      if (
        q &&
        !art.title.toLowerCase().includes(q) &&
        !art.studentName.toLowerCase().includes(q) &&
        !art.description.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });

    if (filterMode === 'popular') {
      return [...list].sort(
        (a, b) => (b.likedBy?.length ?? 0) - (a.likedBy?.length ?? 0)
      );
    }

    // Default: pinned works stay featured at the top, followed by newest
    return [...list].sort((a, b) => {
      if (Boolean(a.pinned) !== Boolean(b.pinned)) {
        return a.pinned ? -1 : 1;
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [artworks, filterMode, classFilter, searchQuery]);

  const handleToggleLike = async (art: ArtworkSubmission) => {
    playClickSound();
    setActionError('');
    if (busyLikeId === art.id) return;

    const currentLikes = art.likedBy ?? [];
    const alreadyLiked = currentLikes.includes(profile.name);
    const optimisticLikes = alreadyLiked
      ? currentLikes.filter((n) => n !== profile.name)
      : [...currentLikes, profile.name];

    // Optimistic update
    onArtworkUpdated({ ...art, likedBy: optimisticLikes });
    setBusyLikeId(art.id);

    try {
      const res = await fetch(`/api/artworks/${art.id}/like`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userName: profile.name }),
      });
      const data = (await res.json()) as { item?: ArtworkSubmission; error?: string };
      if (!res.ok) {
        // Rollback on error
        onArtworkUpdated(art);
        setActionError(data.error || 'Gagal memperbarui apresiasi suka.');
        return;
      }
      if (data.item) {
        onArtworkUpdated(data.item);
      }
    } catch {
      onArtworkUpdated(art);
      setActionError('Koneksi gagal saat mengirim suka.');
    } finally {
      setBusyLikeId(null);
    }
  };

  const handleTogglePin = async (art: ArtworkSubmission) => {
    playClickSound();
    setActionError('');
    if (busyPinId === art.id) return;

    const nextPinned = !art.pinned;
    onArtworkUpdated({
      ...art,
      pinned: nextPinned,
      pinnedBy: nextPinned ? profile.name : undefined,
      pinnedAt: nextPinned ? new Date().toISOString() : undefined,
    });
    setBusyPinId(art.id);

    try {
      const res = await fetch(`/api/artworks/${art.id}/pin`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pinned: nextPinned,
          actorName: profile.name,
          actorRole: profile.role,
        }),
      });
      const data = (await res.json()) as { item?: ArtworkSubmission; error?: string };
      if (!res.ok) {
        onArtworkUpdated(art);
        setActionError(data.error || 'Gagal memperbarui status pin karya.');
        return;
      }
      if (data.item) {
        onArtworkUpdated(data.item);
      }
    } catch {
      onArtworkUpdated(art);
      setActionError('Koneksi gagal saat menyematkan karya.');
    } finally {
      setBusyPinId(null);
    }
  };

  const handleSubmitAppreciation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedArtwork || !appreciationMsg.trim()) return;
    playClickSound();
    setActionError('');
    setSubmittingAppreciation(true);

    try {
      const res = await fetch(`/api/artworks/${selectedArtwork.id}/appreciations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: profile.name,
          authorRole: 'siswa',
          badge: selectedBadge,
          message: appreciationMsg.trim(),
        }),
      });
      const data = (await res.json()) as {
        artworkId?: string;
        appreciation?: ArtworkAppreciation;
        error?: string;
      };
      if (!res.ok) {
        setActionError(data.error || 'Gagal mengirim apresiasi.');
        return;
      }
      if (data.appreciation) {
        onAppreciationAdded(selectedArtwork.id, data.appreciation);
      }
      setAppreciationMsg('');
    } catch {
      setActionError('Koneksi terputus saat mengirim apresiasi.');
    } finally {
      setSubmittingAppreciation(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Editorial Section Header */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-[#E5E0D8] pb-5 dark:border-[#272E3F]">
        <div>
          <h2 className="text-2xl font-bold text-[#171923] dark:text-white">
            Galeri Kelas &amp; Apresiasi Karya Real-Time
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-[#4A505E] dark:text-[#A3B1C6]">
            Karya terbaik dapat ditandai (pin) sebagai referensi inspirasi kelas, sementara seluruh siswa dapat memberikan &ldquo;Suka&rdquo; dan catatan apresiasi secara real-time.
          </p>
          <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs text-[#646B7A] dark:text-[#94A3B8]">
            <span>
              Total Karya: <strong className="font-mono-num text-[#171923] dark:text-white">{artworks.length}</strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Karya Terbaik (Pinned):{' '}
              <strong className="font-mono-num text-[#B45309] dark:text-[#FBBF24]">
                {pinnedArtworks.length}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Total Suka:{' '}
              <strong className="font-mono-num text-[#DC2626] dark:text-[#F87171]">
                {totalLikes}
              </strong>
            </span>
            <span aria-hidden="true">·</span>
            <span>
              Catatan Apresiasi:{' '}
              <strong className="font-mono-num text-[#1D4ED8] dark:text-[#60A5FA]">
                {totalAppreciations}
              </strong>
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleOpenUploadModal}
            className="inline-flex items-center gap-2 rounded-xl bg-[#059669] px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-[#047857]"
          >
            <Plus className="h-4 w-4" />
            <span>Tambah &amp; Kirim Karya Siswa</span>
          </button>

          <button
            type="button"
            onClick={() => {
              playClickSound();
              onNavigateTab('demo-praktik');
            }}
            className="inline-flex items-center gap-2 rounded-xl bg-[#1D4ED8] px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-[#1E40AF]"
          >
            <Paintbrush className="h-4 w-4" />
            <span>Gambar di Studio Praktik</span>
          </button>
        </div>
      </div>

      {uploadSuccess && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#059669]/35 bg-emerald-50 px-4 py-3 text-xs text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-200">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 shrink-0 text-[#059669] dark:text-[#34D399]" />
            <span className="font-medium">{uploadSuccess.message}</span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {uploadSuccess.item.driveWebViewLink && (
              <a
                href={uploadSuccess.item.driveWebViewLink}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 rounded-lg bg-white px-2.5 py-1 font-semibold text-[#065F46] shadow-sm hover:underline dark:bg-[#151923] dark:text-emerald-300"
              >
                <span>Buka Drive</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            )}
            {onRequestSendEmail && (
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  const item = uploadSuccess.item;
                  onRequestSendEmail({
                    subject: `[BHOLANG RUPA] Karya Baru Galeri Kelas - ${item.studentName} (${item.className})`,
                    summaryText: `Karya "${item.title}" oleh ${item.studentName} (${item.className}) telah ditambahkan ke Galeri Kelas.`,
                    htmlBody: `
                      <div style="font-family:sans-serif;max-width:600px;color:#171923;">
                        <h2 style="color:#1D4ED8;">Kiriman Karya Siswa Galeri Kelas</h2>
                        <p><strong>Nama Siswa:</strong> ${item.studentName} (${item.className})</p>
                        <p><strong>Judul Karya:</strong> ${item.title}</p>
                        <p><strong>Deskripsi:</strong> ${item.description || '-'}</p>
                        ${item.aiCritique ? `<p><strong>Ulasan Kurator AI:</strong> ${item.aiCritique}</p>` : ''}
                        ${item.driveWebViewLink ? `<p><strong>Link Drive Karya:</strong> <a href="${item.driveWebViewLink}">${item.driveWebViewLink}</a></p>` : ''}
                        <p><strong>Folder Drive Pemantauan:</strong> <a href="${DRIVE_FOLDER_URL}">${DRIVE_FOLDER_URL}</a></p>
                      </div>
                    `,
                  });
                }}
                className="inline-flex items-center gap-1 rounded-lg bg-[#059669] px-2.5 py-1 font-semibold text-white hover:bg-[#047857]"
              >
                <Mail className="h-3 w-3" />
                <span>Kirim Info ke E-mail</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setUploadSuccess(null)}
              aria-label="Tutup pesan sukses"
              className="p-1 hover:opacity-75"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {actionError && (
        <div className="flex items-center justify-between rounded-xl border border-[#DC2626]/30 bg-red-50 px-4 py-2.5 text-xs text-[#991B1B] dark:bg-red-950/30 dark:text-red-200">
          <span>{actionError}</span>
          <button type="button" onClick={() => setActionError('')}>
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Spotlight: Karya Terbaik Pilihan Kelas (Pinned) */}
      {pinnedArtworks.length > 0 && filterMode !== 'popular' && (
        <section className="space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Pin className="h-4 w-4 text-[#B45309] dark:text-[#FBBF24]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Karya Terbaik Pilihan Kelas ({pinnedArtworks.length})
              </h3>
            </div>
            <span className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
              Karya terbaik yang disematkan sebagai inspirasi kelas.
            </span>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {pinnedArtworks.map((art) => {
              const liked = (art.likedBy ?? []).includes(profile.name);
              const likeCount = art.likedBy?.length ?? 0;
              const apprCount = art.appreciations?.length ?? 0;
              return (
                <article
                  key={`pinned-${art.id}`}
                  className="overflow-hidden rounded-2xl border-2 border-[#D97706]/45 bg-white shadow-sm dark:border-[#FBBF24]/40 dark:bg-[#151923]"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-12">
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setSelectedArtworkId(art.id);
                      }}
                      className="group relative overflow-hidden bg-white sm:col-span-6"
                    >
                      <img
                        src={art.imageDataUrl}
                        alt={art.title}
                        className="h-52 w-full object-contain transition-transform duration-300 group-hover:scale-[1.02]"
                      />
                    </button>

                    <div className="flex flex-col justify-between p-5 sm:col-span-6">
                      <div>
                        <div className="flex items-center justify-between gap-2">
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-[#B45309] dark:text-[#FBBF24]">
                            <Pin className="h-3 w-3" />
                            <span>Karya Pilihan</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => handleTogglePin(art)}
                            disabled={busyPinId === art.id}
                            className="inline-flex items-center gap-1 rounded-md border border-[#D8D2C8] px-2 py-1 text-[11px] font-semibold text-[#4A505E] hover:bg-[#FAF9F7] dark:border-[#2D3548] dark:text-[#CBD5E1] dark:hover:bg-[#0D1017]"
                          >
                            <PinOff className="h-3 w-3" />
                            <span>Lepas Pin</span>
                          </button>
                        </div>

                        <h4 className="mt-2 text-base font-bold leading-snug text-[#171923] dark:text-white">
                          {art.title}
                        </h4>
                        <div className="mt-1 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                          <span>{art.studentName}</span>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span>{art.className}</span>
                        </div>
                        {art.description && (
                          <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                            {art.description}
                          </p>
                        )}
                      </div>

                      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-[#EEEAE2] pt-3 dark:border-[#272E3F]">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleToggleLike(art)}
                            disabled={busyLikeId === art.id}
                            className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                              liked
                                ? 'border-[#DC2626]/40 bg-red-50 text-[#DC2626] dark:bg-red-950/30 dark:text-[#F87171]'
                                : 'border-[#D8D2C8] bg-[#FAF9F7] text-[#4A505E] hover:text-[#DC2626] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-[#CBD5E1]'
                            }`}
                          >
                            <Heart className={`h-3.5 w-3.5 ${liked ? 'fill-current' : ''}`} />
                            <span className="font-mono-num">{likeCount}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              playClickSound();
                              setSelectedArtworkId(art.id);
                            }}
                            className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-2.5 py-1.5 text-xs font-semibold text-[#1D4ED8] hover:bg-[#EFF6FF] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-[#60A5FA]"
                          >
                            <MessageSquareHeart className="h-3.5 w-3.5" />
                            <span className="font-mono-num">{apprCount}</span>
                            <span>Apresiasi</span>
                          </button>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            playClickSound();
                            setSelectedArtworkId(art.id);
                          }}
                          className="text-xs font-semibold text-[#171923] hover:text-[#1D4ED8] dark:text-white dark:hover:text-[#60A5FA]"
                        >
                          Buka Detail &rarr;
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      )}

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#E5E0D8] bg-white p-4 dark:border-[#272E3F] dark:bg-[#151923]">
        <div className="flex flex-wrap items-center gap-1.5">
          {(
            [
              { id: 'all', label: `Semua Karya (${artworks.length})` },
              { id: 'pinned', label: `Karya Pilihan (${pinnedArtworks.length})` },
              { id: 'popular', label: 'Paling Disukai' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                playClickSound();
                setFilterMode(tab.id);
              }}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors ${
                filterMode === tab.id
                  ? 'bg-[#1D4ED8] text-white'
                  : 'bg-[#FAF9F7] text-[#4A505E] hover:bg-[#EFECE6] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            aria-label="Filter kelas"
            className="rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-1.5 text-xs font-medium text-[#171923] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
          >
            <option value="ALL">Semua Kelas</option>
            <option value="X-A">Kelas X-A</option>
            <option value="X-B">Kelas X-B</option>
            <option value="X-C">Kelas X-C</option>
          </select>

          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-[#646B7A]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari judul atau nama siswa..."
              className="w-56 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] py-1.5 pr-3 pl-8 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
            />
          </div>
        </div>
      </div>

      {/* Main Artworks Grid */}
      {filteredArtworks.length === 0 ? (
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-10 text-center dark:border-[#272E3F] dark:bg-[#151923]">
          <ImageIcon className="mx-auto h-10 w-10 text-[#94A3B8]" />
          <h3 className="mt-3 text-base font-bold text-[#171923] dark:text-white">
            Belum ada karya yang sesuai filter
          </h3>
          <p className="mt-1 text-xs text-[#646B7A] dark:text-[#94A3B8]">
            Kirimkan gambar dari tab Studio Praktik untuk memajangnya di Galeri Kelas.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filteredArtworks.map((art) => {
            const liked = (art.likedBy ?? []).includes(profile.name);
            const likeCount = art.likedBy?.length ?? 0;
            const apprCount = art.appreciations?.length ?? 0;
            const latestAppreciation =
              art.appreciations && art.appreciations.length > 0
                ? art.appreciations[art.appreciations.length - 1]
                : null;

            return (
              <article
                key={art.id}
                className={`flex flex-col overflow-hidden rounded-2xl border bg-white transition-shadow hover:shadow-md dark:bg-[#151923] ${
                  art.pinned
                    ? 'border-[#D97706]/50 dark:border-[#FBBF24]/45'
                    : 'border-[#E5E0D8] dark:border-[#272E3F]'
                }`}
              >
                {/* Artwork Canvas Frame */}
                <div className="relative border-b border-[#EEEAE2] bg-white dark:border-[#272E3F]">
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setSelectedArtworkId(art.id);
                    }}
                    className="block w-full overflow-hidden"
                  >
                    <img
                      src={art.imageDataUrl}
                      alt={art.title}
                      className="aspect-[16/10] w-full bg-white object-contain transition-transform duration-300 hover:scale-[1.02]"
                    />
                  </button>

                  {/* Top-right Pin Control */}
                  <div className="absolute top-2.5 right-2.5 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleTogglePin(art)}
                      disabled={busyPinId === art.id}
                      className={`inline-flex items-center gap-1 rounded-lg border px-2.5 py-1 text-[11px] font-semibold shadow-sm transition-colors ${
                        art.pinned
                          ? 'border-[#D97706] bg-[#FEF3C7] text-[#92400E] hover:bg-[#FDE68A]'
                          : 'border-[#D8D2C8] bg-white/95 text-[#171923] hover:bg-[#FAF9F7]'
                      }`}
                    >
                      <Pin className="h-3 w-3" />
                      <span>{art.pinned ? 'Dipin Pilihan' : 'Pin Terbaik'}</span>
                    </button>
                  </div>
                </div>

                {/* Card Body */}
                <div className="flex flex-1 flex-col justify-between p-4">
                  <div>
                    <h3 className="text-sm font-bold text-[#171923] dark:text-white">
                      {art.title}
                    </h3>
                    <div className="mt-1 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                      <span className="font-medium text-[#171923] dark:text-[#E2E8F0]">
                        {art.studentName}
                      </span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>{art.className}</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>
                        {new Date(art.createdAt).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                        })}
                      </span>
                    </div>
                    {art.description && (
                      <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                        {art.description}
                      </p>
                    )}

                    {latestAppreciation && (
                      <div className="mt-3 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-2.5 text-[11px] dark:border-[#232A3B] dark:bg-[#0D1017]">
                        <div className="font-semibold text-[#171923] dark:text-white">
                          {latestAppreciation.authorName}
                          {latestAppreciation.badge ? (
                            <span className="font-normal text-[#1D4ED8] dark:text-[#60A5FA]">
                              {' '}· {latestAppreciation.badge}
                            </span>
                          ) : null}
                        </div>
                        <p className="mt-0.5 line-clamp-2 text-[#4A505E] dark:text-[#A3B1C6]">
                          &ldquo;{latestAppreciation.message}&rdquo;
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Interactive Real-time Likes, Apresiasi, & Export Row */}
                  <div className="mt-4 flex items-center justify-between gap-2 border-t border-[#EEEAE2] pt-3 dark:border-[#272E3F]">
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleToggleLike(art)}
                        disabled={busyLikeId === art.id}
                        aria-label={`Sukai karya ${art.title}`}
                        className={`inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition-colors ${
                          liked
                            ? 'border-[#DC2626]/40 bg-red-50 text-[#DC2626] dark:bg-red-950/30 dark:text-[#F87171]'
                            : 'border-[#D8D2C8] bg-[#FAF9F7] text-[#4A505E] hover:text-[#DC2626] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-[#CBD5E1]'
                        }`}
                      >
                        <Heart className={`h-3.5 w-3.5 ${liked ? 'fill-current' : ''}`} />
                        <span className="font-mono-num">{likeCount}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          playClickSound();
                          setSelectedArtworkId(art.id);
                        }}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-2.5 py-1.5 text-xs font-semibold text-[#1D4ED8] hover:bg-[#EFF6FF] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-[#60A5FA]"
                      >
                        <MessageSquareHeart className="h-3.5 w-3.5" />
                        <span className="font-mono-num">{apprCount}</span>
                        <span>Apresiasi</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={art.imageDataUrl}
                        download={`${art.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`}
                        onClick={() => playClickSound()}
                        title="Unduh gambar karya"
                        className="rounded-lg border border-[#D8D2C8] p-1.5 text-[#4A505E] hover:text-[#171923] dark:border-[#2D3548] dark:text-[#A3B1C6] dark:hover:text-white"
                      >
                        <Download className="h-3.5 w-3.5" />
                      </a>
                      {art.driveWebViewLink && (
                        <a
                          href={art.driveWebViewLink}
                          target="_blank"
                          rel="noreferrer"
                          title="Buka di Google Drive"
                          className="rounded-lg border border-[#D8D2C8] p-1.5 text-[#059669] dark:border-[#2D3548] dark:text-[#34D399]"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Detail & Real-Time Appreciation Modal */}
      {selectedArtwork && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#0F172A]/75 p-4 backdrop-blur-sm"
          onClick={() => setSelectedArtworkId(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="grid max-h-[92vh] w-full max-w-5xl grid-cols-1 overflow-hidden rounded-2xl border border-[#E5E0D8] bg-white shadow-2xl lg:grid-cols-12 dark:border-[#272E3F] dark:bg-[#151923]"
          >
            {/* Left: Full Artwork Preview & Metadata */}
            <div className="flex flex-col justify-between overflow-y-auto border-b border-[#E5E0D8] bg-[#FAF9F7] p-6 lg:col-span-7 lg:border-r lg:border-b-0 dark:border-[#272E3F] dark:bg-[#0D1017]">
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-xs font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                      {selectedArtwork.studentName} · Kelas {selectedArtwork.className}
                    </div>
                    <h3 className="mt-1 text-xl font-bold text-[#171923] dark:text-white">
                      {selectedArtwork.title}
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setSelectedArtworkId(null);
                    }}
                    aria-label="Tutup detail karya"
                    className="rounded-lg border border-[#D8D2C8] p-1.5 text-[#4A505E] hover:bg-white lg:hidden dark:border-[#2D3548] dark:text-[#A3B1C6]"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <div className="mt-4 overflow-hidden rounded-xl border border-[#D8D2C8] bg-white dark:border-[#2D3548]">
                  <img
                    src={selectedArtwork.imageDataUrl}
                    alt={selectedArtwork.title}
                    className="max-h-[420px] w-full object-contain"
                  />
                </div>

                {selectedArtwork.description && (
                  <p className="mt-4 text-xs leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                    {selectedArtwork.description}
                  </p>
                )}

                {selectedArtwork.aiCritique && (
                  <div className="mt-4 rounded-xl border border-[#1D4ED8]/25 bg-white p-3.5 text-xs dark:border-[#3B82F6]/30 dark:bg-[#151923]">
                    <div className="flex items-center gap-1.5 font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                      <Bot className="h-3.5 w-3.5" />
                      <span>Catatan Kurator AI</span>
                    </div>
                    <p className="mt-1 text-[#4A505E] dark:text-[#CBD5E1]">
                      {selectedArtwork.aiCritique}
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-5 flex flex-wrap items-center justify-between gap-2 border-t border-[#E5E0D8] pt-4 dark:border-[#272E3F]">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleToggleLike(selectedArtwork)}
                    disabled={busyLikeId === selectedArtwork.id}
                    className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                      (selectedArtwork.likedBy ?? []).includes(profile.name)
                        ? 'border-[#DC2626]/40 bg-red-50 text-[#DC2626] dark:bg-red-950/30 dark:text-[#F87171]'
                        : 'border-[#D8D2C8] bg-white text-[#171923] dark:border-[#2D3548] dark:bg-[#151923] dark:text-white'
                    }`}
                  >
                    <Heart
                      className={`h-4 w-4 ${
                        (selectedArtwork.likedBy ?? []).includes(profile.name)
                          ? 'fill-current'
                          : ''
                      }`}
                    />
                    <span className="font-mono-num">
                      {selectedArtwork.likedBy?.length ?? 0}
                    </span>
                    <span>Suka</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleTogglePin(selectedArtwork)}
                    disabled={busyPinId === selectedArtwork.id}
                    className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                      selectedArtwork.pinned
                        ? 'border-[#D97706] bg-[#FEF3C7] text-[#92400E]'
                        : 'border-[#D8D2C8] bg-white text-[#171923] dark:border-[#2D3548] dark:bg-[#151923] dark:text-white'
                    }`}
                  >
                    {selectedArtwork.pinned ? (
                      <PinOff className="h-4 w-4" />
                    ) : (
                      <Pin className="h-4 w-4" />
                    )}
                    <span>
                      {selectedArtwork.pinned
                        ? 'Lepas Pin Karya Terbaik'
                        : 'Tandai (Pin) Karya Terbaik'}
                    </span>
                  </button>
                </div>

                <a
                  href={selectedArtwork.imageDataUrl}
                  download={`${selectedArtwork.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`}
                  onClick={() => playClickSound()}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-white px-3 py-1.5 text-xs font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#151923] dark:text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Unduh PNG</span>
                </a>
              </div>
            </div>

            {/* Right: Real-Time Appreciation Wall */}
            <div className="flex max-h-[85vh] flex-col justify-between p-6 lg:col-span-5">
              <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
                <div>
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                    <h4 className="text-base font-bold text-[#171923] dark:text-white">
                      Komentar &amp; Apresiasi ({selectedArtwork.appreciations?.length ?? 0})
                    </h4>
                  </div>
                  <p className="mt-0.5 text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                    Terbuka untuk seluruh anggota kelas
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setSelectedArtworkId(null);
                  }}
                  aria-label="Tutup modal"
                  className="hidden rounded-lg border border-[#D8D2C8] p-1.5 text-[#4A505E] hover:bg-[#FAF9F7] lg:inline-flex dark:border-[#2D3548] dark:text-[#A3B1C6]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Liked By Strip */}
              {selectedArtwork.likedBy && selectedArtwork.likedBy.length > 0 && (
                <div className="mt-3 border-b border-[#EEEAE2] pb-3 text-[11px] text-[#646B7A] dark:border-[#272E3F] dark:text-[#94A3B8]">
                  <span className="font-semibold text-[#DC2626] dark:text-[#F87171]">
                    Disukai oleh:
                  </span>{' '}
                  {selectedArtwork.likedBy.join(', ')}
                </div>
              )}

              {/* Appreciation Messages Feed */}
              <div className="my-3 flex-1 space-y-2.5 overflow-y-auto pr-1">
                {!selectedArtwork.appreciations ||
                selectedArtwork.appreciations.length === 0 ? (
                  <p className="py-6 text-center text-xs text-[#646B7A] dark:text-[#94A3B8]">
                    Belum ada catatan apresiasi. Jadilah yang pertama memberi apresiasi untuk karya {selectedArtwork.studentName}!
                  </p>
                ) : (
                  selectedArtwork.appreciations.map((appr) => (
                    <div
                      key={appr.id}
                      className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="font-bold text-[#171923] dark:text-white">
                          <span>{appr.authorName}</span>
                          <span className="mx-1.5 font-normal text-[#646B7A]" aria-hidden="true">
                            ·
                          </span>
                          <span className="font-semibold text-[#059669] dark:text-[#34D399]">
                            {appr.authorRole === 'guru' ? 'Kurator Kelas' : 'Siswa'}
                          </span>
                        </div>
                        <span className="text-[10px] text-[#646B7A] dark:text-[#94A3B8]">
                          {new Date(appr.createdAt).toLocaleTimeString('id-ID', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      {appr.badge && (
                        <div className="mt-1 text-[11px] font-semibold text-[#B45309] dark:text-[#FBBF24]">
                          Apresiasi: {appr.badge}
                        </div>
                      )}
                      <p className="mt-1 leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                        {appr.message}
                      </p>
                    </div>
                  ))
                )}
              </div>

              {/* Submit New Appreciation Form */}
              <form
                onSubmit={handleSubmitAppreciation}
                className="space-y-2.5 border-t border-[#EEEAE2] pt-3 dark:border-[#272E3F]"
              >
                <div>
                  <span className="block text-[11px] font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                    Pilih Label Apresiasi:
                  </span>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {APPRECIATION_BADGES.map((badge) => (
                      <button
                        key={badge}
                        type="button"
                        onClick={() => {
                          playClickSound();
                          setSelectedBadge(badge);
                        }}
                        className={`rounded-md border px-2 py-1 text-[11px] font-semibold transition-colors ${
                          selectedBadge === badge
                            ? 'border-[#1D4ED8] bg-[#1D4ED8] text-white'
                            : 'border-[#D8D2C8] bg-[#FAF9F7] text-[#4A505E] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                        }`}
                      >
                        {badge}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <input
                    type="text"
                    required
                    value={appreciationMsg}
                    onChange={(e) => setAppreciationMsg(e.target.value)}
                    placeholder={`Tulis komentar/apresiasi untuk ${selectedArtwork.studentName}...`}
                    className="min-w-[160px] flex-1 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  />
                  <button
                    type="submit"
                    disabled={submittingAppreciation}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF] disabled:opacity-50"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>Kirim</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
      {/* Modal: Tambah & Kirim Karya Siswa ke Galeri Real-Time */}
      {uploadModalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#0F172A]/75 p-4 backdrop-blur-sm"
          onClick={() => setUploadModalOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-[#E5E0D8] bg-white p-6 shadow-2xl dark:border-[#272E3F] dark:bg-[#151923]"
          >
            <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3.5 dark:border-[#272E3F]">
              <div className="flex items-center gap-2">
                <UploadCloud className="h-5 w-5 text-[#059669]" />
                <div>
                  <h3 className="text-base font-bold text-[#171923] dark:text-white">
                    Tambah &amp; Kirim Karya Siswa ke Galeri Kelas
                  </h3>
                  <p className="text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                    Unggah foto/gambar karya agar langsung tampil real-time di Galeri Kelas dan siap diapresiasi.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setUploadModalOpen(false);
                }}
                aria-label="Tutup form unggah karya"
                className="rounded-lg border border-[#D8D2C8] p-1.5 text-[#4A505E] hover:bg-[#FAF9F7] dark:border-[#2D3548] dark:text-[#A3B1C6]"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitNewArtwork} className="mt-4 space-y-4 text-xs">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="block font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                    Nama Siswa
                  </label>
                  <input
                    type="text"
                    required
                    value={newStudentName}
                    onChange={(e) => setNewStudentName(e.target.value)}
                    placeholder="Masukkan nama lengkap siswa"
                    className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                    Kelas
                  </label>
                  <select
                    value={newClassName}
                    onChange={(e) => setNewClassName(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  >
                    <option value="X-A">X-A</option>
                    <option value="X-B">X-B</option>
                    <option value="X-C">X-C</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                  Judul Karya
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Contoh: Komposisi Garis & Warna Harmonis"
                  className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                  Deskripsi Unsur &amp; Prinsip Karya
                </label>
                <textarea
                  rows={2}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  placeholder="Ceritakan unsur (garis, warna, tekstur) dan prinsip (keseimbangan, irama) pada karyamu..."
                  className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>

              {/* Image Picker & Preview */}
              <div className="rounded-xl border border-dashed border-[#C9C2B6] bg-[#FAF9F7] p-4 dark:border-[#2D3548] dark:bg-[#0D1017]">
                <label className="block font-semibold text-[#171923] dark:text-white">
                  Pilih Gambar Karya (PNG, JPG, WebP, SVG)
                </label>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  onChange={handlePickArtworkFile}
                  className="mt-2 block w-full text-xs text-[#4A505E] file:mr-3 file:rounded-lg file:border-0 file:bg-[#1D4ED8] file:px-3 py-1.5 file:text-xs file:font-semibold file:text-white hover:file:bg-[#1E40AF]"
                />
                {processingImage && (
                  <p className="mt-2 font-medium text-[#1D4ED8] dark:text-[#60A5FA]">
                    Memproses gambar karya...
                  </p>
                )}
                {newImageDataUrl && !processingImage && (
                  <div className="mt-3 space-y-2">
                    <div className="overflow-hidden rounded-lg border border-[#D8D2C8] bg-white dark:border-[#2D3548]">
                      <img
                        src={newImageDataUrl}
                        alt="Pratinjau karya siswa"
                        className="max-h-56 w-full object-contain"
                      />
                    </div>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-[11px] font-medium text-[#059669] dark:text-[#34D399]">
                        Siap ditampilkan: {newFileName}
                      </span>
                      <button
                        type="button"
                        onClick={handleRequestAiCritiqueForUpload}
                        disabled={critiqueBusy}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-3 py-1 text-[11px] font-semibold text-[#1D4ED8] hover:bg-[#DBEAFE] disabled:opacity-50 dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
                      >
                        <Bot className="h-3.5 w-3.5" />
                        <span>
                          {critiqueBusy ? 'Menganalisis...' : 'Lampirkan Kritik Kurator AI'}
                        </span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {aiCritiqueText && (
                <div className="rounded-xl border border-[#1D4ED8]/25 bg-[#EFF6FF]/70 p-3 text-xs dark:border-[#3B82F6]/30 dark:bg-[#1E293B]">
                  <div className="font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                    Catatan Kurator AI Terlampir:
                  </div>
                  <p className="mt-1 text-[#171923] dark:text-[#E2E8F0]">{aiCritiqueText}</p>
                </div>
              )}

              {/* Google Drive Sync Indicator */}
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] px-3.5 py-2.5 text-[11px] dark:border-[#232A3B] dark:bg-[#0D1017]">
                {getCachedAccessToken() ? (
                  <span className="flex items-center gap-1.5 font-medium text-[#059669] dark:text-[#34D399]">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Terhubung ke Google Drive — salinan karya otomatis ikut diunggah.</span>
                  </span>
                ) : (
                  <>
                    <span className="text-[#646B7A] dark:text-[#94A3B8]">
                      Ingin karya juga otomatis masuk ke folder Google Drive pemantauan?
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        onRequireGoogleLogin();
                      }}
                      className="font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                    >
                      Hubungkan Akun Google
                    </button>
                  </>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2 border-t border-[#EEEAE2] pt-3.5 dark:border-[#272E3F]">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setUploadModalOpen(false);
                  }}
                  className="rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={submittingArtwork || processingImage || !newImageDataUrl}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#059669] px-5 py-2 text-xs font-semibold text-white hover:bg-[#047857] disabled:opacity-50"
                >
                  <Send className="h-3.5 w-3.5" />
                  <span>
                    {submittingArtwork
                      ? 'Mengirim Karya...'
                      : 'Kirim & Tampilkan di Galeri'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
