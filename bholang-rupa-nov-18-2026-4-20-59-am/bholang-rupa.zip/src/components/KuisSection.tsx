import React, { useState } from 'react';
import {
  ArrowLeft,
  Bot,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  FileDown,
  FileSpreadsheet,
  FileText,
  Globe,
  ListChecks,
  Mail,
  Maximize2,
  RotateCcw,
  Send,
  XCircle,
} from 'lucide-react';
import {
  DEFAULT_SUBJECT_COMPARISONS,
  DRIVE_FOLDER_URL,
  ESSAY_QUESTIONS,
  QUIZ_QUESTIONS,
  WAYGROUND_QUIZ_URL,
} from '../data/learningContent';
import type {
  EssayAnswerSubmission,
  QuizSubmission,
  UserProfile,
} from '../types';
import {
  appendQuizScoreToSpreadsheet,
  getCachedAccessToken,
} from '../utils/firebaseGoogle';
import { exportStudentReportPdf } from '../utils/pdfExport';
import { playClickSound } from '../utils/sound';
import type { FocusViewerResource } from './ExternalReturnExperience';

interface KuisSectionProps {
  profile: UserProfile;
  quizSubmissions: QuizSubmission[];
  artworkCount: number;
  presentationCount: number;
  onQuizSubmitted: (item: QuizSubmission) => void;
  onQuizUpdated: (item: QuizSubmission) => void;
  onRequireGoogleLogin: () => Promise<boolean>;
  onRequestSendEmail?: (payload: {
    subject: string;
    summaryText: string;
    htmlBody: string;
  }) => void;
  onOpenFocusViewer?: (resource: FocusViewerResource) => void;
  onBackToMateri?: () => void;
}

export const KuisSection: React.FC<KuisSectionProps> = ({
  profile,
  quizSubmissions,
  artworkCount,
  presentationCount,
  onQuizSubmitted,
  onQuizUpdated,
  onRequireGoogleLogin,
  onRequestSendEmail,
  onOpenFocusViewer,
  onBackToMateri,
}) => {
  const [quizSectionTab, setQuizSectionTab] = useState<'kerjakan' | 'wayground' | 'rekap'>('kerjakan');
  const [partMode, setPartMode] = useState<'pg' | 'esai'>('pg');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [essayTexts, setEssayTexts] = useState<Record<string, string>>({});

  const [finished, setFinished] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [latestResult, setLatestResult] = useState<QuizSubmission | null>(null);
  const [driveSyncMsg, setDriveSyncMsg] = useState<{
    ok: boolean;
    text: string;
    url?: string;
  } | null>(null);

  const [hintLoading, setHintLoading] = useState(false);
  const [hints, setHints] = useState<Record<string, string>>({});

  const currentQuestion = QUIZ_QUESTIONS[currentIdx];
  const answeredPgCount = Object.keys(answers).length;
  const answeredEssayCount = ESSAY_QUESTIONS.filter(
    (eq) => (essayTexts[eq.id] || '').trim().length > 0
  ).length;

  const requestHint = async () => {
    playClickSound();
    if (hints[currentQuestion.id] || hintLoading) return;
    setHintLoading(true);
    try {
      const res = await fetch('/api/ai/quiz-hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: currentQuestion.question,
          topic: `${currentQuestion.bloomLevel} · ${currentQuestion.category} — ${currentQuestion.topic}`,
        }),
      });
      const data = (await res.json()) as { hint?: string };
      if (res.ok && data.hint) {
        setHints((prev) => ({ ...prev, [currentQuestion.id]: data.hint! }));
      }
    } finally {
      setHintLoading(false);
    }
  };

  const syncResultToGoogleSheet = async (submission: QuizSubmission) => {
    try {
      const { spreadsheetUrl } = await appendQuizScoreToSpreadsheet(submission);
      const patchRes = await fetch(`/api/quiz/${submission.id}/drive-sync`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ driveSynced: true, spreadsheetUrl }),
      });
      const patched = (await patchRes.json()) as { item?: QuizSubmission };
      if (patched.item) {
        setLatestResult(patched.item);
        onQuizUpdated(patched.item);
      }
      setDriveSyncMsg({
        ok: true,
        text: 'Skor PG & ringkasan Esai C1–C6 otomatis tercatat ke Google Sheets folder Drive!',
        url: spreadsheetUrl,
      });
    } catch (err) {
      setDriveSyncMsg({
        ok: false,
        text: err instanceof Error ? err.message : 'Gagal menyinkronkan ke Google Sheets.',
      });
    }
  };

  const handleFinishQuiz = async () => {
    playClickSound();
    setSubmitting(true);
    setDriveSyncMsg(null);

    let totalCorrect = 0;
    let unsurCorrect = 0;
    let unsurTotal = 0;
    let prinsipCorrect = 0;
    let prinsipTotal = 0;

    QUIZ_QUESTIONS.forEach((q) => {
      const chosen = answers[q.id];
      const isRight = chosen === q.correctIndex;
      if (isRight) totalCorrect += 1;
      if (q.category === 'Unsur Seni Rupa') {
        unsurTotal += 1;
        if (isRight) unsurCorrect += 1;
      } else {
        prinsipTotal += 1;
        if (isRight) prinsipCorrect += 1;
      }
    });

    const score = Math.round((totalCorrect / QUIZ_QUESTIONS.length) * 100);
    const unsurScore = Math.round((unsurCorrect / Math.max(1, unsurTotal)) * 100);
    const prinsipScore = Math.round((prinsipCorrect / Math.max(1, prinsipTotal)) * 100);

    const predicate =
      score >= 90
        ? 'Sangat Baik'
        : score >= 75
          ? 'Baik'
          : score >= 60
            ? 'Cukup'
            : 'Perlu Bimbingan';

    const essayPayload: EssayAnswerSubmission[] = ESSAY_QUESTIONS.map((eq) => ({
      questionId: eq.id,
      bloomLevel: eq.bloomLevel,
      question: eq.question,
      answer: (essayTexts[eq.id] || '').trim(),
    }));

    const notes =
      unsurScore >= prinsipScore
        ? 'Penguasaan unsur visual kuat; terus latih penerapan prinsip komposisi.'
        : 'Pemahaman prinsip komposisi bagus; perkuat identifikasi unsur garis, warna, & tekstur.';

    try {
      const payload: Partial<QuizSubmission> = {
        studentName: profile.name,
        className: profile.className,
        topic: 'Evaluasi C1–C6 (PG + Esai) Seni Rupa KD 3.1',
        score,
        unsurScore,
        prinsipScore,
        correctCount: totalCorrect,
        totalQuestions: QUIZ_QUESTIONS.length,
        predicate,
        notes,
        essayAnswers: essayPayload,
        driveSynced: false,
      };

      const res = await fetch('/api/quiz/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { item?: QuizSubmission; error?: string };
      if (!res.ok || !data.item) throw new Error(data.error || 'Gagal menyimpan kuis.');

      setLatestResult(data.item);
      onQuizSubmitted(data.item);
      setFinished(true);

      if (getCachedAccessToken()) {
        await syncResultToGoogleSheet(data.item);
      } else {
        setDriveSyncMsg({
          ok: false,
          text: 'Skor PG dan jawaban esai C1–C6 sudah tercatat! Hubungkan Google untuk menyimpan otomatis ke spreadsheet folder Drive & mengirim ke E-mail pemantauan.',
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleManualGoogleSync = async () => {
    playClickSound();
    if (!latestResult) return;
    if (!getCachedAccessToken()) {
      const connected = await onRequireGoogleLogin();
      if (!connected) return;
    }
    await syncResultToGoogleSheet(latestResult);
  };

  const handleResetQuiz = () => {
    playClickSound();
    setAnswers({});
    setEssayTexts({});
    setCurrentIdx(0);
    setPartMode('pg');
    setFinished(false);
    setLatestResult(null);
    setDriveSyncMsg(null);
  };

  const handleExportPdf = () => {
    playClickSound();
    const mySubs = quizSubmissions.filter(
      (q) => q.studentName.toLowerCase() === profile.name.toLowerCase()
    );
    const activeSubs =
      mySubs.length > 0 ? mySubs : latestResult ? [latestResult] : quizSubmissions;
    const avgUnsur =
      activeSubs.length > 0
        ? Math.round(
            activeSubs.reduce((a, b) => a + b.unsurScore, 0) / activeSubs.length
          )
        : 85;
    const avgPrinsip =
      activeSubs.length > 0
        ? Math.round(
            activeSubs.reduce((a, b) => a + b.prinsipScore, 0) / activeSubs.length
          )
        : 82;

    const subjectData = DEFAULT_SUBJECT_COMPARISONS.map((row) => {
      if (row.subject === 'Unsur Seni Rupa') return { ...row, studentScore: avgUnsur };
      if (row.subject === 'Prinsip Seni Rupa') return { ...row, studentScore: avgPrinsip };
      return row;
    });

    exportStudentReportPdf({
      studentName: profile.name,
      className: profile.className,
      submissions: activeSubs,
      subjectComparisons: subjectData,
      artworkCount,
      presentationCount,
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Switcher: Kerjakan Kuis vs Lihat Papan Skor Langsung */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#171923] dark:text-white">
            Kuis Evaluasi (Pilihan Ganda &amp; Esai C1–C6)
          </h2>
          <p className="mt-0.5 text-sm text-[#4A505E] dark:text-[#A3B1C6]">
            Tanpa batas waktu · Soal mencakup tingkat kognitif C1 (Mengingat) hingga C6 (Mencipta) · Hasil penilaian otomatis masuk ke Google Drive &amp; E-mail pemantauan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-[#E5E0D8] bg-[#F2EFE9] p-1 dark:border-[#272E3F] dark:bg-[#151923]">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setQuizSectionTab('kerjakan');
            }}
            className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              quizSectionTab === 'kerjakan'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            Kerjakan Soal C1–C6
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setQuizSectionTab('wayground');
            }}
            className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              quizSectionTab === 'wayground'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            <Globe className="h-3.5 w-3.5" />
            <span>Kuis Wayground</span>
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setQuizSectionTab('rekap');
            }}
            className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              quizSectionTab === 'rekap'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            Skor Langsung Evaluasi ({quizSubmissions.length})
          </button>
        </div>
      </div>

      {/* Wayground External Interactive Quiz View */}
      {quizSectionTab === 'wayground' && (
        <div className="space-y-4 rounded-2xl border border-[#E5E0D8] bg-white p-6 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EEEAE2] pb-4 dark:border-[#272E3F]">
            <div>
              <h3 className="text-lg font-bold text-[#171923] dark:text-white">
                Kuis Interaktif Wayground — Seni Rupa KD 3.1
              </h3>
              <p className="mt-0.5 text-xs text-[#4A505E] dark:text-[#A3B1C6]">
                Kerjakan kuis Wayground langsung di dalam halaman ini atau buka di tab luar, lalu gunakan tombol{' '}
                <strong>Kembali ke Web</strong> kapan saja.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  playClickSound();
                  setQuizSectionTab('kerjakan');
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-[#1E40AF]"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Kembali ke Web (Kuis C1–C6)</span>
              </button>
              {onBackToMateri && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onBackToMateri();
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>Kembali ke Materi</span>
                </button>
              )}
              {onOpenFocusViewer && (
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onOpenFocusViewer({
                      title: 'Kuis Interaktif Wayground — BHOLANG RUPA',
                      subtitle: 'Kuis Eksternal Wayground · Klik "Kembali ke Web BHOLANG RUPA" saat selesai',
                      embedUrl: WAYGROUND_QUIZ_URL,
                      externalUrl: WAYGROUND_QUIZ_URL,
                    });
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-3.5 py-2 text-xs font-semibold text-[#1D4ED8] hover:bg-[#DBEAFE] dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
                >
                  <Maximize2 className="h-3.5 w-3.5" />
                  <span>Layar Penuh</span>
                </button>
              )}
              <a
                href={WAYGROUND_QUIZ_URL}
                target="_blank"
                rel="noreferrer"
                data-resource-label="Kuis Interaktif Wayground"
                onClick={() => playClickSound()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#059669] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#047857]"
              >
                <span>Buka Wayground di Tab Baru</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-[#E5E0D8] bg-[#FAF9F7] dark:border-[#272E3F] dark:bg-[#0D1017]">
            <iframe
              src={WAYGROUND_QUIZ_URL}
              title="Kuis Interaktif Wayground BHOLANG RUPA"
              allow="fullscreen; clipboard-write"
              allowFullScreen
              className="h-[600px] w-full border-0 bg-white"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] px-4 py-3 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
            <span className="text-[#4A505E] dark:text-[#A3B1C6]">
              Jika tampilan kuis Wayground belum muncul di bingkai di atas karena kebijakan keamanan browser, silakan klik{' '}
              <strong>Buka Wayground di Tab Baru</strong>, lalu kembali ke tab ini.
            </span>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                setQuizSectionTab('kerjakan');
              }}
              className="inline-flex items-center gap-1.5 font-bold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Kembali ke Web BHOLANG RUPA</span>
            </button>
          </div>
        </div>
      )}

      {/* Live Score Board */}
      {quizSectionTab === 'rekap' && (
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div>
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Papan Skor Kuis Langsung (Evaluasi C1–C6)
              </h3>
              <p className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
                Nilai pilihan ganda muncul seketika setelah dikumpulkan bersama status esai C1–C6.
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportPdf}
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
            >
              <FileDown className="h-3.5 w-3.5" />
              <span>Ekspor Laporan PDF Saya</span>
            </button>
          </div>

          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#EEEAE2] text-[#646B7A] dark:border-[#272E3F] dark:text-[#94A3B8]">
                  <th className="py-2.5 pr-3 font-semibold">Nama Siswa</th>
                  <th className="py-2.5 px-3 font-semibold">Kelas</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Skor PG</th>
                  <th className="py-2.5 px-3 text-right font-semibold">Skor Esai</th>
                  <th className="py-2.5 px-3 font-semibold">Predikat</th>
                  <th className="py-2.5 pl-3 font-semibold">Waktu Kirim</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEEAE2] dark:divide-[#272E3F]">
                {quizSubmissions.map((q) => (
                  <tr key={q.id} className="hover:bg-[#FAF9F7] dark:hover:bg-[#0D1017]/60">
                    <td className="py-3 pr-3 font-semibold text-[#171923] dark:text-white">
                      {q.studentName}
                    </td>
                    <td className="py-3 px-3 text-[#4A505E] dark:text-[#A3B1C6]">{q.className}</td>
                    <td className="font-mono-num py-3 px-3 text-right font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                      {q.score}
                    </td>
                    <td className="font-mono-num py-3 px-3 text-right font-semibold text-[#059669] dark:text-[#34D399]">
                      {typeof q.essayScore === 'number'
                        ? q.essayScore
                        : q.essayAnswers && q.essayAnswers.some((e) => e.answer.trim())
                          ? 'Menunggu penilaian'
                          : '-'}
                    </td>
                    <td className="py-3 px-3 font-semibold text-[#171923] dark:text-[#E2E8F0]">
                      {q.predicate}
                    </td>
                    <td className="py-3 pl-3 text-[#646B7A] dark:text-[#94A3B8]">
                      {new Date(q.createdAt).toLocaleString('id-ID', {
                        dateStyle: 'short',
                        timeStyle: 'short',
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Result View */}
      {quizSectionTab === 'kerjakan' && finished && latestResult && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8 dark:border-[#272E3F] dark:bg-[#151923]">
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#EEEAE2] pb-5 dark:border-[#272E3F]">
              <div>
                <div className="text-xs font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                  Skor Langsung Evaluasi C1–C6
                </div>
                <h3 className="mt-1 text-2xl font-bold text-[#171923] dark:text-white">
                  {latestResult.studentName} · {latestResult.className}
                </h3>
                <p className="mt-1 text-sm text-[#4A505E] dark:text-[#A3B1C6]">
                  {latestResult.notes}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                {onRequestSendEmail && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      const essayRows = (latestResult.essayAnswers || [])
                        .map(
                          (ea, i) =>
                            `<tr><td style="padding:6px;border:1px solid #e5e7eb;">${i + 1}. ${ea.bloomLevel}</td><td style="padding:6px;border:1px solid #e5e7eb;">${ea.question}</td><td style="padding:6px;border:1px solid #e5e7eb;">${ea.answer || '(Tidak diisi)'}</td></tr>`
                        )
                        .join('');
                      onRequestSendEmail({
                        subject: `[BHOLANG RUPA] Nilai Kuis C1-C6 - ${latestResult.studentName} (${latestResult.className})`,
                        summaryText: `Skor PG: ${latestResult.score} (${latestResult.predicate}) | Unsur: ${latestResult.unsurScore}% | Prinsip: ${latestResult.prinsipScore}% | Esai terisi: ${answeredEssayCount}/${ESSAY_QUESTIONS.length}.`,
                        htmlBody: `
                          <div style="font-family:sans-serif;max-width:680px;color:#171923;">
                            <h2 style="color:#1D4ED8;">Laporan Penilaian Kuis Seni Rupa (C1–C6)</h2>
                            <p><strong>Nama Siswa:</strong> ${latestResult.studentName} (${latestResult.className})</p>
                            <p><strong>Skor Pilihan Ganda:</strong> ${latestResult.score} / 100 (${latestResult.predicate})</p>
                            <p><strong>Ketuntasan Materi:</strong> Unsur Seni Rupa ${latestResult.unsurScore}% · Prinsip Seni Rupa ${latestResult.prinsipScore}%</p>
                            <p><strong>Benar PG:</strong> ${latestResult.correctCount} dari ${latestResult.totalQuestions} soal</p>
                            <h3 style="margin-top:16px;">Jawaban Esai Berjenjang C1–C6</h3>
                            <table style="width:100%;border-collapse:collapse;font-size:12px;">
                              <thead><tr style="background:#f3f4f6;"><th style="padding:6px;border:1px solid #e5e7eb;text-align:left;">Level</th><th style="padding:6px;border:1px solid #e5e7eb;text-align:left;">Pertanyaan</th><th style="padding:6px;border:1px solid #e5e7eb;text-align:left;">Jawaban Siswa</th></tr></thead>
                              <tbody>${essayRows}</tbody>
                            </table>
                            <p style="margin-top:16px;"><strong>Folder Drive Evaluasi:</strong> <a href="${DRIVE_FOLDER_URL}">${DRIVE_FOLDER_URL}</a></p>
                          </div>
                        `,
                      });
                    }}
                    className="inline-flex items-center gap-2 rounded-lg bg-[#059669] px-4 py-2 text-xs font-semibold text-white hover:bg-[#047857]"
                  >
                    <Mail className="h-4 w-4" />
                    <span>Kirim Nilai ke E-mail Pemantauan</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleExportPdf}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
                >
                  <FileDown className="h-4 w-4" />
                  <span>Ekspor Laporan Nilai (PDF)</span>
                </button>
                <button
                  type="button"
                  onClick={handleResetQuiz}
                  className="inline-flex items-center gap-2 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>Kerjakan Lagi</span>
                </button>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
              <div className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
                <div className="text-xs text-[#646B7A] dark:text-[#94A3B8]">Skor Pilihan Ganda</div>
                <div className="font-mono-num mt-1 text-3xl font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                  {latestResult.score}
                </div>
                <div className="mt-0.5 text-xs font-medium text-[#171923] dark:text-white">
                  Predikat: {latestResult.predicate}
                </div>
              </div>
              <div className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
                <div className="text-xs text-[#646B7A] dark:text-[#94A3B8]">Jawaban PG Benar</div>
                <div className="font-mono-num mt-1 text-3xl font-bold text-[#171923] dark:text-white">
                  {latestResult.correctCount}/{latestResult.totalQuestions}
                </div>
                <div className="mt-0.5 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  C1–C6 Terpenuhi
                </div>
              </div>
              <div className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
                <div className="text-xs text-[#646B7A] dark:text-[#94A3B8]">Unsur / Prinsip</div>
                <div className="font-mono-num mt-1 text-2xl font-bold text-[#059669] dark:text-[#34D399]">
                  {latestResult.unsurScore}% / {latestResult.prinsipScore}%
                </div>
                <div className="mt-0.5 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  Pemetaan Materi
                </div>
              </div>
              <div className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]">
                <div className="text-xs text-[#646B7A] dark:text-[#94A3B8]">Esai C1–C6 Terkirim</div>
                <div className="font-mono-num mt-1 text-3xl font-bold text-[#0284C7] dark:text-[#38BDF8]">
                  {answeredEssayCount}/{ESSAY_QUESTIONS.length}
                </div>
                <div className="mt-0.5 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  Tersimpan untuk Penilaian
                </div>
              </div>
            </div>

            {/* Google Sheets Sync Box */}
            <div className="mt-5 rounded-xl border border-[#E5E0D8] bg-[#FAF9F7] p-4 dark:border-[#272E3F] dark:bg-[#0D1017]">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="h-5 w-5 text-[#059669]" />
                  <div>
                    <div className="text-xs font-bold text-[#171923] dark:text-white">
                      Penyimpanan Otomatis Spreadsheet Evaluasi (Google Drive)
                    </div>
                    <p className="text-xs text-[#4A505E] dark:text-[#A3B1C6]">
                      {driveSyncMsg?.text ||
                        'Menyiapkan sinkronisasi ke folder evaluasi hasil belajar...'}
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {driveSyncMsg?.url ? (
                    <a
                      href={driveSyncMsg.url}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#059669] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#047857]"
                    >
                      <span>Buka Google Sheets</span>
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  ) : (
                    <button
                      type="button"
                      onClick={handleManualGoogleSync}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#059669] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#047857]"
                    >
                      <FileSpreadsheet className="h-3.5 w-3.5" />
                      <span>Simpan ke Google Sheets</span>
                    </button>
                  )}
                  <a
                    href={DRIVE_FOLDER_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] bg-white px-3 py-2 text-xs font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#151923] dark:text-white"
                  >
                    <span>Folder Drive</span>
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Pembahasan Pilihan Ganda */}
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 dark:border-[#272E3F] dark:bg-[#151923]">
            <h3 className="text-lg font-bold text-[#171923] dark:text-white">
              Pembahasan Pilihan Ganda (C1–C6)
            </h3>
            <div className="mt-4 space-y-3">
              {QUIZ_QUESTIONS.map((q, idx) => {
                const selected = answers[q.id];
                const isCorrect = selected === q.correctIndex;
                return (
                  <div
                    key={q.id}
                    className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-semibold text-[#646B7A] dark:text-[#94A3B8]">
                        Soal {idx + 1} · {q.bloomLevel} · {q.category}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 text-xs font-bold ${
                          isCorrect
                            ? 'text-[#059669] dark:text-[#34D399]'
                            : 'text-[#DC2626] dark:text-[#F87171]'
                        }`}
                      >
                        {isCorrect ? (
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        ) : (
                          <XCircle className="h-3.5 w-3.5" />
                        )}
                        <span>{isCorrect ? 'Benar' : 'Belum Tepat'}</span>
                      </span>
                    </div>
                    <p className="mt-1.5 text-sm font-semibold text-[#171923] dark:text-white">
                      {q.question}
                    </p>
                    <p className="mt-2 text-xs text-[#059669] dark:text-[#34D399]">
                      Jawaban Benar: {q.options[q.correctIndex]}
                    </p>
                    <p className="mt-1.5 text-xs leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                      {q.explanation}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Ringkasan Jawaban Esai Terkirim */}
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 dark:border-[#272E3F] dark:bg-[#151923]">
            <h3 className="text-lg font-bold text-[#171923] dark:text-white">
              Jawaban Esai C1–C6 yang Dikirim untuk Penilaian
            </h3>
            <div className="mt-4 space-y-3">
              {ESSAY_QUESTIONS.map((eq, idx) => (
                <div
                  key={eq.id}
                  className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]"
                >
                  <div className="text-xs font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                    Esai {idx + 1} · {eq.bloomLabel} · {eq.topic}
                  </div>
                  <p className="mt-1 text-sm font-semibold text-[#171923] dark:text-white">
                    {eq.question}
                  </p>
                  <p className="mt-2 rounded-lg bg-white p-3 text-xs text-[#171923] dark:bg-[#151923] dark:text-[#E2E8F0]">
                    {(essayTexts[eq.id] || '').trim() || '(Tidak diisi)'}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Active Quiz Working Area (No Timer!) */}
      {quizSectionTab === 'kerjakan' && !finished && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8 lg:col-span-8 dark:border-[#272E3F] dark:bg-[#151923]">
            {/* Part Switcher: Pilihan Ganda vs Esai */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EEEAE2] pb-4 dark:border-[#272E3F]">
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setPartMode('pg');
                  }}
                  className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold ${
                    partMode === 'pg'
                      ? 'bg-[#1D4ED8] text-white'
                      : 'bg-[#FAF9F7] text-[#4A505E] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                  }`}
                >
                  <ListChecks className="h-3.5 w-3.5" />
                  <span>
                    Bagian A: Pilihan Ganda ({answeredPgCount}/{QUIZ_QUESTIONS.length})
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setPartMode('esai');
                  }}
                  className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold ${
                    partMode === 'esai'
                      ? 'bg-[#1D4ED8] text-white'
                      : 'bg-[#FAF9F7] text-[#4A505E] dark:bg-[#0D1017] dark:text-[#A3B1C6]'
                  }`}
                >
                  <FileText className="h-3.5 w-3.5" />
                  <span>
                    Bagian B: Esai C1–C6 ({answeredEssayCount}/{ESSAY_QUESTIONS.length})
                  </span>
                </button>
              </div>

              <span className="text-xs font-medium text-[#059669] dark:text-[#34D399]">
                Bebas Waktu · Fokus Pemahaman
              </span>
            </div>

            {partMode === 'pg' ? (
              <>
                <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  <span className="font-mono-num font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                    Soal {currentIdx + 1} / {QUIZ_QUESTIONS.length}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-semibold text-[#171923] dark:text-white">
                    Tingkat {currentQuestion.bloomLevel}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{currentQuestion.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{currentQuestion.topic}</span>
                </div>

                <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-[#EEEAE2] dark:bg-[#232A3B]">
                  <div
                    className="h-full bg-[#1D4ED8] transition-all duration-200 dark:bg-[#3B82F6]"
                    style={{
                      width: `${((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100}%`,
                    }}
                  />
                </div>

                <div className="mt-6">
                  <p className="text-base font-semibold leading-relaxed text-[#171923] sm:text-lg dark:text-white">
                    {currentQuestion.question}
                  </p>

                  <div className="mt-5 space-y-2.5">
                    {currentQuestion.options.map((opt, idx) => {
                      const isSelected = answers[currentQuestion.id] === idx;
                      const letter = String.fromCharCode(65 + idx);
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            playClickSound();
                            setAnswers((prev) => ({
                              ...prev,
                              [currentQuestion.id]: idx,
                            }));
                          }}
                          className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3.5 text-left text-sm transition-all ${
                            isSelected
                              ? 'border-[#1D4ED8] bg-[#EFF6FF] font-semibold text-[#1E3A8A] dark:border-[#60A5FA] dark:bg-[#1E293B] dark:text-white'
                              : 'border-[#E5E0D8] bg-[#FAF9F7] text-[#171923] hover:border-[#C5BFB3] dark:border-[#272E3F] dark:bg-[#0D1017] dark:text-[#E2E8F0]'
                          }`}
                        >
                          <span
                            className={`font-mono-num flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold ${
                              isSelected
                                ? 'bg-[#1D4ED8] text-white'
                                : 'border border-[#D8D2C8] bg-white text-[#4A505E] dark:border-[#2D3548] dark:bg-[#151923] dark:text-[#A3B1C6]'
                            }`}
                          >
                            {letter}
                          </span>
                          <span>{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="mt-5">
                  <button
                    type="button"
                    onClick={requestHint}
                    disabled={hintLoading}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                  >
                    <Bot className="h-3.5 w-3.5" />
                    <span>
                      {hintLoading
                        ? 'Menyiapkan petunjuk...'
                        : 'Minta Petunjuk Berpikir AI (Tanpa Bocoran)'}
                    </span>
                  </button>
                  {hints[currentQuestion.id] && (
                    <div className="mt-2 rounded-xl border border-[#1D4ED8]/25 bg-[#EFF6FF] p-3 text-xs text-[#1E3A8A] dark:border-[#3B82F6]/30 dark:bg-[#1E293B] dark:text-[#DBEAFE]">
                      {hints[currentQuestion.id]}
                    </div>
                  )}
                </div>

                <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-[#EEEAE2] pt-4 dark:border-[#272E3F]">
                  <button
                    type="button"
                    disabled={currentIdx === 0}
                    onClick={() => {
                      playClickSound();
                      setCurrentIdx((i) => Math.max(0, i - 1));
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] disabled:opacity-40 dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    <span>Sebelumnya</span>
                  </button>

                  {currentIdx < QUIZ_QUESTIONS.length - 1 ? (
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setCurrentIdx((i) => Math.min(QUIZ_QUESTIONS.length - 1, i + 1));
                      }}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-5 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
                    >
                      <span>Berikutnya</span>
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setPartMode('esai');
                      }}
                      className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-5 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
                    >
                      <span>Lanjut ke Soal Esai C1–C6</span>
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </>
            ) : (
              /* ESSAY SECTION C1 - C6 */
              <div className="mt-5 space-y-5">
                <div className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 text-xs text-[#4A505E] dark:border-[#232A3B] dark:bg-[#0D1017] dark:text-[#A3B1C6]">
                  Jawablah 6 soal esai berjenjang dari tingkat <strong>C1 (Mengingat)</strong> hingga{' '}
                  <strong>C6 (Mencipta)</strong> di bawah ini, lalu kirimkan bersama skor pilihan ganda untuk tersimpan di Drive &amp; laporan E-mail.
                </div>

                {ESSAY_QUESTIONS.map((eq, idx) => (
                  <div
                    key={eq.id}
                    className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 dark:border-[#232A3B] dark:bg-[#0D1017]"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                        Esai {idx + 1} · {eq.bloomLabel}
                      </span>
                      <span className="text-[#646B7A] dark:text-[#94A3B8]">
                        {eq.category} · {eq.topic}
                      </span>
                    </div>
                    <p className="mt-1.5 text-sm font-semibold text-[#171923] dark:text-white">
                      {eq.question}
                    </p>
                    <p className="mt-1 text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                      Panduan: {eq.rubricHint}
                    </p>
                    <textarea
                      rows={3}
                      value={essayTexts[eq.id] || ''}
                      onChange={(e) =>
                        setEssayTexts((prev) => ({ ...prev, [eq.id]: e.target.value }))
                      }
                      placeholder="Tuliskan jawaban uraian Anda di sini..."
                      className="mt-2.5 w-full rounded-lg border border-[#D8D2C8] bg-white px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#151923] dark:text-white"
                    />
                  </div>
                ))}

                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#EEEAE2] pt-4 dark:border-[#272E3F]">
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setPartMode('pg');
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    <span>Kembali ke Pilihan Ganda</span>
                  </button>

                  <button
                    type="button"
                    disabled={submitting}
                    onClick={handleFinishQuiz}
                    className="inline-flex items-center gap-2 rounded-lg bg-[#059669] px-5 py-2.5 text-xs font-semibold text-white hover:bg-[#047857] disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                    <span>
                      {submitting
                        ? 'Mengirim ke Drive & Pemantauan...'
                        : 'Kirim Kuis (PG + Esai)'}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Panel: C1-C6 Question Map */}
          <div className="space-y-5 lg:col-span-4">
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#171923] dark:text-white">
                  Peta Soal PG (C1–C6)
                </h3>
                <span className="font-mono-num text-xs font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                  {answeredPgCount}/{QUIZ_QUESTIONS.length} Terjawab
                </span>
              </div>

              <div className="mt-4 grid grid-cols-4 gap-2">
                {QUIZ_QUESTIONS.map((q, idx) => {
                  const isCurrent = partMode === 'pg' && idx === currentIdx;
                  const isAnswered = typeof answers[q.id] === 'number';
                  return (
                    <button
                      key={q.id}
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setPartMode('pg');
                        setCurrentIdx(idx);
                      }}
                      className={`font-mono-num rounded-lg border py-1.5 text-xs font-bold transition-colors ${
                        isCurrent
                          ? 'border-[#1D4ED8] bg-[#1D4ED8] text-white'
                          : isAnswered
                            ? 'border-[#059669]/40 bg-emerald-50 text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-300'
                            : 'border-[#E5E0D8] bg-[#FAF9F7] text-[#4A505E] dark:border-[#272E3F] dark:bg-[#0D1017] dark:text-[#94A3B8]'
                      }`}
                    >
                      <div>{idx + 1}</div>
                      <div className="text-[9px] font-normal opacity-80">{q.bloomLevel}</div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-4 border-t border-[#EEEAE2] pt-3 dark:border-[#272E3F]">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#171923] dark:text-white">
                    Soal Esai C1–C6
                  </span>
                  <span className="font-mono-num font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                    {answeredEssayCount}/{ESSAY_QUESTIONS.length} Terisi
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setPartMode('esai');
                  }}
                  className="mt-2 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  Buka Lembar Esai C1–C6
                </button>
              </div>

              <button
                type="button"
                disabled={submitting || (answeredPgCount === 0 && answeredEssayCount === 0)}
                onClick={handleFinishQuiz}
                className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#059669] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#047857] disabled:opacity-40"
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>Kumpulkan &amp; Lihat Skor Sekarang</span>
              </button>
            </div>

            {/* External Wayground Quiz Shortcut Card */}
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <h3 className="text-sm font-bold text-[#171923] dark:text-white">
                  Kuis Interaktif Wayground
                </h3>
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-[#4A505E] dark:text-[#A3B1C6]">
                Akses paket latihan interaktif Wayground langsung dari halaman ini dengan tombol{' '}
                <strong>Kembali ke Web</strong> kapan saja.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setQuizSectionTab('wayground');
                  }}
                  className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF]"
                >
                  <Globe className="h-3.5 w-3.5" />
                  <span>Buka di Halaman Kuis</span>
                </button>
                <a
                  href={WAYGROUND_QUIZ_URL}
                  target="_blank"
                  rel="noreferrer"
                  data-resource-label="Kuis Interaktif Wayground"
                  onClick={() => playClickSound()}
                  className="inline-flex items-center justify-center gap-1 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  <span>Tab Luar</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
