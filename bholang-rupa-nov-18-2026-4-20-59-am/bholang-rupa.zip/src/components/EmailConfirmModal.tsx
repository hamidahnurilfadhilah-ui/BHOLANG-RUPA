import React from 'react';
import { Mail, Send, X } from 'lucide-react';
import { playClickSound } from '../utils/sound';

export interface PendingEmailPayload {
  to: string;
  subject: string;
  summaryText: string;
  htmlBody: string;
}

interface EmailConfirmModalProps {
  pending: PendingEmailPayload | null;
  sending: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export const EmailConfirmModal: React.FC<EmailConfirmModalProps> = ({
  pending,
  sending,
  onCancel,
  onConfirm,
}) => {
  if (!pending) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="email-confirm-title"
    >
      <div className="w-full max-w-lg overflow-hidden rounded-2xl border border-[#E5E0D8] bg-white shadow-2xl dark:border-[#272E3F] dark:bg-[#151923]">
        <div className="flex items-center justify-between border-b border-[#EEEAE2] px-5 py-4 dark:border-[#272E3F]">
          <div className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-[#1D4ED8] dark:text-[#60A5FA]" />
            <h3
              id="email-confirm-title"
              className="text-base font-bold text-[#171923] dark:text-white"
            >
              Konfirmasi Pengiriman Laporan ke E-mail
            </h3>
          </div>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              onCancel();
            }}
            aria-label="Tutup dialog konfirmasi"
            className="rounded-lg p-1 text-[#646B7A] hover:bg-[#FAF9F7] dark:text-[#94A3B8] dark:hover:bg-[#0D1017]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-3 p-5 text-xs">
          <p className="leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
            Pastikan data pemantauan dan penilaian di bawah ini sudah benar sebelum dikirimkan melalui Gmail ke alamat e-mail tujuan:
          </p>

          <div className="space-y-2 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3.5 dark:border-[#232A3B] dark:bg-[#0D1017]">
            <div>
              <span className="font-semibold text-[#646B7A] dark:text-[#94A3B8]">Tujuan: </span>
              <span className="font-mono-num font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                {pending.to}
              </span>
            </div>
            <div>
              <span className="font-semibold text-[#646B7A] dark:text-[#94A3B8]">Subjek: </span>
              <span className="font-semibold text-[#171923] dark:text-white">
                {pending.subject}
              </span>
            </div>
            <div className="border-t border-[#E5E0D8] pt-2 text-[#4A505E] dark:border-[#232A3B] dark:text-[#CBD5E1]">
              {pending.summaryText}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2 border-t border-[#EEEAE2] px-5 py-3.5 dark:border-[#272E3F]">
          <button
            type="button"
            disabled={sending}
            onClick={() => {
              playClickSound();
              onCancel();
            }}
            className="rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] disabled:opacity-50 dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
          >
            Batal
          </button>
          <button
            type="button"
            disabled={sending}
            onClick={() => {
              playClickSound();
              onConfirm();
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF] disabled:opacity-50"
          >
            <Send className="h-3.5 w-3.5" />
            <span>{sending ? 'Mengirim E-mail...' : 'Konfirmasi & Kirim E-mail'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
