import React, { useEffect, useState } from 'react';
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Download,
  ExternalLink,
  Eye,
  FileUp,
  MessageSquare,
  Plus,
  Presentation,
  Reply,
  Send,
  Trash2,
  UploadCloud,
} from 'lucide-react';
import { DRIVE_FOLDER_URL } from '../data/learningContent';
import type {
  ForumMessage,
  ParsedPptxSlide,
  PresentationComment,
  PresentationSlide,
  PresentationSubmission,
  UserProfile,
} from '../types';
import {
  getCachedAccessToken,
  uploadBlobToDriveFolder,
} from '../utils/firebaseGoogle';
import { parsePptxFileToSlides } from '../utils/pptxParser';
import { playClickSound } from '../utils/sound';

interface PresentasiDiskusiSectionProps {
  profile: UserProfile;
  presentations: PresentationSubmission[];
  onPresentationSubmitted: (item: PresentationSubmission) => void;
  onPresentationCommentAdded: (
    presentationId: string,
    comment: PresentationComment
  ) => void;
  forumMessages: ForumMessage[];
  onForumCreated: (msg: ForumMessage) => void;
  onForumReply: (messageId: string, reply: ForumMessage['replies'][number]) => void;
  onRequireGoogleLogin: () => void;
  onRequestSendEmail?: (payload: {
    subject: string;
    summaryText: string;
    htmlBody: string;
  }) => void;
}

export const PresentasiDiskusiSection: React.FC<PresentasiDiskusiSectionProps> = ({
  profile,
  presentations,
  onPresentationSubmitted,
  onPresentationCommentAdded,
  forumMessages,
  onForumCreated,
  onForumReply,
  onRequireGoogleLogin,
  onRequestSendEmail,
}) => {
  const [subMode, setSubMode] = useState<'presentasi' | 'diskusi'>('presentasi');

  // --- Presentation Builder / Upload State ---
  const [presMode, setPresMode] = useState<'deck' | 'file'>('deck');
  const [presTitle, setPresTitle] = useState('Analisis Unsur & Prinsip Karya Seni Rupa');
  const [presTopic, setPresTopic] = useState('Unsur Garis, Warna & Keseimbangan');
  const [slides, setSlides] = useState<PresentationSlide[]>([
    {
      id: 'sl-1',
      heading: 'Identifikasi Unsur Dominan',
      bullets: [
        'Garis lengkung berirama mendominasi alur komposisi.',
        'Pemilihan warna komplementer biru dan oranye membangun kontras.',
      ],
      note: 'Pembukaan presentasi analisis karya.',
      accentColor: '#1D4ED8',
    },
    {
      id: 'sl-2',
      heading: 'Penerapan Prinsip Seni Rupa',
      bullets: [
        'Keseimbangan asimetris menjaga stabilitas kiri dan kanan.',
        'Pusat perhatian terletak pada objek utama di tengah kanan.',
      ],
      note: 'Kesimpulan evaluasi karya.',
      accentColor: '#DC2626',
    },
  ]);

  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    mimeType: string;
    dataUrl: string;
    blob: Blob;
    parsedSlides?: ParsedPptxSlide[];
  } | null>(null);
  const [parsingPptx, setParsingPptx] = useState(false);

  const [submittingPres, setSubmittingPres] = useState(false);
  const [presStatus, setPresStatus] = useState<{
    ok: boolean;
    message: string;
    driveLink?: string;
  } | null>(null);

  const [previewPresId, setPreviewPresId] = useState<string>(
    presentations[0]?.id ?? ''
  );
  const [activePreviewSlideIdx, setActivePreviewSlideIdx] = useState(0);
  const [presCommentInput, setPresCommentInput] = useState('');
  const [sendingPresComment, setSendingPresComment] = useState(false);

  // Keep preview synced when presentations list updates
  const previewPres =
    presentations.find((p) => p.id === previewPresId) ?? presentations[0] ?? null;

  useEffect(() => {
    setActivePreviewSlideIdx(0);
  }, [previewPres?.id]);

  // --- Forum State ---
  const [forumFilter, setForumFilter] = useState<'all' | 'Unsur Seni Rupa' | 'Prinsip Seni Rupa'>('all');
  const [forumTopicTag, setForumTopicTag] = useState('Unsur Seni Rupa');
  const [forumTitle, setForumTitle] = useState('');
  const [forumContent, setForumContent] = useState('');
  const [replyDrafts, setReplyDrafts] = useState<Record<string, string>>({});
  const [activeReplyBox, setActiveReplyBox] = useState<string | null>(null);
  const [postingForum, setPostingForum] = useState(false);

  const addSlide = () => {
    playClickSound();
    setSlides((prev) => [
      ...prev,
      {
        id: `sl-${Date.now()}`,
        heading: `Slide ${prev.length + 1}`,
        bullets: ['Poin pembahasan utama...'],
        note: '',
        accentColor: '#1D4ED8',
      },
    ]);
  };

  const updateSlide = (idx: number, patch: Partial<PresentationSlide>) => {
    setSlides((prev) => prev.map((s, i) => (i === idx ? { ...s, ...patch } : s)));
  };

  const removeSlide = (idx: number) => {
    playClickSound();
    if (slides.length <= 1) return;
    setSlides((prev) => prev.filter((_, i) => i !== idx));
  };

  const buildDeckHtmlString = (
    title: string,
    author: string,
    topic: string,
    deckSlides: PresentationSlide[]
  ) => {
    const slidesHtml = deckSlides
      .map(
        (s, i) => `
      <section style="border:1px solid #e5e0d8;border-radius:16px;padding:32px;margin-bottom:24px;background:#fff;">
        <div style="font-size:12px;color:${s.accentColor};font-weight:700;margin-bottom:8px;">SLIDE ${i + 1} · ${topic}</div>
        <h2 style="margin:0 0 12px 0;font-size:24px;color:#171923;">${s.heading}</h2>
        <ul style="line-height:1.7;color:#334155;">
          ${s.bullets.map((b) => `<li>${b}</li>`).join('')}
        </ul>
        ${s.note ? `<p style="margin-top:16px;font-size:13px;color:#64748b;border-top:1px solid #f1f5f9;padding-top:10px;">Catatan: ${s.note}</p>` : ''}
      </section>`
      )
      .join('');

    return `<!doctype html><html lang="id"><head><meta charset="utf-8"><title>${title}</title></head><body style="font-family:system-ui,sans-serif;max-width:860px;margin:40px auto;padding:0 20px;background:#faf9f7;color:#171923;">
      <header style="margin-bottom:28px;">
        <div style="font-size:12px;color:#1d4ed8;font-weight:700;">PRESENTASI SISWA BHOLANG RUPA</div>
        <h1 style="margin:6px 0;">${title}</h1>
        <p style="margin:0;color:#4a505e;font-size:14px;">Penyaji: ${author} · Topik: ${topic}</p>
      </header>
      ${slidesHtml}
    </body></html>`;
  };

  const downloadPresentation = (pres: {
    title: string;
    studentName: string;
    topic: string;
    mode: 'deck' | 'file';
    slides?: PresentationSlide[];
    fileName?: string;
    fileDataUrl?: string;
  }) => {
    playClickSound();
    if (pres.mode === 'file' && pres.fileDataUrl) {
      const a = document.createElement('a');
      a.href = pres.fileDataUrl;
      a.download = pres.fileName || `${pres.title}.pptx`;
      a.click();
      return;
    }

    const html = buildDeckHtmlString(
      pres.title,
      pres.studentName,
      pres.topic,
      pres.slides || slides
    );
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${pres.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFilePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setParsingPptx(true);
    let parsedSlides: ParsedPptxSlide[] = [];
    if (file.name.toLowerCase().endsWith('.pptx')) {
      parsedSlides = await parsePptxFileToSlides(file);
    }

    const reader = new FileReader();
    reader.onload = () => {
      setUploadedFile({
        name: file.name,
        mimeType: file.type || 'application/octet-stream',
        dataUrl: reader.result as string,
        blob: file,
        parsedSlides,
      });
      if (!presTitle.trim() || presTitle === 'Analisis Unsur & Prinsip Karya Seni Rupa') {
        setPresTitle(file.name.replace(/\.[^.]+$/, ''));
      }
      setParsingPptx(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitPresentation = async () => {
    playClickSound();
    if (!presTitle.trim()) return;
    if (presMode === 'file' && !uploadedFile) {
      setPresStatus({ ok: false, message: 'Pilih berkas presentasi terlebih dahulu.' });
      return;
    }

    setSubmittingPres(true);
    setPresStatus(null);
    try {
      let driveFileId: string | undefined;
      let driveWebViewLink: string | undefined;

      const token = getCachedAccessToken();
      if (token) {
        if (presMode === 'file' && uploadedFile) {
          const driveRes = await uploadBlobToDriveFolder(
            uploadedFile.blob,
            `${profile.name.replace(/\s+/g, '_')}_${uploadedFile.name}`,
            uploadedFile.mimeType
          );
          driveFileId = driveRes.id;
          driveWebViewLink = driveRes.webViewLink;
        } else {
          const html = buildDeckHtmlString(presTitle, profile.name, presTopic, slides);
          const blob = new Blob([html], { type: 'text/html' });
          const driveRes = await uploadBlobToDriveFolder(
            blob,
            `${profile.name.replace(/\s+/g, '_')}_${presTitle.replace(/\s+/g, '_')}.html`,
            'text/html'
          );
          driveFileId = driveRes.id;
          driveWebViewLink = driveRes.webViewLink;
        }
      }

      const res = await fetch('/api/submissions/presentation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: profile.name,
          className: profile.className,
          title: presTitle,
          topic: presTopic,
          mode: presMode,
          slides: presMode === 'deck' ? slides : undefined,
          parsedSlides: presMode === 'file' ? uploadedFile?.parsedSlides : undefined,
          fileName: presMode === 'file' ? uploadedFile?.name : undefined,
          fileMimeType: presMode === 'file' ? uploadedFile?.mimeType : undefined,
          fileDataUrl: presMode === 'file' ? uploadedFile?.dataUrl : undefined,
          driveFileId,
          driveWebViewLink,
        }),
      });
      const data = (await res.json()) as { item?: PresentationSubmission; error?: string };
      if (!res.ok || !data.item) throw new Error(data.error || 'Gagal mengirim presentasi.');

      onPresentationSubmitted(data.item);
      setPreviewPresId(data.item.id);
      setPresStatus({
        ok: true,
        message: driveWebViewLink
          ? 'Presentasi terkirim ke Google Drive dan langsung tampil di pratinjau agar bisa dikomentari seluruh siswa!'
          : 'Presentasi terkirim & tampil langsung! Seluruh siswa sekarang bisa melihat serta memberikan komentar.',
        driveLink: driveWebViewLink,
      });
    } catch (err) {
      setPresStatus({
        ok: false,
        message: err instanceof Error ? err.message : 'Gagal mengirim presentasi.',
      });
    } finally {
      setSubmittingPres(false);
    }
  };

  const handleSendPresentationComment = async (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound();
    if (!previewPres || !presCommentInput.trim() || sendingPresComment) return;

    setSendingPresComment(true);
    try {
      const res = await fetch(`/api/submissions/presentation/${previewPres.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: profile.name,
          authorRole: 'siswa',
          content: presCommentInput.trim(),
        }),
      });
      const data = (await res.json()) as { comment?: PresentationComment };
      if (res.ok && data.comment) {
        onPresentationCommentAdded(previewPres.id, data.comment);
        setPresCommentInput('');
      }
    } finally {
      setSendingPresComment(false);
    }
  };

  const handleCreateForumPost = async (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound();
    if (!forumTitle.trim() || !forumContent.trim() || postingForum) return;

    setPostingForum(true);
    try {
      const res = await fetch('/api/forum/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          authorName: profile.name,
          authorRole: 'siswa',
          className: profile.className,
          topicTag: forumTopicTag,
          title: forumTitle,
          content: forumContent,
        }),
      });
      const data = (await res.json()) as { item?: ForumMessage };
      if (res.ok && data.item) {
        onForumCreated(data.item);
        setForumTitle('');
        setForumContent('');
      }
    } finally {
      setPostingForum(false);
    }
  };

  const handleSendReply = async (messageId: string) => {
    playClickSound();
    const content = (replyDrafts[messageId] || '').trim();
    if (!content) return;

    const res = await fetch(`/api/forum/messages/${messageId}/replies`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        authorName: profile.name,
        authorRole: 'siswa',
        content,
      }),
    });
    const data = (await res.json()) as { reply?: ForumMessage['replies'][number] };
    if (res.ok && data.reply) {
      onForumReply(messageId, data.reply);
      setReplyDrafts((prev) => ({ ...prev, [messageId]: '' }));
      setActiveReplyBox(null);
    }
  };

  const filteredForum = forumMessages.filter((m) => {
    if (forumFilter === 'all') return true;
    return m.topicTag === forumFilter;
  });

  const renderPresentationViewer = (pres: PresentationSubmission) => {
    // 1. Built-in slide deck
    if (pres.mode === 'deck' && pres.slides && pres.slides.length > 0) {
      const total = pres.slides.length;
      const safeIdx = Math.min(activePreviewSlideIdx, total - 1);
      const sl = pres.slides[safeIdx];
      return (
        <div className="space-y-3">
          <div className="rounded-xl border border-[#E5E0D8] bg-[#FAF9F7] p-5 dark:border-[#232A3B] dark:bg-[#0D1017]">
            <div className="flex items-center justify-between text-[11px] font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
              <span>
                Slide {safeIdx + 1} dari {total}
              </span>
              <span>{pres.topic}</span>
            </div>
            <h5 className="mt-2 text-lg font-bold text-[#171923] dark:text-white">
              {sl.heading}
            </h5>
            <ul className="mt-3 list-disc space-y-1.5 pl-5 text-xs leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
              {sl.bullets.map((b, bi) => (
                <li key={bi}>{b}</li>
              ))}
            </ul>
            {sl.note && (
              <p className="mt-3 border-t border-[#E5E0D8] pt-2 text-[11px] text-[#646B7A] dark:border-[#232A3B] dark:text-[#94A3B8]">
                Catatan: {sl.note}
              </p>
            )}
          </div>
          {total > 1 && (
            <div className="flex items-center justify-between">
              <button
                type="button"
                disabled={safeIdx === 0}
                onClick={() => {
                  playClickSound();
                  setActivePreviewSlideIdx((i) => Math.max(0, i - 1));
                }}
                className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-3 py-1.5 text-xs font-semibold disabled:opacity-40 dark:border-[#2D3548]"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                <span>Slide Sebelumnya</span>
              </button>
              <button
                type="button"
                disabled={safeIdx === total - 1}
                onClick={() => {
                  playClickSound();
                  setActivePreviewSlideIdx((i) => Math.min(total - 1, i + 1));
                }}
                className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-3 py-1.5 text-xs font-semibold disabled:opacity-40 dark:border-[#2D3548]"
              >
                <span>Slide Berikutnya</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>
      );
    }

    // 2. Uploaded PPTX parsed into visual slides
    if (pres.parsedSlides && pres.parsedSlides.length > 0) {
      const total = pres.parsedSlides.length;
      const safeIdx = Math.min(activePreviewSlideIdx, total - 1);
      const sl = pres.parsedSlides[safeIdx];
      return (
        <div className="space-y-3">
          <div className="rounded-xl border border-[#E5E0D8] bg-[#FAF9F7] p-5 dark:border-[#232A3B] dark:bg-[#0D1017]">
            <div className="flex items-center justify-between text-[11px] font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
              <span>
                PPTX Slide {sl.slideNumber} / {total}
              </span>
              <span>{pres.fileName}</span>
            </div>
            <h5 className="mt-2 text-lg font-bold text-[#171923] dark:text-white">
              {sl.title}
            </h5>
            {sl.texts.length > 0 && (
              <ul className="mt-3 list-disc space-y-1.5 pl-5 text-xs leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                {sl.texts.map((t, ti) => (
                  <li key={ti}>{t}</li>
                ))}
              </ul>
            )}
            {sl.images.length > 0 && (
              <div className="mt-3 grid grid-cols-2 gap-2">
                {sl.images.map((src, ii) => (
                  <img
                    key={ii}
                    src={src}
                    alt={`Slide ${sl.slideNumber} visual ${ii + 1}`}
                    className="max-h-40 w-full rounded-lg border border-[#E5E0D8] bg-white object-contain dark:border-[#272E3F]"
                  />
                ))}
              </div>
            )}
          </div>
          {total > 1 && (
            <div className="flex items-center justify-between">
              <button
                type="button"
                disabled={safeIdx === 0}
                onClick={() => {
                  playClickSound();
                  setActivePreviewSlideIdx((i) => Math.max(0, i - 1));
                }}
                className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-3 py-1.5 text-xs font-semibold disabled:opacity-40 dark:border-[#2D3548]"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                <span>Slide Sebelumnya</span>
              </button>
              <button
                type="button"
                disabled={safeIdx === total - 1}
                onClick={() => {
                  playClickSound();
                  setActivePreviewSlideIdx((i) => Math.min(total - 1, i + 1));
                }}
                className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] px-3 py-1.5 text-xs font-semibold disabled:opacity-40 dark:border-[#2D3548]"
              >
                <span>Slide Berikutnya</span>
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>
      );
    }

    // 3. PDF / Image / HTML file preview
    const lowerName = (pres.fileName || '').toLowerCase();
    if (pres.fileDataUrl && (lowerName.endsWith('.png') || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg'))) {
      return (
        <img
          src={pres.fileDataUrl}
          alt={pres.title}
          className="max-h-72 w-full rounded-xl border border-[#EEEAE2] bg-white object-contain dark:border-[#232A3B]"
        />
      );
    }
    if (pres.fileDataUrl && (lowerName.endsWith('.pdf') || lowerName.endsWith('.html'))) {
      return (
        <iframe
          title={pres.title}
          src={pres.fileDataUrl}
          className="h-72 w-full rounded-xl border border-[#EEEAE2] bg-white dark:border-[#232A3B]"
        />
      );
    }

    // Fallback for legacy .ppt or unparsed file
    return (
      <div className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-5 text-center text-xs dark:border-[#232A3B] dark:bg-[#0D1017]">
        <p className="font-semibold text-[#171923] dark:text-white">
          Berkas Presentasi: {pres.fileName || pres.title}
        </p>
        <p className="mt-1 text-[#646B7A] dark:text-[#94A3B8]">
          Klik Unduh atau Buka di Google Drive untuk menampilkan berkas ini secara penuh.
        </p>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Segmented Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-[#171923] dark:text-white">
            Presentasi Siswa &amp; Forum Diskusi
          </h2>
          <p className="mt-0.5 text-sm text-[#4A505E] dark:text-[#A3B1C6]">
            Unggah PPT/PDF atau susun slide langsung, tampilkan di pratinjau kelas, dan berikan komentar antar teman sekelas.
          </p>
        </div>

        <div className="flex items-center gap-1 rounded-xl border border-[#E5E0D8] bg-[#F2EFE9] p-1 dark:border-[#272E3F] dark:bg-[#151923]">
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSubMode('presentasi');
            }}
            className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subMode === 'presentasi'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            Presentasi Siswa ({presentations.length})
          </button>
          <button
            type="button"
            onClick={() => {
              playClickSound();
              setSubMode('diskusi');
            }}
            className={`rounded-lg px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subMode === 'diskusi'
                ? 'bg-white text-[#171923] shadow-sm dark:bg-[#2563EB] dark:text-white'
                : 'text-[#4A505E] hover:text-[#171923] dark:text-[#A3B1C6] dark:hover:text-white'
            }`}
          >
            Forum Diskusi Kelas ({forumMessages.length})
          </button>
        </div>
      </div>

      {/* PRESENTASI SISWA */}
      {subMode === 'presentasi' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Builder / Uploader */}
          <div className="space-y-4 rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-5 dark:border-[#272E3F] dark:bg-[#151923]">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
              <div className="flex items-center gap-2">
                <Presentation className="h-5 w-5 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <h3 className="text-base font-bold text-[#171923] dark:text-white">
                  Buat atau Unggah PPT
                </h3>
              </div>

              <div className="flex gap-1 rounded-lg bg-[#FAF9F7] p-0.5 dark:bg-[#0D1017]">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setPresMode('deck');
                  }}
                  className={`rounded-md px-2.5 py-1 text-xs font-semibold ${
                    presMode === 'deck'
                      ? 'bg-[#1D4ED8] text-white'
                      : 'text-[#4A505E] dark:text-[#A3B1C6]'
                  }`}
                >
                  Susun Slide
                </button>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setPresMode('file');
                  }}
                  className={`rounded-md px-2.5 py-1 text-xs font-semibold ${
                    presMode === 'file'
                      ? 'bg-[#1D4ED8] text-white'
                      : 'text-[#4A505E] dark:text-[#A3B1C6]'
                  }`}
                >
                  Unggah PPT / PDF
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                  Judul Presentasi
                </label>
                <input
                  type="text"
                  value={presTitle}
                  onChange={(e) => setPresTitle(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                  Fokus Materi
                </label>
                <input
                  type="text"
                  value={presTopic}
                  onChange={(e) => setPresTopic(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                />
              </div>
            </div>

            {presMode === 'deck' ? (
              <div className="space-y-3">
                {slides.map((s, idx) => (
                  <div
                    key={s.id}
                    className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3.5 dark:border-[#232A3B] dark:bg-[#0D1017]"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-num text-xs font-bold text-[#1D4ED8] dark:text-[#60A5FA]">
                        Slide {idx + 1}
                      </span>
                      {slides.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeSlide(idx)}
                          className="text-xs text-[#DC2626] hover:underline"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                    <input
                      type="text"
                      value={s.heading}
                      onChange={(e) => updateSlide(idx, { heading: e.target.value })}
                      placeholder="Judul slide"
                      className="mt-2 w-full rounded-lg border border-[#D8D2C8] bg-white px-3 py-1.5 text-xs font-semibold text-[#171923] outline-none dark:border-[#2D3548] dark:bg-[#151923] dark:text-white"
                    />
                    <textarea
                      rows={2}
                      value={s.bullets.join('\n')}
                      onChange={(e) =>
                        updateSlide(idx, { bullets: e.target.value.split('\n') })
                      }
                      placeholder="Poin presentasi (1 baris per poin)"
                      className="mt-2 w-full rounded-lg border border-[#D8D2C8] bg-white px-3 py-1.5 text-xs text-[#4A505E] outline-none dark:border-[#2D3548] dark:bg-[#151923] dark:text-[#CBD5E1]"
                    />
                  </div>
                ))}
                <button
                  type="button"
                  onClick={addSlide}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Tambah Slide</span>
                </button>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-[#C9C2B6] bg-[#FAF9F7] p-6 text-center dark:border-[#2D3548] dark:bg-[#0D1017]">
                <FileUp className="mx-auto h-8 w-8 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <p className="mt-2 text-xs font-medium text-[#171923] dark:text-white">
                  Unggah berkas PowerPoint (.pptx, .ppt), PDF, HTML, atau Gambar
                </p>
                <p className="mt-1 text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                  File .pptx otomatis diekstrak menjadi slide visual yang bisa dibaca &amp; dikomentari langsung!
                </p>
                <input
                  type="file"
                  accept=".pptx,.ppt,.pdf,.html,.png,.jpg,.jpeg"
                  onChange={handleFilePick}
                  className="mt-3 text-xs text-[#4A505E] file:mr-3 file:rounded-lg file:border-0 file:bg-[#1D4ED8] file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-white"
                />
                {parsingPptx && (
                  <p className="mt-2 text-xs font-medium text-[#1D4ED8]">
                    Membaca isi slide PowerPoint...
                  </p>
                )}
                {uploadedFile && !parsingPptx && (
                  <p className="mt-2 text-xs font-semibold text-[#059669]">
                    Terpilih: {uploadedFile.name}
                    {uploadedFile.parsedSlides && uploadedFile.parsedSlides.length > 0
                      ? ` (${uploadedFile.parsedSlides.length} slide siap ditampilkan)`
                      : ''}
                  </p>
                )}
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[#EEEAE2] pt-4 dark:border-[#272E3F]">
              <button
                type="button"
                onClick={() =>
                  downloadPresentation({
                    title: presTitle,
                    studentName: profile.name,
                    topic: presTopic,
                    mode: presMode,
                    slides,
                    fileName: uploadedFile?.name,
                    fileDataUrl: uploadedFile?.dataUrl,
                  })
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-2 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Unduh</span>
              </button>

              <button
                type="button"
                onClick={handleSubmitPresentation}
                disabled={submittingPres || parsingPptx}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF] disabled:opacity-50"
              >
                <UploadCloud className="h-3.5 w-3.5" />
                <span>{submittingPres ? 'Mengirim...' : 'Kirim & Tampilkan'}</span>
              </button>
            </div>

            {!getCachedAccessToken() && (
              <div className="flex items-center justify-between rounded-lg bg-[#FAF9F7] px-3 py-2 text-[11px] text-[#646B7A] dark:bg-[#0D1017] dark:text-[#94A3B8]">
                <span>Ingin otomatis masuk ke Google Drive kelas?</span>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    onRequireGoogleLogin();
                  }}
                  className="font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                >
                  Hubungkan Google
                </button>
              </div>
            )}

            {presStatus && (
              <div
                className={`rounded-xl border p-3 text-xs ${
                  presStatus.ok
                    ? 'border-[#059669]/30 bg-emerald-50 text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-200'
                    : 'border-[#DC2626]/30 bg-red-50 text-[#991B1B] dark:bg-red-950/30 dark:text-red-200'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span>{presStatus.message}</span>
                  {presStatus.driveLink && (
                    <a
                      href={presStatus.driveLink}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-semibold underline"
                    >
                      <span>Buka Drive</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right Panel: Interactive PPT/Slide Viewer + Comments + List */}
          <div className="space-y-5 lg:col-span-7">
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 dark:border-[#272E3F] dark:bg-[#151923]">
              <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
                <div className="flex items-center gap-2">
                  <Eye className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
                  <h3 className="text-base font-bold text-[#171923] dark:text-white">
                    Tampilan Presentasi Siswa &amp; Komentar Kelas
                  </h3>
                </div>
                <a
                  href={DRIVE_FOLDER_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                >
                  <span>Folder Drive</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>

              {previewPres ? (
                <div className="mt-4 space-y-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
                        {previewPres.studentName} · {previewPres.className} · {previewPres.topic}
                      </div>
                      <h4 className="mt-1 text-lg font-bold text-[#171923] dark:text-white">
                        {previewPres.title}
                      </h4>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {onRequestSendEmail && (
                        <button
                          type="button"
                          onClick={() => {
                            playClickSound();
                            onRequestSendEmail({
                              subject: `[BHOLANG RUPA] Presentasi Siswa - ${previewPres.studentName} (${previewPres.className})`,
                              summaryText: `Laporan presentasi "${previewPres.title}" oleh ${previewPres.studentName} (${previewPres.className}).`,
                              htmlBody: `
                                <div style="font-family:sans-serif;max-width:600px;color:#171923;">
                                  <h2 style="color:#1D4ED8;">Laporan Presentasi Siswa</h2>
                                  <p><strong>Siswa:</strong> ${previewPres.studentName} (${previewPres.className})</p>
                                  <p><strong>Judul Presentasi:</strong> ${previewPres.title}</p>
                                  <p><strong>Fokus Materi:</strong> ${previewPres.topic}</p>
                                  ${previewPres.driveWebViewLink ? `<p><strong>Link Drive:</strong> <a href="${previewPres.driveWebViewLink}">${previewPres.driveWebViewLink}</a></p>` : ''}
                                  <p><strong>Folder Drive Pemantauan:</strong> <a href="${DRIVE_FOLDER_URL}">${DRIVE_FOLDER_URL}</a></p>
                                </div>
                              `,
                            });
                          }}
                          className="inline-flex items-center gap-1 rounded-lg border border-[#1D4ED8]/40 bg-[#EFF6FF] px-3 py-1.5 text-xs font-semibold text-[#1D4ED8] dark:bg-[#1E293B] dark:text-[#60A5FA]"
                        >
                          <span>Kirim ke E-mail</span>
                        </button>
                      )}
                      {previewPres.driveWebViewLink && (
                        <a
                          href={previewPres.driveWebViewLink}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 rounded-lg border border-[#059669]/40 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-[#065F46] dark:bg-emerald-950/30 dark:text-emerald-300"
                        >
                          <span>Buka di Drive</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => downloadPresentation(previewPres)}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-1.5 text-xs font-semibold text-[#171923] hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Unduh</span>
                      </button>
                    </div>
                  </div>

                  {/* Visual Slide / PPTX / PDF Renderer */}
                  {renderPresentationViewer(previewPres)}

                  {/* Komentar Keseluruhan Kelas pada Presentasi Ini */}
                  <div className="border-t border-[#EEEAE2] pt-4 dark:border-[#272E3F]">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h5 className="text-sm font-bold text-[#171923] dark:text-white">
                        Komentar &amp; Tanggapan Kelas ({previewPres.comments?.length ?? 0})
                      </h5>
                      <span className="text-[11px] font-medium text-[#1D4ED8] dark:text-[#60A5FA]">
                        Terbuka untuk seluruh anggota kelas
                      </span>
                    </div>

                    <div className="mt-3 max-h-52 space-y-2 overflow-y-auto pr-1">
                      {!previewPres.comments || previewPres.comments.length === 0 ? (
                        <p className="text-xs text-[#646B7A] dark:text-[#94A3B8]">
                          Belum ada komentar untuk presentasi ini. Berikan masukan atau apresiasi pertamamu!
                        </p>
                      ) : (
                        previewPres.comments.map((com) => (
                          <div
                            key={com.id}
                            className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3 text-xs dark:border-[#232A3B] dark:bg-[#0D1017]"
                          >
                            <div className="flex items-center justify-between gap-2 text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold text-[#171923] dark:text-white">
                                  {com.authorName}
                                </span>
                                <span aria-hidden="true">·</span>
                                <span className="font-semibold text-[#059669] dark:text-[#34D399]">
                                  {com.authorRole === 'guru' ? 'Kurator Kelas' : 'Siswa'}
                                </span>
                              </div>
                              <span>
                                {new Date(com.createdAt).toLocaleTimeString('id-ID', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </span>
                            </div>
                            <p className="mt-1 text-[#171923] dark:text-[#E2E8F0]">
                              {com.content}
                            </p>
                          </div>
                        ))
                      )}
                    </div>

                    <form onSubmit={handleSendPresentationComment} className="mt-3 flex flex-wrap gap-2">
                      <input
                        type="text"
                        value={presCommentInput}
                        onChange={(e) => setPresCommentInput(e.target.value)}
                        placeholder={`Tulis komentar sebagai ${profile.name}...`}
                        className="min-w-[200px] flex-1 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                      />
                      <button
                        type="submit"
                        disabled={sendingPresComment || !presCommentInput.trim()}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-4 py-2 text-xs font-semibold text-white hover:bg-[#1E40AF] disabled:opacity-50 whitespace-nowrap"
                      >
                        <Send className="h-3.5 w-3.5" />
                        <span>Kirim</span>
                      </button>
                    </form>
                  </div>
                </div>
              ) : (
                <p className="mt-4 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  Pilih presentasi dari daftar di bawah untuk melihat isinya.
                </p>
              )}
            </div>

            {/* List of Submitted Presentations */}
            <div className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]">
              <h3 className="text-sm font-bold text-[#171923] dark:text-white">
                Daftar Presentasi Terkumpul ({presentations.length})
              </h3>
              <div className="mt-3 divide-y divide-[#EEEAE2] dark:divide-[#272E3F]">
                {presentations.map((p) => {
                  const isSelected = previewPres?.id === p.id;
                  return (
                    <div
                      key={p.id}
                      className={`flex flex-wrap items-center justify-between gap-2 py-2.5 px-2 rounded-lg text-xs ${
                        isSelected ? 'bg-[#EFF6FF] dark:bg-[#1E293B]' : ''
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          playClickSound();
                          setPreviewPresId(p.id);
                        }}
                        className="text-left hover:text-[#1D4ED8] dark:hover:text-[#60A5FA]"
                      >
                        <div className="font-semibold text-[#171923] dark:text-white">
                          {p.title}
                        </div>
                        <div className="text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                          {p.studentName} · {p.className} · {p.comments?.length ?? 0} komentar
                          {p.fileName ? ` · ${p.fileName}` : ''}
                        </div>
                      </button>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            playClickSound();
                            setPreviewPresId(p.id);
                          }}
                          className="rounded-md border border-[#D8D2C8] bg-white px-2.5 py-1 font-medium text-[#171923] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                        >
                          Lihat &amp; Komentar
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadPresentation(p)}
                          className="rounded-md bg-[#FAF9F7] px-2.5 py-1 font-medium text-[#1D4ED8] dark:bg-[#0D1017] dark:text-[#60A5FA]"
                        >
                          Unduh
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FORUM DISKUSI REAL-TIME */}
      {subMode === 'diskusi' && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <form
            onSubmit={handleCreateForumPost}
            className="h-fit space-y-4 rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-4 dark:border-[#272E3F] dark:bg-[#151923]"
          >
            <div className="flex items-center gap-2 border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
              <MessageSquare className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
              <h3 className="text-base font-bold text-[#171923] dark:text-white">
                Mulai Topik Diskusi
              </h3>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                Kategori Materi
              </label>
              <select
                value={forumTopicTag}
                onChange={(e) => setForumTopicTag(e.target.value)}
                className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <option value="Unsur Seni Rupa">Unsur Seni Rupa</option>
                <option value="Prinsip Seni Rupa">Prinsip Seni Rupa</option>
                <option value="Praktik Menggambar">Praktik Menggambar</option>
                <option value="Presentasi Karya">Presentasi Karya</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                Judul / Pertanyaan
              </label>
              <input
                type="text"
                value={forumTitle}
                onChange={(e) => setForumTitle(e.target.value)}
                placeholder="Contoh: Cara memadukan tekstur semu dan irama"
                className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                Isi Pendapat / Pertanyaan
              </label>
              <textarea
                rows={4}
                value={forumContent}
                onChange={(e) => setForumContent(e.target.value)}
                placeholder="Tulis pertanyaan atau tanggapan untuk teman sekelas..."
                className="mt-1 w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              />
            </div>

            <button
              type="submit"
              disabled={postingForum || !forumTitle.trim() || !forumContent.trim()}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-xs font-semibold text-white hover:bg-[#1E40AF] disabled:opacity-50"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{postingForum ? 'Mengirim...' : 'Kirim ke Forum Kelas'}</span>
            </button>
          </form>

          <div className="space-y-4 lg:col-span-8">
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-[#E5E0D8] bg-white px-4 py-2.5 dark:border-[#272E3F] dark:bg-[#151923]">
              <span className="text-xs font-semibold text-[#4A505E] dark:text-[#A3B1C6]">
                Forum Diskusi Interaktif Antar Anggota Kelas
              </span>
              <div className="flex gap-1">
                {(
                  [
                    { id: 'all', label: 'Semua' },
                    { id: 'Unsur Seni Rupa', label: 'Unsur' },
                    { id: 'Prinsip Seni Rupa', label: 'Prinsip' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      playClickSound();
                      setForumFilter(f.id);
                    }}
                    className={`rounded-md px-2.5 py-1 text-xs font-medium ${
                      forumFilter === f.id
                        ? 'bg-[#1D4ED8] text-white'
                        : 'text-[#4A505E] hover:bg-[#FAF9F7] dark:text-[#A3B1C6] dark:hover:bg-[#0D1017]'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {filteredForum.map((msg) => (
              <article
                key={msg.id}
                className="rounded-2xl border border-[#E5E0D8] bg-white p-5 dark:border-[#272E3F] dark:bg-[#151923]"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[#171923] dark:text-white">
                      {msg.authorName}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {msg.authorRole === 'guru' ? 'Kurator Kelas' : `Siswa ${msg.className}`}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{msg.topicTag}</span>
                  </div>
                  <span>
                    {new Date(msg.createdAt).toLocaleString('id-ID', {
                      dateStyle: 'short',
                      timeStyle: 'short',
                    })}
                  </span>
                </div>

                <h4 className="mt-2 text-base font-bold text-[#171923] dark:text-white">
                  {msg.title}
                </h4>
                <p className="mt-1.5 text-sm leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                  {msg.content}
                </p>

                {msg.replies.length > 0 && (
                  <div className="mt-4 space-y-2.5 border-t border-[#EEEAE2] pt-3 dark:border-[#272E3F]">
                    {msg.replies.map((rep) => (
                      <div
                        key={rep.id}
                        className="rounded-xl bg-[#FAF9F7] p-3 text-xs dark:bg-[#0D1017]"
                      >
                        <div className="flex items-center gap-2 text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                          <span className="font-semibold text-[#171923] dark:text-white">
                            {rep.authorName}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>
                            {rep.authorRole === 'guru' ? 'Kurator Kelas' : 'Siswa'}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span>
                            {new Date(rep.createdAt).toLocaleTimeString('id-ID', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="mt-1 text-[#171923] dark:text-[#E2E8F0]">{rep.content}</p>
                      </div>
                    ))}
                  </div>
                )}

                <div className="mt-3 pt-2">
                  {activeReplyBox === msg.id ? (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={replyDrafts[msg.id] || ''}
                        onChange={(e) =>
                          setReplyDrafts((prev) => ({ ...prev, [msg.id]: e.target.value }))
                        }
                        placeholder="Tulis balasan Anda..."
                        className="w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-1.5 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={() => handleSendReply(msg.id)}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#1D4ED8] px-3 py-1.5 text-xs font-semibold text-white"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Kirim</span>
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        playClickSound();
                        setActiveReplyBox(msg.id);
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1D4ED8] hover:underline dark:text-[#60A5FA]"
                    >
                      <Reply className="h-3.5 w-3.5" />
                      <span>Balas Diskusi</span>
                    </button>
                  )}
                </div>
              </article>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
