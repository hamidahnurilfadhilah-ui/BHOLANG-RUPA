import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Bot,
  ChevronLeft,
  ChevronRight,
  Download,
  ExternalLink,
  FileText,
  Maximize2,
  Play,
  Send,
  Youtube,
} from 'lucide-react';
import { EBOOK_URL, SLIDES, YOUTUBE_VIDEOS } from '../data/learningContent';
import type { ActiveTab } from '../types';
import { playClickSound } from '../utils/sound';
import type { FocusViewerResource } from './ExternalReturnExperience';

interface MateriSectionProps {
  onNavigateTab: (tab: ActiveTab) => void;
  onOpenFocusViewer?: (resource: FocusViewerResource) => void;
}

interface TutorMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
}

export const MateriSection: React.FC<MateriSectionProps> = ({
  onNavigateTab,
  onOpenFocusViewer,
}) => {
  const [slideIndex, setSlideIndex] = useState(0);
  const [showInlinePdf, setShowInlinePdf] = useState(false);
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');
  const [messages, setMessages] = useState<TutorMessage[]>([
    {
      id: 'm-init',
      sender: 'ai',
      text: 'Halo! Saya Tutor AI BHOLANG RUPA. Tanyakan konsep apa saja tentang Unsur-Unsur Seni Rupa (titik, garis, warna, tekstur, gelap-terang) maupun Prinsip Komposisi.',
    },
  ]);

  const currentSlide = SLIDES[slideIndex];

  const askAiTutor = async (customPrompt?: string) => {
    const query = (customPrompt ?? aiQuestion).trim();
    if (!query || aiLoading) return;
    playClickSound();

    const userMsg: TutorMessage = { id: `u-${Date.now()}`, sender: 'user', text: query };
    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setAiQuestion('');
    setAiLoading(true);
    setAiError('');

    try {
      const res = await fetch('/api/ai/tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: query,
          slideContext: `${currentSlide.title} — ${currentSlide.summary}`,
        }),
      });
      const data = (await res.json()) as { answer?: string; error?: string };
      if (!res.ok) {
        throw new Error(data.error || 'Gagal menghubungi Tutor AI.');
      }
      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          sender: 'ai',
          text: data.answer || 'Tidak ada jawaban.',
        },
      ]);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'Terjadi kesalahan jaringan.');
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className="space-y-10">
      {/* Editorial Hero Split */}
      <section className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-12">
        <div className="flex flex-col justify-between rounded-2xl border border-[#E5E0D8] bg-white p-6 sm:p-8 lg:col-span-7 dark:border-[#272E3F] dark:bg-[#151923]">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-[#646B7A] dark:text-[#94A3B8]">
              <span>Kurikulum Merdeka</span>
              <span aria-hidden="true">·</span>
              <span>Seni Budaya Kelas X</span>
              <span aria-hidden="true">·</span>
              <span>KD 3.1 Unsur &amp; Prinsip Seni Rupa</span>
            </div>
            <h1
              className="mt-3 text-3xl font-bold tracking-tight text-[#171923] sm:text-4xl dark:text-white"
              style={{ textWrap: 'balance' }}
            >
              Memahami Bahasa Visual: Unsur-Unsur &amp; Prinsip Seni Rupa
            </h1>
            <p className="mt-3 max-w-2xl text-base leading-relaxed text-[#4A505E] dark:text-[#A3B1C6]">
              Jelajahi delapan unsur pembentuk karya rupa dan enam prinsip penataan komposisi secara visual,
              berdiskusi aktif di forum kelas, praktik menggambar di studio digital, dan simpan hasil evaluasi
              otomatis ke Google Drive serta E-mail pemantauan.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-3 pt-4 border-t border-[#EEEAE2] dark:border-[#272E3F]">
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onNavigateTab('demo-praktik');
              }}
              className="inline-flex items-center gap-2 rounded-lg bg-[#1D4ED8] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1E40AF] whitespace-nowrap shrink-0 dark:bg-[#2563EB]"
            >
              <span>Buka Demo &amp; Studio Gambar</span>
              <ArrowRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => {
                playClickSound();
                onNavigateTab('kuis');
              }}
              className="inline-flex items-center gap-2 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-4 py-2.5 text-sm font-semibold text-[#171923] transition-colors hover:bg-[#EFECE6] whitespace-nowrap shrink-0 dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white dark:hover:bg-[#1E2433]"
            >
              <span>Kerjakan Kuis Evaluasi</span>
            </button>
          </div>
        </div>

        <div className="relative min-h-[240px] overflow-hidden rounded-2xl border border-[#E5E0D8] bg-[#151923] lg:col-span-5 dark:border-[#272E3F]">
          <img
            src="/src/assets/images/hero_art_studio_1794935614952.jpg"
            alt="Meja studio seni rupa dengan buku sketsa dan palet cat air"
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent" />
          <div className="absolute right-5 bottom-5 left-5 text-white">
            <p className="text-xs font-medium text-blue-200">Studio Terpadu BHOLANG RUPA</p>
            <p className="mt-0.5 text-sm font-semibold">
              Slide Interaktif · E-Book Kemendikdasmen · Video · AI Tutor
            </p>
          </div>
        </div>
      </section>

      {/* Slide Interaktif + AI Tutor */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Interactive Slide Deck */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-8 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#EEEAE2] pb-4 dark:border-[#272E3F]">
            <div>
              <div className="flex items-center gap-2 text-xs text-[#646B7A] dark:text-[#94A3B8]">
                <span className="font-mono-num font-semibold text-[#1D4ED8] dark:text-[#60A5FA]">
                  {currentSlide.index}
                </span>
                <span aria-hidden="true">·</span>
                <span>{currentSlide.category}</span>
              </div>
              <h2 className="mt-1 text-xl font-bold text-[#171923] sm:text-2xl dark:text-white">
                {currentSlide.title}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={slideIndex === 0}
                onClick={() => {
                  playClickSound();
                  setSlideIndex((i) => Math.max(0, i - 1));
                }}
                aria-label="Slide sebelumnya"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] text-[#171923] transition-colors hover:bg-[#EFECE6] disabled:opacity-40 dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                type="button"
                disabled={slideIndex === SLIDES.length - 1}
                onClick={() => {
                  playClickSound();
                  setSlideIndex((i) => Math.min(SLIDES.length - 1, i + 1));
                }}
                aria-label="Slide berikutnya"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] text-[#171923] transition-colors hover:bg-[#EFECE6] disabled:opacity-40 dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-1 gap-6 md:grid-cols-12">
            <div className="space-y-4 md:col-span-7">
              <p className="text-sm font-medium text-[#1D4ED8] dark:text-[#60A5FA]">
                {currentSlide.subtitle}
              </p>
              <p className="text-sm leading-relaxed text-[#4A505E] dark:text-[#CBD5E1]">
                {currentSlide.summary}
              </p>
              <div className="space-y-3 pt-1">
                {currentSlide.points.map((pt) => (
                  <div
                    key={pt.label}
                    className="rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3.5 dark:border-[#232A3B] dark:bg-[#0D1017]"
                  >
                    <div className="text-sm font-semibold text-[#171923] dark:text-white">
                      {pt.label}
                    </div>
                    <p className="mt-0.5 text-xs leading-relaxed text-[#4A505E] dark:text-[#94A3B8]">
                      {pt.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Slide Visual Plate */}
            <div className="flex flex-col justify-between rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-4 md:col-span-5 dark:border-[#232A3B] dark:bg-[#0D1017]">
              {currentSlide.imageUrl ? (
                <div className="overflow-hidden rounded-lg">
                  <img
                    src={currentSlide.imageUrl}
                    alt={currentSlide.title}
                    referrerPolicy="no-referrer"
                    className="h-56 w-full object-cover"
                  />
                </div>
              ) : (
                <div className="flex h-56 items-center justify-center rounded-lg bg-white p-3 dark:bg-[#151923]">
                  <SlideVectorIllustration type={currentSlide.visualType} />
                </div>
              )}

              <div className="mt-4 space-y-3">
                <button
                  type="button"
                  onClick={() =>
                    askAiTutor(`Berikan contoh latihan praktik sederhana untuk materi "${currentSlide.title}"`)
                  }
                  className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-3 py-2 text-xs font-semibold text-[#1D4ED8] transition-colors hover:bg-[#DBEAFE] dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
                >
                  <Bot className="h-3.5 w-3.5" />
                  <span>Tanya AI Contoh Latihan Slide Ini</span>
                </button>
              </div>
            </div>
          </div>

          {/* Slide selector bar */}
          <div className="mt-6 flex flex-wrap items-center gap-1.5 border-t border-[#EEEAE2] pt-4 dark:border-[#272E3F]">
            {SLIDES.map((s, idx) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  playClickSound();
                  setSlideIndex(idx);
                }}
                className={`font-mono-num rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
                  idx === slideIndex
                    ? 'bg-[#1D4ED8] text-white'
                    : 'bg-[#FAF9F7] text-[#4A505E] hover:bg-[#EFECE6] dark:bg-[#0D1017] dark:text-[#94A3B8] dark:hover:bg-[#1E2433]'
                }`}
              >
                {String(idx + 1).padStart(2, '0')}
              </button>
            ))}
          </div>
        </div>

        {/* AI Tutor Seni Rupa */}
        <div className="flex flex-col justify-between rounded-2xl border border-[#E5E0D8] bg-white p-5 lg:col-span-4 dark:border-[#272E3F] dark:bg-[#151923]">
          <div>
            <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
              <div className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-[#1D4ED8] dark:text-[#60A5FA]" />
                <h3 className="text-base font-bold text-[#171923] dark:text-white">
                  Asisten Belajar AI
                </h3>
              </div>
              <span className="text-[11px] font-medium text-[#646B7A] dark:text-[#94A3B8]">
                Seni Rupa KD 3.1
              </span>
            </div>

            <div className="mt-3 h-72 space-y-3 overflow-y-auto pr-1">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`rounded-xl p-3 text-xs leading-relaxed ${
                    m.sender === 'user'
                      ? 'ml-6 bg-[#1D4ED8] text-white'
                      : 'mr-4 border border-[#EEEAE2] bg-[#FAF9F7] text-[#171923] dark:border-[#232A3B] dark:bg-[#0D1017] dark:text-[#E2E8F0]'
                  }`}
                >
                  <p className="whitespace-pre-line">{m.text}</p>
                </div>
              ))}
              {aiLoading && (
                <div className="mr-4 rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] p-3 text-xs text-[#646B7A] dark:border-[#232A3B] dark:bg-[#0D1017] dark:text-[#94A3B8]">
                  Menyusun penjelasan materi...
                </div>
              )}
              {aiError && (
                <div className="rounded-xl border border-[#DC2626]/30 bg-red-50 p-3 text-xs text-[#DC2626] dark:bg-red-950/30 dark:text-red-300">
                  {aiError}
                </div>
              )}
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              askAiTutor();
            }}
            className="mt-4 flex gap-2 border-t border-[#EEEAE2] pt-3 dark:border-[#272E3F]"
          >
            <input
              type="text"
              value={aiQuestion}
              onChange={(e) => setAiQuestion(e.target.value)}
              placeholder="Tanya tentang garis, warna, irama..."
              className="w-full rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3 py-2 text-xs text-[#171923] outline-none focus:border-[#1D4ED8] dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
            />
            <button
              type="submit"
              disabled={aiLoading || !aiQuestion.trim()}
              aria-label="Kirim pertanyaan ke AI"
              className="inline-flex items-center justify-center rounded-lg bg-[#1D4ED8] px-3.5 py-2 text-white transition-colors hover:bg-[#1E40AF] disabled:opacity-50"
            >
              <Send className="h-3.5 w-3.5" />
            </button>
          </form>
        </div>
      </section>

      {/* E-Book Kemendikdasmen & Video Pembelajaran YouTube */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* E-Book Card */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-5 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex items-center gap-2 text-xs font-medium text-[#646B7A] dark:text-[#94A3B8]">
            <BookOpen className="h-4 w-4 text-[#1D4ED8] dark:text-[#60A5FA]" />
            <span>E-Book Resmi Kemendikdasmen</span>
            <span aria-hidden="true">·</span>
            <span>PDF KD 3.1</span>
          </div>

          <div className="mt-4 flex flex-col gap-5 sm:flex-row">
            <div className="w-32 shrink-0 overflow-hidden rounded-lg border border-[#E5E0D8] dark:border-[#272E3F]">
              <img
                src="/src/assets/images/ebook_cover_seni_rupa_1794935616200.jpg"
                alt="Sampul Modul Seni Budaya Kelas X KD 3.1"
                referrerPolicy="no-referrer"
                className="h-44 w-full object-cover"
              />
            </div>

            <div className="flex flex-col justify-between">
              <div>
                <h3 className="text-lg font-bold text-[#171923] dark:text-white">
                  Modul Seni Budaya (Seni Rupa) Kelas X — KD 3.1
                </h3>
                <p className="mt-1.5 text-xs leading-relaxed text-[#4A505E] dark:text-[#A3B1C6]">
                  Buku sumber resmi dari repositori Kemendikdasmen tentang konsep, unsur, prinsip, bahan, dan
                  teknik berkarya seni rupa dua dimensi.
                </p>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setShowInlinePdf((v) => !v);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1E40AF] whitespace-nowrap"
                >
                  <FileText className="h-3.5 w-3.5" />
                  <span>{showInlinePdf ? 'Kembali ke Web (Tutup PDF)' : 'Baca di Halaman'}</span>
                </button>
                {onOpenFocusViewer && (
                  <button
                    type="button"
                    onClick={() => {
                      playClickSound();
                      onOpenFocusViewer({
                        title: 'E-Book Seni Budaya (Seni Rupa) Kelas X — KD 3.1',
                        subtitle: 'Repositori Resmi Kemendikdasmen · Mode Baca Dalam Web',
                        embedUrl: `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(EBOOK_URL)}`,
                        externalUrl: EBOOK_URL,
                      });
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-[#1D4ED8]/30 bg-[#EFF6FF] px-3.5 py-2 text-xs font-semibold text-[#1D4ED8] transition-colors hover:bg-[#DBEAFE] whitespace-nowrap dark:border-[#3B82F6]/40 dark:bg-[#1E293B] dark:text-[#60A5FA]"
                  >
                    <Maximize2 className="h-3.5 w-3.5" />
                    <span>Layar Penuh</span>
                  </button>
                )}
                <a
                  href={EBOOK_URL}
                  target="_blank"
                  rel="noreferrer"
                  data-resource-label="E-Book Kemendikdasmen KD 3.1"
                  onClick={() => playClickSound()}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#D8D2C8] bg-[#FAF9F7] px-3.5 py-2 text-xs font-semibold text-[#171923] transition-colors hover:bg-[#EFECE6] whitespace-nowrap dark:border-[#2D3548] dark:bg-[#0D1017] dark:text-white"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Buka / Unduh PDF</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          </div>

          {showInlinePdf && (
            <div className="mt-5 overflow-hidden rounded-xl border border-[#E5E0D8] bg-[#FAF9F7] dark:border-[#272E3F] dark:bg-[#0D1017]">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#E5E0D8] bg-white px-3.5 py-2.5 text-xs dark:border-[#272E3F] dark:bg-[#151923]">
                <span className="font-semibold text-[#171923] dark:text-white">
                  Pratinjau E-Book KD 3.1
                </span>
                <button
                  type="button"
                  onClick={() => {
                    playClickSound();
                    setShowInlinePdf(false);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#1E40AF]"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>Kembali ke Web</span>
                </button>
              </div>
              <iframe
                title="E-Book Seni Budaya KD 3.1"
                src={`https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(EBOOK_URL)}`}
                className="h-[420px] w-full"
              />
            </div>
          )}
        </div>

        {/* YouTube Videos */}
        <div className="rounded-2xl border border-[#E5E0D8] bg-white p-6 lg:col-span-7 dark:border-[#272E3F] dark:bg-[#151923]">
          <div className="flex items-center justify-between border-b border-[#EEEAE2] pb-3 dark:border-[#272E3F]">
            <div className="flex items-center gap-2">
              <Youtube className="h-5 w-5 text-[#DC2626]" />
              <h3 className="text-lg font-bold text-[#171923] dark:text-white">
                Video Pembelajaran YouTube
              </h3>
            </div>
            <span className="text-xs text-[#646B7A] dark:text-[#94A3B8]">2 Video Kurikulum</span>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2">
            {YOUTUBE_VIDEOS.map((video) => (
              <div
                key={video.id}
                className="overflow-hidden rounded-xl border border-[#EEEAE2] bg-[#FAF9F7] dark:border-[#232A3B] dark:bg-[#0D1017]"
              >
                <div className="aspect-video w-full bg-black">
                  <iframe
                    src={video.embedUrl}
                    title={video.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="h-full w-full"
                  />
                </div>
                <div className="p-3.5">
                  <div className="flex items-center gap-2 text-[11px] text-[#646B7A] dark:text-[#94A3B8]">
                    <Play className="h-3 w-3 text-[#DC2626]" />
                    <span>{video.duration}</span>
                  </div>
                  <h4 className="mt-1 text-sm font-bold text-[#171923] dark:text-white">
                    {video.title}
                  </h4>
                  <p className="mt-1 text-xs text-[#4A505E] dark:text-[#A3B1C6]">{video.focus}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    {onOpenFocusViewer && (
                      <button
                        type="button"
                        onClick={() => {
                          playClickSound();
                          onOpenFocusViewer({
                            title: video.title,
                            subtitle: `${video.duration} · Video Pembelajaran YouTube Dalam Web`,
                            embedUrl: video.embedUrl,
                            externalUrl: video.url,
                          });
                        }}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-[#1D4ED8] px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#1E40AF]"
                      >
                        <Maximize2 className="h-3 w-3" />
                        <span>Putar Fokus</span>
                      </button>
                    )}
                    <a
                      href={video.url}
                      target="_blank"
                      rel="noreferrer"
                      data-resource-label={`Video YouTube: ${video.title}`}
                      onClick={() => playClickSound()}
                      className="inline-flex items-center gap-1 rounded-lg border border-[#D8D2C8] bg-white px-3 py-1.5 text-xs font-semibold text-[#171923] transition-colors hover:bg-[#EFECE6] dark:border-[#2D3548] dark:bg-[#151923] dark:text-[#60A5FA]"
                    >
                      <span>Tonton di YouTube</span>
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

const SlideVectorIllustration: React.FC<{ type: string }> = ({ type }) => {
  if (type === 'bidang-bentuk') {
    return (
      <svg viewBox="0 0 240 160" className="h-full w-full">
        <rect x="24" y="34" width="66" height="66" fill="#DBEAFE" stroke="#1D4ED8" strokeWidth="2" />
        <circle cx="88" cy="100" r="30" fill="#FEE2E2" stroke="#DC2626" strokeWidth="2" opacity="0.85" />
        <polygon points="155,34 210,60 210,122 155,96" fill="#1D4ED8" opacity="0.85" />
        <polygon points="155,34 186,18 232,42 210,60" fill="#60A5FA" />
        <polygon points="210,60 232,42 232,102 210,122" fill="#1E3A8A" />
      </svg>
    );
  }
  if (type === 'ruang-warna') {
    return (
      <svg viewBox="0 0 240 160" className="h-full w-full">
        <circle cx="95" cy="70" r="36" fill="#DC2626" opacity="0.82" />
        <circle cx="135" cy="70" r="36" fill="#EAB308" opacity="0.82" />
        <circle cx="115" cy="102" r="36" fill="#1D4ED8" opacity="0.82" />
      </svg>
    );
  }
  if (type === 'tekstur-gelap') {
    return (
      <svg viewBox="0 0 240 160" className="h-full w-full">
        <defs>
          <radialGradient id="sphereGrad" cx="35%" cy="32%" r="65%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="45%" stopColor="#94A3B8" />
            <stop offset="100%" stopColor="#0F172A" />
          </radialGradient>
        </defs>
        <ellipse cx="128" cy="130" rx="52" ry="12" fill="#0F172A" opacity="0.25" />
        <circle cx="116" cy="78" r="48" fill="url(#sphereGrad)" />
      </svg>
    );
  }
  if (type === 'irama-penekanan') {
    return (
      <svg viewBox="0 0 240 160" className="h-full w-full">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <rect
            key={i}
            x={24 + i * 32}
            y={36 + (i % 2) * 14}
            width="20"
            height={78 - i * 6}
            rx="4"
            fill={i === 3 ? '#DC2626' : '#334155'}
          />
        ))}
      </svg>
    );
  }
  if (type === 'proporsi-keselarasan') {
    return (
      <svg viewBox="0 0 240 160" className="h-full w-full">
        <rect x="28" y="24" width="184" height="112" fill="none" stroke="#1D4ED8" strokeWidth="2" />
        <line x1="142" y1="24" x2="142" y2="136" stroke="#1D4ED8" strokeWidth="1.5" />
        <line x1="142" y1="94" x2="212" y2="94" stroke="#1D4ED8" strokeWidth="1.5" />
        <path d="M 28 136 A 114 114 0 0 1 142 24" fill="none" stroke="#DC2626" strokeWidth="2.5" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 240 160" className="h-full w-full">
      <rect x="30" y="30" width="76" height="96" rx="8" fill="#1D4ED8" opacity="0.2" stroke="#1D4ED8" strokeWidth="2" />
      <circle cx="156" cy="78" r="42" fill="#059669" opacity="0.22" stroke="#059669" strokeWidth="2" />
      <path d="M 48 110 Q 120 30 194 98" fill="none" stroke="#DC2626" strokeWidth="3" />
    </svg>
  );
};
